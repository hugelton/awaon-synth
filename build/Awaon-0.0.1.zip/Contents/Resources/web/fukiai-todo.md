note 8 16
portament arrow
weight(16t)
ladder
acid (smile)
link
un-link
amp (audio cresend)
resonator (mountains)
