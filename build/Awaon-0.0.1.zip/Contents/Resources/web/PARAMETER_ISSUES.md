# Parameter Issues - 2025-12-13

## 問題1: LFO DEPTH 初期値の不一致

### 現状
- **GUI** (index.html line 498, 541): `value="0"` → 0%
- **DSP** (IPlugWebUI.cpp line 53): `InitDouble("LFO1 Depth", 0.2, ...)` → 20%
- **DSP** (IPlugWebUI.cpp line 58): `InitDouble("LFO2 Depth", 0.3, ...)` → 30%

### 問題
起動時、GUI は DEPTH=0% を表示するが、DSP 側は実際には 20%/30% で動作している。
さらに、Matrix のデフォルトルーティング (line 88-92) で `LFO1 (source=3) → OSC1 Freq (dest=1), amount=100%` が設定されているため、DEPTH とは別に Matrix 経由で LFO がかかっている。

### 解決策
1. DSP 初期値を 0.0 に変更
2. Matrix デフォルトルーティングを削除または amount を 0.0 に設定

---

## 問題2: Voice Number 初期値の不一致

### 現状
- **GUI** (index.html line 67): `value="16"` → 16 voices
- **DSP** (IPlugWebUI.cpp line 75): `InitInt("Voices", 1, 1, 16)` → 1 voice

### 問題
起動時、GUI は 16 voices を表示するが、DSP 側は実際には 1 voice で動作している。

### 解決策
DSP 初期値を 16 に変更、または GUI を 1 に変更（ポリシンセとしては 16 が適切）

---

## 問題3: Voicing Mode 初期値の不一致

### 現状
- **GUI** (index.html): デフォルト選択が不明確（おそらく最初のボタン = Mono?）
- **DSP** (IPlugWebUI.cpp line 76): `InitEnum("Voicing", 0, {"Mono","Poly","Unison"})` → Mono (0)

### 問題
ポリシンセとして起動すべきだが、Mono モードで起動している可能性。
また、Unison モードに切り替えても、voice number が正しく反映されない。

### 解決策
1. 初期値を Poly (1) に変更
2. Unison モード時の voice number 表示を確認

---

## 問題4: Matrix LFO が一つだけ

### 現状
- Matrix UI では LFO が一つのソースとして表示されている
- DSP 側 (IPlugWebUI.h line 699-710) では modSources[3]=LFO1, modSources[4]=LFO2 と分離されている

### 問題
GUI と DSP のソースインデックスが一致していない可能性。

### 解決策
1. Matrix UI を LFO I / LFO II に分離
2. ソースインデックスを GUI と DSP で一致させる

---

## 問題5: モーダルフィルター MIX の実装確認 ✅ 調査完了

### 調査結果
- **Filter MIX パラメータ**: ❌ 存在しない
- **Serial/Parallel ルーティング**: ❌ 存在しない (常に Serial のみ)
- **現在の実装** (IPlugWebUI.h line 840-842):
  ```cpp
  // Filters (series connection)
  float filtered = mFilterA.process(oscMix);
  filtered = mFilterB.process(filtered);
  ```

### 現状
Filter A と Filter B は常に **直列接続** (FilterA → FilterB) で動作。
- MIX パラメータなし
- Parallel 接続オプションなし
- GUI にも DSP にも MIX 関連のパラメータが存在しない

### 今後の実装候補（要望があれば）
1. **Filter Routing Mode** パラメータ追加 (Serial / Parallel / FilterA Only / FilterB Only)
2. **Filter Mix** パラメータ追加 (Parallel 時の A/B バランス 0%=A only, 50%=equal mix, 100%=B only)
3. DSP 側の実装:
   ```cpp
   if (routingMode == PARALLEL) {
     float outA = mFilterA.process(oscMix);
     float outB = mFilterB.process(oscMix);
     filtered = outA * (1.0f - mix) + outB * mix;
   } else { // SERIAL
     filtered = mFilterA.process(oscMix);
     filtered = mFilterB.process(filtered);
   }
   ```

### 結論
**Filter MIX は未実装**。現在は Serial 接続のみ。実装するには新規パラメータ追加が必要。

---

## 修正の優先順位

1. **高**: LFO DEPTH 初期値修正 + Matrix デフォルト削除
2. **高**: Voice Number 初期値修正
3. **中**: Voicing Mode 初期値を Poly に変更
4. **中**: Matrix LFO 分離
5. **低**: Filter MIX 実装確認
