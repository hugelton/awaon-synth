// ============================================================================
// Awaon Synthesizer UI - JavaScript
// Parameter communication with iPlug2 C++ DSP
// ============================================================================
const RIGHT_CLICK = false;
const DEBUG = false;
const KEYBOARD = false;
const APP_VERSION = '0.0.1';  // Current Awaon version - must match preset version

if (!DEBUG) {
  console.log = () => { };
  console.warn = () => { };
  console.error = () => { };
  console.info = () => { };
  console.debug = () => { };
}

// ============================================================================
// Loading Progress Bar Management
// ============================================================================

let loadingProgress = 0;

function updateLoadingProgress(progress) {
  loadingProgress = Math.min(progress, 100);
  const progressFill = document.getElementById('loading-progress-fill');
  if (progressFill) {
    progressFill.style.width = loadingProgress + '%';
  }
}

function hideLoadingScreen() {
  const progressBar = document.getElementById('loading-progress-bar');
  if (progressBar) {
    // Animate to 100% and fade out
    updateLoadingProgress(100);
    setTimeout(() => {
      progressBar.style.opacity = '0';
      progressBar.style.transition = 'opacity 0.5s ease';
      setTimeout(() => {
        progressBar.style.display = 'none';
      }, 500);
    }, 200);
  }
}

// Initialize loading progress on page load
window.addEventListener('load', () => {
  updateLoadingProgress(50);
});

// Parameter indices from IPlugWebUI.h Param namespace
// IMPORTANT: These MUST match the C++ Param namespace exactly!
const Params = {
  // Oscillator 1 (0-4)
  OSC1_WAVE: 0,
  OSC1_SEMI: 1,
  OSC1_FINE: 2,
  OSC1_LEVEL: 3,
  OSC1_SYNC: 4,

  // Oscillator 2 (5-9)
  OSC2_WAVE: 5,
  OSC2_SEMI: 6,
  OSC2_FINE: 7,
  OSC2_LEVEL: 8,
  OSC2_DETUNE: 9,

  // Noise (10-12)
  NOISE_TYPE: 10,
  NOISE_LEVEL: 11,
  NOISE_VARIANT: 12,

  // Filter 1 (13-16)
  FILTER_1_TYPE: 13,
  FILTER_1_CUTOFF: 14,
  FILTER_1_RESO: 15,
  FILTER_1_DRIVE: 16,

  // Filter 2 (17-20)
  FILTER_2_TYPE: 17,
  FILTER_2_CUTOFF: 18,
  FILTER_2_RESO: 19,
  FILTER_2_DRIVE: 20,

  // Filter Routing (21-22)
  FILTER_ROUTING: 21,
  FILTER_MIX: 22,

  // Envelope 1 (23-28)
  ENV1_ATTACK: 23,
  ENV1_DECAY: 24,
  ENV1_SUSTAIN: 25,
  ENV1_RELEASE: 26,
  ENV1_CURVE: 27,
  ENV1_LEVEL: 28,

  // Envelope 2 (29-34)
  ENV2_ATTACK: 29,
  ENV2_DECAY: 30,
  ENV2_SUSTAIN: 31,
  ENV2_RELEASE: 32,
  ENV2_CURVE: 33,
  ENV2_LEVEL: 34,

  // LFO 1 (35-39)
  LFO1_WAVE: 35,
  LFO1_RATE: 36,
  LFO1_SHAPE: 37,
  LFO1_DEPTH: 38,
  LFO1_SYNC: 39,

  // LFO 2 (40-44)
  LFO2_WAVE: 40,
  LFO2_RATE: 41,
  LFO2_SHAPE: 42,
  LFO2_DEPTH: 43,
  LFO2_SYNC: 44,

  // Effects (45-54)
  DELAY_TIME: 45,
  DELAY_FEEDBACK: 46,
  DELAY_MIX: 47,
  DELAY_SYNC: 48,
  CHORUS_RATE: 49,
  CHORUS_DEPTH: 50,
  CHORUS_MIX: 51,
  REVERB_SIZE: 52,
  REVERB_DAMP: 53,
  REVERB_MIX: 54,

  // Master/Global (55-63, 61 repurposed for LFO1 tempo div)
  MASTER_VOLUME: 55,
  MASTER_PORTAMENTO: 56,
  MASTER_TUNE: 57,
  MASTER_VOICE_NUM: 58,
  MASTER_VOICING_MODE: 59,
  MASTER_BEND_AMOUNT: 60,
  LFO1_TEMPO_DIV: 61,  // REPURPOSED from MASTER_ANALOG_FEEL
  GLOBAL_OCTAVE: 62,
  GLOBAL_SEMITONE: 63,

  // OSC Wavetable Blend (64-69)
  OSC1_AMOUNT: 64,
  OSC1_BANK: 65,
  OSC1_COMPOUND: 66,
  OSC2_AMOUNT: 67,
  OSC2_BANK: 68,
  OSC2_COMPOUND: 69,

  // Modal Filter (70-73)
  MODAL_TYPE: 70,
  MODAL_TONE: 71,
  MODAL_RESO: 72,
  MODAL_MIX: 73,

  // LFO Delays (74-75)
  LFO1_DELAY: 74,
  LFO2_DELAY: 75,

  // Filter Dry/Wet Mix (76-77)
  FILTER_1_MIX: 76,
  FILTER_2_MIX: 77,

  // OSC Wavetable Phase Offset (78-81)
  OSC1_OFFSET_A: 78,
  OSC1_OFFSET_B: 79,
  OSC2_OFFSET_A: 80,
  OSC2_OFFSET_B: 81,

  // OSC Clip Mode (82-83)
  OSC1_CLIP_MODE: 82,
  OSC2_CLIP_MODE: 83,

  // Transient Oscillator (84-88, 87 repurposed for LFO2 tempo div)
  TRANSIENT_MODE: 84,
  TRANSIENT_DECAY: 85,
  TRANSIENT_TIMBRE: 86,
  LFO2_TEMPO_DIV: 87,  // REPURPOSED from TRANSIENT_PAN
  TRANSIENT_LEVEL: 88,

  // Signals Section (Pre-Effects Processing) (89-91)
  SIGNALS_CLIP_MODE: 89,
  SIGNALS_DRIVE: 90,
  SIGNALS_TONE: 91,

  // Master Output (92-95)
  MASTER_PAN: 92,
  UNISON_DETUNE: 93,
  FILTER_SLOPE: 94,
  FILTER2_SLOPE: 95
};

// Helper to read theme colors from CSS variables (default to warm palette)
function getRootStyles() {
  if (typeof window === 'undefined' || !document?.documentElement) return null;
  return getComputedStyle(document.documentElement);
}
const THEME_COLOR_VARS = {
  osc1: '--color-osc1',
  osc2: '--color-osc2',
  noise: '--color-noise',
  transient: '--color-transient',
  vcf: '--color-vcf',
  resonator: '--color-resonator',
  master: '--color-master'
};
function readThemeColor(varName, fallback) {
  const styles = getRootStyles();
  if (!styles) return fallback;
  const raw = styles.getPropertyValue(varName);
  const cleaned = raw && raw.trim();
  return cleaned && cleaned.length ? cleaned : fallback;
}

const THEME_COLORS = {
  osc1: readThemeColor('--color-osc1', '255, 40, 40'),
  osc2: readThemeColor('--color-osc2', '255, 96, 32'),
  transient: readThemeColor('--color-transient', '255, 168, 56'),
  noise: readThemeColor('--color-noise', '255, 208, 104'),
  lfo: readThemeColor('--color-lfo', '255, 64, 176'),
  effects: readThemeColor('--color-effects', '255, 96, 64')
};
function resolveCssColor(raw) {
  if (!raw) return null;
  let result = raw.trim();
  if (!result.length) return null;
  const varMatch = result.match(/^var\((--[^)]+)\)$/);
  if (varMatch) {
    const styles = getRootStyles();
    if (!styles) return null;
    const resolved = styles.getPropertyValue(varMatch[1]);
    if (resolved && resolved.trim().length) {
      return resolved.trim();
    }
  }
  return result;
}

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

// ============================================================================
// Center Detent and Option+Click Reset for Bipolar Sliders
// ============================================================================

// Initialize center detent markers for bipolar sliders
function initCenterDetents() {
  const bipolarSliders = document.querySelectorAll('input[type="range"].bipolar');

  bipolarSliders.forEach(slider => {
    // Wrap slider in relative container if not already wrapped
    const parent = slider.parentElement;
    if (!parent.classList.contains('control-with-detent')) {
      const wrapper = document.createElement('div');
      wrapper.className = 'control-with-detent';

      parent.insertBefore(wrapper, slider);
      wrapper.appendChild(slider);

      // Add center detent marker
      const marker = document.createElement('div');
      marker.className = 'center-detent-marker';
      wrapper.appendChild(marker);
    }

    // Add Option+click to reset to center (0)
    slider.addEventListener('mousedown', (e) => {
      if (e.altKey) { // Alt key is Option on Mac
        e.preventDefault();
        const min = parseFloat(slider.min);
        const max = parseFloat(slider.max);

        // Only reset if it's a symmetric bipolar range
        if (min === -max) {
          slider.value = 0;
          // Trigger input event to update display and send to plugin
          slider.dispatchEvent(new Event('input', { bubbles: true }));
        }
      }
    });
  });
}

// Call after DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initCenterDetents);
} else {
  initCenterDetents();
}

// ============================================================================
// Accessibility: auto-populate aria-label from title/labels
// ============================================================================
function ensureAriaLabels() {
  // Buttons and button-like controls
  document.querySelectorAll('button, [role="button"]').forEach(el => {
    if (!el.getAttribute('aria-label')) {
      const title = el.getAttribute('title');
      const text = (el.innerText || '').trim();
      const label = title || text;
      if (label) el.setAttribute('aria-label', label);
    }
  });

  // Range sliders: use nearest visible label text
  document.querySelectorAll('input[type="range"]').forEach(el => {
    if (!el.getAttribute('aria-label')) {
      const control = el.closest('.control');
      const labEl = control && control.querySelector('.control-label > label');
      const label = labEl && labEl.textContent && labEl.textContent.trim();
      if (label) el.setAttribute('aria-label', label);
    }
  });

  // Checkboxes: use wrapping label text (e.g. header-checkbox)
  document.querySelectorAll('input[type="checkbox"]').forEach(el => {
    if (!el.getAttribute('aria-label')) {
      const wrap = el.closest('label');
      const text = wrap && wrap.textContent && wrap.textContent.replace(/\s+/g, ' ').trim();
      if (text) el.setAttribute('aria-label', text);
    }
  });

  // Selects: use existing aria-label or title or placeholder-like text
  document.querySelectorAll('select').forEach(el => {
    if (!el.getAttribute('aria-label')) {
      const title = el.getAttribute('title');
      const aria = el.getAttribute('aria-label');
      if (!aria && title) el.setAttribute('aria-label', title);
    }
  });
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', ensureAriaLabels);
} else {
  ensureAriaLabels();
}

// ============================================================================
// Hide label/value for all controls that contain a toggle-group
// ============================================================================
function hideLabelsForToggleGroups() {
  document.querySelectorAll('.toggle-group').forEach((group) => {
    const control = group.closest('.control');
    if (!control) return;
    const labelWrap = control.querySelector('.control-label');
    // if (labelWrap) {
    // labelWrap.style.display = 'none';
    // }
  });
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', hideLabelsForToggleGroups);
} else {
  hideLabelsForToggleGroups();
}

function setupSectionGroupToggles() {
  const headers = document.querySelectorAll('.grid-header[data-section-group]');
  if (!headers.length) return;

  const sectionFadeMs = 180;
  const groupCollapseMs = 220;
  const groupTimers = new WeakMap();

  const clearGroupTimers = (groupBody) => {
    const timers = groupTimers.get(groupBody);
    if (!timers) return;
    timers.forEach((timer) => clearTimeout(timer));
    groupTimers.delete(groupBody);
  };

  const collapseGroupBody = (groupBody, sections) => {
    clearGroupTimers(groupBody);
    groupBody.classList.add('is-collapsing');
    groupBody.classList.remove('is-expanding');
    sections.forEach((section) => {
      section.classList.remove('is-fade-start');
      section.classList.remove('is-collapsing');
      section.classList.remove('is-collapsed');
    });

    const endTimer = setTimeout(() => {
      groupBody.classList.remove('is-collapsing');
      groupBody.classList.add('is-collapsed');
    }, groupCollapseMs + sectionFadeMs);

    groupTimers.set(groupBody, [endTimer]);
  };

  const expandGroupBody = (groupBody, sections) => {
    clearGroupTimers(groupBody);
    groupBody.classList.remove('is-collapsing');
    groupBody.classList.remove('is-collapsed');
    groupBody.classList.remove('is-expanding');
    groupBody.classList.add('is-expanding');
    sections.forEach((section) => {
      section.classList.remove('is-fade-start');
      section.classList.remove('is-collapsing');
      section.classList.remove('is-collapsed');
    });

    const cleanupTimer = setTimeout(() => {
      groupBody.classList.remove('is-expanding');
    }, groupCollapseMs + sectionFadeMs);

    groupTimers.set(groupBody, [cleanupTimer]);
  };

  window.__groupToggleDurations = { groupCollapseMs, sectionFadeMs };
  window.__expandGroupForTarget = (targetEl) => {
    if (!targetEl) return false;
    const groupEl = targetEl.closest('.grid-group');
    if (!groupEl) return false;
    const groupBody = groupEl.querySelector('.grid-group-body');
    if (!groupBody) return false;
    if (!groupBody.classList.contains('is-collapsed')) return false;
    const sections = [...groupBody.querySelectorAll('.section')];
    if (!sections.length) return false;
    expandGroupBody(groupBody, sections);
    return true;
  };

  headers.forEach((header) => {
    if (header.dataset.toggleBound === 'true') return;
    const group = header.dataset.sectionGroup;
    if (!group) return;

    const groupEl = header.closest('.grid-group');
    const groupBody = groupEl ? groupEl.querySelector('.grid-group-body') : null;
    if (!groupBody) return;
    const sections = [...groupBody.querySelectorAll('.section')];
    if (!sections.length) return;

    header.classList.add('is-toggleable');
    header.dataset.toggleBound = 'true';
    header.setAttribute('role', 'button');
    header.setAttribute('tabindex', '0');

    const applyState = (collapsed, skipAnimation = false) => {
      header.classList.toggle('is-collapsed', collapsed);
      header.setAttribute('aria-expanded', collapsed ? 'false' : 'true');
      if (skipAnimation) {
        groupBody.classList.toggle('is-collapsed', collapsed);
        groupBody.classList.remove('is-collapsing');
        groupBody.classList.remove('is-expanding');
        sections.forEach((section) => {
          section.classList.remove('is-fade-start');
          section.classList.remove('is-collapsing');
          section.classList.remove('is-collapsed');
        });
        return;
      }
      if (collapsed) {
        collapseGroupBody(groupBody, sections);
      } else {
        expandGroupBody(groupBody, sections);
      }
    };

    const initialCollapsed = header.getAttribute('data-collapsed') === 'true';
    applyState(initialCollapsed, true);

    const toggle = () => {
      if (groupBody.classList.contains('is-collapsing')) return;
      if (sections.some((section) => section.classList.contains('is-collapsing'))) return;
      applyState(!header.classList.contains('is-collapsed'));
    };

    header.addEventListener('click', (event) => {
      if (event.target.closest('a,button,input,select,textarea')) return;
      toggle();
    });
    header.addEventListener('keydown', (event) => {
      if (event.key !== 'Enter' && event.key !== ' ') return;
      event.preventDefault();
      toggle();
    });
  });
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', setupSectionGroupToggles);
} else {
  setupSectionGroupToggles();
}

// ============================================================================
// Inline editing of displayed values (double-click)
// ============================================================================
function initInlineValueEditing() {
  const values = document.querySelectorAll('.control .value');
  values.forEach((valEl) => {
    valEl.addEventListener('dblclick', (e) => {
      e.preventDefault();
      const displayId = valEl.id || '';
      if (!displayId.endsWith('-val')) return;
      const sliderId = displayId.slice(0, -4); // remove '-val'
      const slider = document.getElementById(sliderId);
      if (!slider || slider.tagName !== 'INPUT' || slider.type !== 'range') return;

      const originalHTML = valEl.innerHTML;
      const originalWidth = valEl.clientWidth;
      const originalHeight = valEl.clientHeight;
      const min = parseFloat(slider.min || '0');
      const max = parseFloat(slider.max || '100');
      const step = parseFloat(slider.step || '1');
      const current = parseFloat(slider.value);

      const input = document.createElement('input');
      input.type = 'number';
      input.min = String(min);
      input.max = String(max);
      input.step = String(step);
      input.value = String(current);
      input.className = 'inline-number';
      // stabilize container size to avoid flicker
      if (originalWidth) valEl.style.width = originalWidth + 'px';
      if (originalHeight) valEl.style.height = originalHeight + 'px';

      // Keep unit if present
      const unitEl = valEl.querySelector('.unit');
      valEl.textContent = '';
      valEl.appendChild(input);
      if (unitEl) {
        const u = document.createElement('span');
        u.className = 'unit';
        u.textContent = unitEl.textContent;
        u.style.marginLeft = '2px';
        valEl.appendChild(u);
      }

      const commit = () => {
        let v = parseFloat(input.value);
        if (Number.isNaN(v)) { cancel(); return; }
        v = Math.min(max, Math.max(min, v));
        slider.value = String(v);
        slider.dispatchEvent(new Event('input', { bubbles: true }));
        // restore display; the input handler should also update text
        valEl.innerHTML = originalHTML;
        valEl.style.width = '';
        valEl.style.height = '';
      };
      const cancel = () => {
        valEl.innerHTML = originalHTML;
        valEl.style.width = '';
        valEl.style.height = '';
      };

      input.addEventListener('keydown', (ev) => {
        if (ev.key === 'Enter') { ev.preventDefault(); commit(); }
        else if (ev.key === 'Escape') { ev.preventDefault(); cancel(); }
        else if (ev.key === 'ArrowUp') { ev.preventDefault(); input.stepUp(); }
        else if (ev.key === 'ArrowDown') { ev.preventDefault(); input.stepDown(); }
        else if (ev.key === 'ArrowRight') { ev.preventDefault(); input.stepUp(); }
        else if (ev.key === 'ArrowLeft') { ev.preventDefault(); input.stepDown(); }
      });
      input.addEventListener('blur', commit);
      input.focus(); input.select();
    });
  });
}

// Replace inline editing with popover editor
function initValuePopoverEditing() {
  const values = document.querySelectorAll('.control .value');
  let current = null;
  const close = () => { if (current && current.remove) current.remove(); current = null; document.removeEventListener('keydown', onKey); document.removeEventListener('mousedown', onDoc, true); };
  const onKey = (e) => { if (e.key === 'Escape') { e.preventDefault(); close(); } };
  const onDoc = (e) => { if (current && !current.contains(e.target)) close(); };
  values.forEach(valEl => {
    valEl.addEventListener('dblclick', (e) => {
      e.preventDefault();
      const id = valEl.id || ''; if (!id.endsWith('-val')) return;
      const slider = document.getElementById(id.slice(0, -4)); if (!slider || slider.type !== 'range') return;
      close();
      const pop = document.createElement('div'); pop.className = 'value-popover';
      const min = parseFloat(slider.min || '0'); const max = parseFloat(slider.max || '100'); const step = parseFloat(slider.step || '1');
      const input = document.createElement('input'); input.type = 'number'; input.min = String(min); input.max = String(max); input.step = String(step); input.value = slider.value;
      const ok = document.createElement('button'); ok.className = 'btn'; ok.title = 'Apply'; ok.innerHTML = '<span class="fukiai">&#xEA0D;</span>';
      const cancel = document.createElement('button'); cancel.className = 'btn'; cancel.title = 'Cancel'; cancel.innerHTML = '<span class="fukiai">&#xEA0E;</span>';
      pop.appendChild(input); pop.appendChild(ok); pop.appendChild(cancel); document.body.appendChild(pop); current = pop;
      const rect = valEl.getBoundingClientRect(); const top = Math.max(8, rect.top - pop.offsetHeight - 8); const left = Math.min(window.innerWidth - pop.offsetWidth - 8, Math.max(8, rect.left));
      pop.style.top = top + 'px'; pop.style.left = left + 'px';
      const commit = () => { const v = parseFloat(input.value); if (Number.isNaN(v) || v < min || v > max) { close(); return; } slider.value = String(v); slider.dispatchEvent(new Event('input', { bubbles: true })); close(); };
      ok.addEventListener('click', commit); cancel.addEventListener('click', close); input.addEventListener('keydown', ev => { if (ev.key === 'Enter') { ev.preventDefault(); commit(); } });
      requestAnimationFrame(() => { input.focus(); input.select(); });
      document.addEventListener('keydown', onKey); document.addEventListener('mousedown', onDoc, true);
    });
  });
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initValuePopoverEditing);
} else {
  initValuePopoverEditing();
}

// ============================================================================
// LFO Musical Rate Options (for tempo sync)
// ============================================================================

const musicalRateOptions = [
  { label: '32 bars', hz: 0.03125 },
  { label: '16 bars', hz: 0.0625 },
  { label: '8 bars', hz: 0.125 },
  { label: '4 bars', hz: 0.25 },
  { label: '2 bars', hz: 0.5 },
  { label: '1 bar', hz: 1 },
  { label: '1/2', hz: 2 },
  { label: '1/4', hz: 4 },
  { label: '1/8', hz: 8 },
  { label: '1/16', hz: 16 },
  { label: '1/16t', hz: 24 },
  { label: '1/32', hz: 32 }
].sort((a, b) => a.hz - b.hz);

// Add or remove detent markers for a slider
function updateDetentMarkers(slider, showDetents) {
  let parent = slider.parentElement;
  if (!parent) return;

  // Ensure the slider sits inside a positioned wrapper so the detents can overlay the track
  if (!parent.classList.contains('control-with-detent')) {
    const wrapper = document.createElement('div');
    wrapper.className = 'control-with-detent';
    parent.insertBefore(wrapper, slider);
    wrapper.appendChild(slider);
    parent = wrapper;
  }

  // Remove existing detent container
  const existingContainer = parent.querySelector('.detent-container');
  if (existingContainer) {
    existingContainer.remove();
  }

  if (showDetents) {
    // Create detent container
    const container = document.createElement('div');
    container.className = 'detent-container';

    // Add detent markers for each musical rate option
    const count = musicalRateOptions.length;

    for (let i = 0; i < count; i++) {
      const marker = document.createElement('div');
      marker.className = 'tempo-detent-marker';
      container.appendChild(marker);
    }

    parent.appendChild(container);
  }
}

// ============================================================================
// Helper Functions
// ============================================================================

// Normalize value to 0-1 range
function normalize(value, min, max) {
  return (value - min) / (max - min);
}

// Denormalize from 0-1 to actual range
function denormalize(normalized, min, max) {
  return min + normalized * (max - min);
}

// Logarithmic scale for frequency/time parameters
function logScale(value, min, max) {
  const minLog = Math.log(min);
  const maxLog = Math.log(max);
  return Math.exp(minLog + value * (maxLog - minLog));
}

// Inverse log scale (convert Hz to 0-1)
function invLogScale(value, min, max) {
  const minLog = Math.log(min);
  const maxLog = Math.log(max);
  return (Math.log(value) - minLog) / (maxLog - minLog);
}

// ============================================================================
// Range progress helper (global)
// ============================================================================
function setRangeProgress(slider) {
  if (!slider) return;
  const min = Number(slider.min || 0);
  const max = Number(slider.max || 100);
  const val = Number(slider.value || 0);
  const pct = ((val - min) / (max - min)) * 100;
  const clamped = Math.max(0, Math.min(100, pct));
  slider.style.setProperty('--progress', `${clamped}%`);

  if (slider.classList.contains('bipolar')) {
    // Bipolar slider: progress from center (50%) to current value
    if (clamped >= 50) {
      slider.style.setProperty('--progress-start', '50%');
      slider.style.setProperty('--progress-end', `${clamped}%`);
    } else {
      slider.style.setProperty('--progress-start', `${clamped}%`);
      slider.style.setProperty('--progress-end', '50%');
    }
  } else {
    // Unipolar slider: progress from 0% to current value
    slider.style.setProperty('--progress-start', '0%');
    slider.style.setProperty('--progress-end', `${clamped}%`);
  }

  // Debug: Log master-vol updates
  if (slider.id === 'master-vol') {
    const stack = new Error().stack.split('\n').slice(1, 3).join('\n');
    console.log(`[setRangeProgress] master-vol: value=${val} → --progress-end="${clamped}%"`);
    console.log(`  Called from: ${stack}`);
  }
}

// ============================================================================
// Sliding Toggle Group (dynamic active indicator)
// ============================================================================

class SlidingToggleGroup {
  constructor(root, { onChange } = {}) {
    this.root = root;
    this.indicator = root.querySelector('.active-indicator');
    if (!this.indicator) {
      this.indicator = document.createElement('div');
      this.indicator.className = 'active-indicator';
      this.root.insertBefore(this.indicator, this.root.firstChild);
    }
    this.buttons = Array.from(root.querySelectorAll('button'));
    this.vertical = root.classList.contains('vertical');
    this.onChange = onChange;
    this.selectedIndex = -1;

    this.buttons.forEach((btn, idx) => {
      btn.addEventListener('click', () => this.selectByIndex(idx));
    });

    // Initialize selection
    const presetIndex = this.buttons.findIndex(b => b.classList.contains('active') || b.classList.contains('is-active') || b.getAttribute('aria-pressed') === 'true');
    this.selectByIndex(presetIndex >= 0 ? presetIndex : 0, false);

    // Handle layout changes
    this._onResize = () => this._updateIndicator();
    window.addEventListener('resize', this._onResize);
  }

  _updateIndicator() {
    if (this.selectedIndex < 0) return;
    const btn = this.buttons[this.selectedIndex];
    const g = this.root.getBoundingClientRect();
    const b = btn.getBoundingClientRect();
    const inset = 4;
    if (this.vertical) {
      const y = b.top - g.top - inset;
      const h = b.height;
      this.indicator.style.height = `${h}px`;
      this.indicator.style.transform = `translateY(${Math.max(0, y)}px)`;
      this.indicator.style.width = `calc(100% - ${inset * 2}px)`;
    } else {
      const x = b.left - g.left - inset;
      const w = b.width;
      this.indicator.style.width = `${w}px`;
      this.indicator.style.transform = `translateX(${Math.max(0, x)}px)`;
      this.indicator.style.height = `calc(100% - ${inset * 2}px)`;
    }
  }

  selectByIndex(index, emit = true) {
    if (index < 0 || index >= this.buttons.length) return;
    this.selectedIndex = index;
    this.buttons.forEach((b, i) => {
      const active = i === index;
      b.classList.toggle('is-active', active);
      b.classList.toggle('active', active); // maintain legacy .active styles
    });
    this._updateIndicator();
    if (emit && this.onChange) {
      const btn = this.buttons[index];
      const value = btn?.dataset?.value ?? index;
      this.onChange(String(value), index, btn);
    }
  }
}

// Global registry for sliding groups
window.__toggleGroups = {};

// ============================================================================
// Bridge Communication
// ============================================================================

// Send parameter to C++ DSP engine
function sendParam(paramIdx, normalizedValue) {
  // Skip if we're updating from plugin (prevent circular updates)
  if (isUpdatingFromPlugin) {
    return false;
  }

  // Debug: log ALL parameter sends
  if (paramIdx === 84) {
    console.error(`🚨 SEND TRANSIENT_MODE: paramIdx=${paramIdx}, value=${normalizedValue}`);
  }
  try {
    if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.callback) {
      window.webkit.messageHandlers.callback.postMessage({
        msg: 'SPVFUI',
        paramIdx: paramIdx,
        value: normalizedValue
      });
      if (paramIdx === 84) {
        console.error(`✅ TRANSIENT_MODE sent successfully`);
      }
      return true;
    } else {
      console.warn('iPlug2 bridge not available');
      return false;
    }
  } catch (e) {
    console.error('Failed to send parameter:', e);
    return false;
  }
}

// Send wavetable data to C++ DSP engine (global wavetable slot)
// slotIndex: 0-3 (wavetable slot index, shared between OSC1 and OSC2)
// samples: Float32Array or Array of 2048 samples (normalized -1 to 1)
function sendWavetable(cppSlot, samples) {
  try {
    if (!samples || samples.length !== 2048) {
      console.error('Invalid wavetable: must be 2048 samples');
      return false;
    }

    // Convert to regular array if Float32Array
    const samplesArray = Array.isArray(samples) ? samples : Array.from(samples);

    if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.callback) {
      window.webkit.messageHandlers.callback.postMessage({
        msg: 'SCMFUI',
        ctrlTag: 'WAVETABLE_DATA',
        slot: cppSlot,  // 0=Osc1A, 1=Osc1B, 2=Osc2A, 3=Osc2B
        data: samplesArray
      });
      console.log(`Sent wavetable data to C++ slot ${cppSlot} (${samplesArray.length} samples)`);
      return true;
    } else {
      console.warn('iPlug2 bridge not available');
      return false;
    }
  } catch (e) {
    console.error('Failed to send wavetable:', e);
    return false;
  }
}

// Flag to prevent circular updates (C++ → UI → C++)
let isUpdatingFromPlugin = false;

// Receive parameter updates from C++ (called by iPlug2)
// This is called when parameters change from DAW automation, presets, etc.
// SPVFD = SendParameterValueFromDelegate (iPlug2 abbreviation)
window.SPVFD = function (paramIdx, normalizedValue) {
  // Store parameter value for preset capture
  window.__parameterValues[paramIdx] = normalizedValue;

  // Set flag to prevent sending back to C++
  isUpdatingFromPlugin = true;
  // Helper to update slider and display
  const updateSlider = (sliderId, displayId, value, formatter) => {
    const slider = document.getElementById(sliderId);
    const display = document.getElementById(displayId);
    // In LFO sync mode, avoid forcing free-Hz normalized values into step sliders
    if ((sliderId === 'lfo1-rate' && typeof lfo1Sync !== 'undefined' && lfo1Sync) ||
      (sliderId === 'lfo2-rate' && typeof lfo2Sync !== 'undefined' && lfo2Sync)) {
      if (display && formatter) display.innerHTML = formatter(value);
      return;
    }
    if (slider) {
      slider.value = value;
      // keep progress fill in sync
      const min = Number(slider.min || 0);
      const max = Number(slider.max || 100);
      const pct = ((Number(value) - min) / (max - min)) * 100;
      slider.style.setProperty('--progress', `${Math.max(0, Math.min(100, pct))}%`);
    }
    if (display && formatter) display.innerHTML = formatter(value);
  };

  // Helper for toggle groups
  const updateToggleGroup = (groupId, buttonIndex) => {
    // Prefer sliding toggle group instance if available
    const instance = window.__toggleGroups && window.__toggleGroups[groupId];
    if (instance && typeof instance.selectByIndex === 'function') {
      instance.selectByIndex(buttonIndex, false);
      return;
    }
    // Fallback: legacy class toggle
    const group = document.getElementById(groupId);
    if (!group) return;
    const buttons = group.querySelectorAll('.toggle-btn');
    buttons.forEach((btn, idx) => btn.classList.toggle('active', idx === buttonIndex));
  };

  switch (paramIdx) {
    // === OSC 1 ===
    case Params.OSC1_WAVE: {
      const waveIndex = Math.round(denormalize(normalizedValue, 0, 15));
      updateToggleGroup('osc1-wave-group', waveIndex);
      break;
    }
    case Params.OSC1_SEMI: {
      const semi = Math.round(denormalize(normalizedValue, -24, 24));
      updateSlider('osc1-semi', 'osc1-semi-val', semi, v => (v >= 0 ? '+' : '') + v);
      // OSC2_SEMI is linked to OSC1_SEMI (DETUNE mode)
      updateSlider('osc2-semi', 'osc2-semi-val', semi, v => (v >= 0 ? '+' : '') + v);
      break;
    }
    case Params.OSC1_FINE: {
      const cents = Math.round(denormalize(normalizedValue, -100, 100));
      updateSlider('osc1-fine', 'osc1-fine-val', cents, v => (v >= 0 ? '+' : '') + v);
      break;
    }
    case Params.OSC1_LEVEL: {
      const pct = Math.round(normalizedValue * 100);
      updateSlider('osc1-level', 'osc1-level-val', pct, v => `${v}<span class="unit">%</span>`);
      break;
    }
    case Params.OSC1_SYNC: {
      const syncCheckbox = document.getElementById('osc1-sync');
      if (syncCheckbox) syncCheckbox.checked = normalizedValue > 0.5;
      break;
    }
    case Params.OSC1_COMPOUND: {
      const modeIndex = Math.round(denormalize(normalizedValue, 0, 3));
      const modeNames = ['fade', 'phase', 'multiply', 'mask'];
      updateToggleGroup('osc1-comp-group', modeIndex);
      if (window.osc1Showcase) {
        window.osc1Showcase.compoundMode = modeNames[modeIndex] || 'fade';
        window.osc1Showcase.updateDisplay();
      }
      break;
    }
    case Params.OSC1_CLIP_MODE: {
      const modeIndex = Math.round(denormalize(normalizedValue, 0, 2));
      const modeNames = ['limit', 'fold', 'loop'];
      updateToggleGroup('osc1-clip-toggle', modeIndex);
      if (window.osc1Showcase) {
        window.osc1Showcase.clipMode = modeNames[modeIndex] || 'limit';
        window.osc1Showcase.updateDisplay();
      }
      break;
    }

    // === OSC 2 ===
    case Params.OSC2_WAVE: {
      const waveIndex = Math.round(denormalize(normalizedValue, 0, 15));
      updateToggleGroup('osc2-wave-group', waveIndex);
      break;
    }
    case Params.OSC2_SEMI: {
      const semi = Math.round(denormalize(normalizedValue, -24, 24));
      updateSlider('osc2-semi', 'osc2-semi-val', semi, v => (v >= 0 ? '+' : '') + v);
      break;
    }
    case Params.OSC2_FINE: {
      const cents = Math.round(denormalize(normalizedValue, -100, 100));
      updateSlider('osc2-fine', 'osc2-fine-val', cents, v => (v >= 0 ? '+' : '') + v);
      break;
    }
    case Params.OSC2_LEVEL: {
      const pct = Math.round(normalizedValue * 100);
      updateSlider('osc2-level', 'osc2-level-val', pct, v => `${v}<span class="unit">%</span>`);
      break;
    }
    case Params.OSC2_DETUNE: {
      const cents = Math.round(denormalize(normalizedValue, -100, 100));
      updateSlider('osc2-detune', 'osc2-detune-val', cents, v => (v >= 0 ? '+' : '') + v);

      // Update DETUNE checkbox state
      const detuneCheckbox = document.getElementById('osc2-detune');
      if (detuneCheckbox) {
        const isDetune = normalizedValue > 0.5;  // Treat as boolean
        detuneCheckbox.checked = isDetune;

        // Disable OSC2 Semi slider when in DETUNE mode
        const osc2SemiSlider = document.getElementById('osc2-semi');
        if (osc2SemiSlider) {
          osc2SemiSlider.disabled = isDetune;
        }
      }
      break;
    }
    case Params.OSC2_COMPOUND: {
      const modeIndex = Math.round(denormalize(normalizedValue, 0, 3));
      const modeNames = ['fade', 'phase', 'multiply', 'mask'];
      updateToggleGroup('osc2-comp-group', modeIndex);
      if (window.osc2Showcase) {
        window.osc2Showcase.compoundMode = modeNames[modeIndex] || 'fade';
        window.osc2Showcase.updateDisplay();
      }
      break;
    }
    case Params.OSC2_CLIP_MODE: {
      const modeIndex = Math.round(denormalize(normalizedValue, 0, 2));
      const modeNames = ['limit', 'fold', 'loop'];
      updateToggleGroup('osc2-clip-toggle', modeIndex);
      if (window.osc2Showcase) {
        window.osc2Showcase.clipMode = modeNames[modeIndex] || 'limit';
        window.osc2Showcase.updateDisplay();
      }
      break;
    }

    // === NOISE/OSC3 ===
    case Params.NOISE_TYPE: {
      const noiseType = Math.round(denormalize(normalizedValue, 0, 2));
      updateToggleGroup('noise-type-group', noiseType);
      if (window.noiseViz) window.noiseViz.setType(noiseType);
      // Update label/value presentation for variant slider
      const label = document.getElementById('noise-variant-label');
      const val = document.getElementById('noise-variant-val');
      const slider = document.getElementById('noise-variant');
      if (label && val && slider) {
        if (noiseType === 0) { // Analog
          label.textContent = 'Color';
          val.textContent = (slider.value / 100).toFixed(2);
        } else if (noiseType === 1) { // Digital
          label.textContent = 'Resolution';
          const bits = 3 + Math.round((slider.value / 100) * 7);
          val.textContent = bits + ' bit';
        } else { // Arcade
          label.textContent = 'Length';
          const length = 2 + Math.round((parseInt(slider.value) / 100) * 14);
          val.textContent = length.toString();
        }
      }
      break;
    }
    case Params.NOISE_LEVEL: {
      const pct = Math.round(normalizedValue * 100);
      updateSlider('noise-level', 'noise-level-val', pct, v => `${v}<span class="unit">%</span>`);
      if (window.noiseViz) window.noiseViz.setLevel(normalizedValue);
      break;
    }
    case Params.NOISE_VARIANT: {
      const slider = document.getElementById('noise-variant');
      const label = document.getElementById('noise-variant-label');
      const val = document.getElementById('noise-variant-val');
      if (slider && label && val) {
        const v = Math.round(normalizedValue * 100);
        slider.value = v;
        if (window.noiseViz) window.noiseViz.setVariant(v / 100);
        const typeGroup = document.getElementById('noise-type-group');
        const idx = typeGroup ? [...typeGroup.querySelectorAll('.toggle-btn')].findIndex(b => b.classList.contains('is-active') || b.classList.contains('active')) : 0;
        if (idx === 1) {
          const bits = 3 + Math.round((v / 100) * 7);
          val.textContent = bits + ' bit';
        } else if (idx === 2) {
          const mode = (v < 50) ? 1 : 2; // two modes only
          val.textContent = mode.toString();
        } else {
          val.textContent = (v / 100).toFixed(2);
        }
      }
      break;
    }

    // === FILTER A ===
    case Params.FILTER_1_TYPE: {
      const filterType = Math.round(denormalize(normalizedValue, 0, 5));
      updateToggleGroup('filter-type-group', filterType);
      const typeNames = ['LP', 'HP', 'BP', 'Notch', 'Transistor', 'Acid'];
      const display = document.getElementById('filter-type-val');
      if (display) display.textContent = typeNames[filterType] || 'LP';
      if (window.filter1Viz) window.filter1Viz.setType(filterType >= 4 ? 0 : filterType);
      break;
    }
    case Params.FILTER_1_CUTOFF: {
      const freq = logScale(normalizedValue, 20, 20000);
      updateSlider('filter-cutoff', 'filter-cutoff-val', normalizedValue * 100,
        () => freq < 1000 ? `${Math.round(freq)}<span class="unit">Hz</span>`
          : `${(freq / 1000).toFixed(2)}<span class="unit">kHz</span>`);
      break;
    }
    case Params.FILTER_1_RESO: {
      const pct = Math.round(normalizedValue * 100);
      updateSlider('filter-reso', 'filter-reso-val', pct, v => `${v}<span class="unit">%</span>`);
      break;
    }
    case Params.FILTER_1_DRIVE: {
      const db = denormalize(normalizedValue, 0, 24);
      updateSlider('filter-drive', 'filter-drive-val', normalizedValue * 100,
        () => `${db.toFixed(1)}<span class="unit">dB</span>`);
      break;
    }

    // === FILTER B ===
    case Params.FILTER_2_TYPE: {
      const filterType = Math.round(denormalize(normalizedValue, 0, 5));
      // Correct group id to match HTML
      updateToggleGroup('filter2-type-group', filterType);
      const typeNames = ['LP', 'HP', 'BP', 'Notch', 'Ladder', 'Acid'];
      const display = document.getElementById('filter2-type-val');
      if (display) display.textContent = typeNames[filterType] || 'LP';
      if (window.filter2Viz) window.filter2Viz.setType(filterType >= 4 ? 0 : filterType);
      break;
    }
    case Params.FILTER_2_CUTOFF: {
      const freq = logScale(normalizedValue, 20, 20000);
      updateSlider('filter2-cutoff', 'filter2-cutoff-val', normalizedValue * 100,
        () => freq < 1000 ? `${Math.round(freq)}<span class="unit">Hz</span>`
          : `${(freq / 1000).toFixed(2)}<span class="unit">kHz</span>`);
      break;
    }
    case Params.FILTER_2_RESO: {
      const pct = Math.round(normalizedValue * 100);
      updateSlider('filter2-reso', 'filter2-reso-val', pct, v => `${v}<span class="unit">%</span>`);
      break;
    }
    case Params.FILTER_2_DRIVE: {
      const db = denormalize(normalizedValue, 0, 24);
      updateSlider('filter2-drive', 'filter2-drive-val', normalizedValue * 100,
        () => `${db.toFixed(1)}<span class="unit">dB</span>`);
      break;
    }

    // === ENV 1 ===
    case Params.ENV1_ATTACK: {
      const ms = logScale(normalizedValue, 1, 5000);
      const seconds = clamp(ms / 1000, 0.001, 5);
      const uiNorm = clamp(invLogScale(seconds, 0.001, 5), 0, 1);
      updateSlider('env1-attack', 'env1-attack-val', uiNorm * 100,
        () => ms < 1000 ? `${Math.round(ms)}<span class="unit">ms</span>`
          : `${(ms / 1000).toFixed(2)}<span class="unit">s</span>`);
      if (window.env1Viz) window.env1Viz.setAttack(ms);
      break;
    }
    case Params.ENV1_DECAY: {
      const ms = logScale(normalizedValue, 1, 5000);
      const seconds = clamp(ms / 1000, 0.001, 5);
      const uiNorm = clamp(invLogScale(seconds, 0.001, 5), 0, 1);
      updateSlider('env1-decay', 'env1-decay-val', uiNorm * 100,
        () => ms < 1000 ? `${Math.round(ms)}<span class="unit">ms</span>`
          : `${(ms / 1000).toFixed(2)}<span class="unit">s</span>`);
      if (window.env1Viz) window.env1Viz.setDecay(ms);
      break;
    }
    case Params.ENV1_SUSTAIN: {
      const pct = Math.round(normalizedValue * 100);
      updateSlider('env1-sustain', 'env1-sustain-val', pct, v => `${v}<span class="unit">%</span>`);
      break;
    }
    case Params.ENV1_RELEASE: {
      const ms = logScale(normalizedValue, 1, 5000);
      const seconds = clamp(ms / 1000, 0.001, 5);
      const uiNorm = clamp(invLogScale(seconds, 0.001, 5), 0, 1);
      updateSlider('env1-release', 'env1-release-val', uiNorm * 100,
        () => ms < 1000 ? `${Math.round(ms)}<span class="unit">ms</span>`
          : `${(ms / 1000).toFixed(2)}<span class="unit">s</span>`);
      if (window.env1Viz) window.env1Viz.setRelease(ms);
      break;
    }
    case Params.ENV1_CURVE: {
      const pct = Math.round(normalizedValue * 100);
      updateSlider('env1-curve', 'env1-curve-val', pct, v => `${v}<span class="unit">%</span>`);
      break;
    }
    case Params.ENV1_LEVEL: {
      const pct = Math.round(normalizedValue * 100);
      updateSlider('env1-level', 'env1-level-val', pct, v => `${v}<span class="unit">%</span>`);
      break;
    }

    // === ENV 2 ===
    case Params.ENV2_ATTACK: {
      const ms = logScale(normalizedValue, 1, 5000);
      const seconds = clamp(ms / 1000, 0.001, 5);
      const uiNorm = clamp(invLogScale(seconds, 0.001, 5), 0, 1);
      updateSlider('env2-attack', 'env2-attack-val', uiNorm * 100,
        () => ms < 1000 ? `${Math.round(ms)}<span class="unit">ms</span>`
          : `${(ms / 1000).toFixed(2)}<span class="unit">s</span>`);
      if (window.env2Viz) window.env2Viz.setAttack(ms);
      break;
    }
    case Params.ENV2_DECAY: {
      const ms = logScale(normalizedValue, 1, 5000);
      const seconds = clamp(ms / 1000, 0.001, 5);
      const uiNorm = clamp(invLogScale(seconds, 0.001, 5), 0, 1);
      updateSlider('env2-decay', 'env2-decay-val', uiNorm * 100,
        () => ms < 1000 ? `${Math.round(ms)}<span class="unit">ms</span>`
          : `${(ms / 1000).toFixed(2)}<span class="unit">s</span>`);
      if (window.env2Viz) window.env2Viz.setDecay(ms);
      break;
    }
    case Params.ENV2_SUSTAIN: {
      const pct = Math.round(normalizedValue * 100);
      updateSlider('env2-sustain', 'env2-sustain-val', pct, v => `${v}<span class="unit">%</span>`);
      break;
    }
    case Params.ENV2_RELEASE: {
      const ms = logScale(normalizedValue, 1, 5000);
      const seconds = clamp(ms / 1000, 0.001, 5);
      const uiNorm = clamp(invLogScale(seconds, 0.001, 5), 0, 1);
      updateSlider('env2-release', 'env2-release-val', uiNorm * 100,
        () => ms < 1000 ? `${Math.round(ms)}<span class="unit">ms</span>`
          : `${(ms / 1000).toFixed(2)}<span class="unit">s</span>`);
      if (window.env2Viz) window.env2Viz.setRelease(ms);
      break;
    }
    case Params.ENV2_CURVE: {
      const pct = Math.round(normalizedValue * 100);
      updateSlider('env2-curve', 'env2-curve-val', pct, v => `${v}<span class="unit">%</span>`);
      break;
    }
    case Params.ENV2_LEVEL: {
      const pct = Math.round(normalizedValue * 100);
      updateSlider('env2-level', 'env2-level-val', pct, v => `${v}<span class="unit">%</span>`);
      break;
    }

    // === LFO 1 ===
    case Params.LFO1_WAVE: {
      const waveIndex = Math.round(denormalize(normalizedValue, 0, 5));
      updateToggleGroup('lfo1-wave-group', waveIndex);
      if (window.lfo1Viz) window.lfo1Viz.setWave(waveIndex);
      break;
    }
    case Params.LFO1_RATE: {
      const hz = logScale(normalizedValue, 0.01, 20);
      updateSlider('lfo1-rate', 'lfo1-rate-val', normalizedValue * 100,
        () => `${hz.toFixed(2)}<span class="unit">Hz</span>`);
      if (window.lfo1Viz) window.lfo1Viz.setRate(normalizedValue);
      break;
    }
    case Params.LFO1_SHAPE: {
      const pct = Math.round(normalizedValue * 100);
      updateSlider('lfo1-shape', 'lfo1-shape-val', pct, v => `${v}<span class="unit">%</span>`);
      break;
    }
    case Params.LFO1_DEPTH: {
      const pct = Math.round(normalizedValue * 100);
      updateSlider('lfo1-depth', 'lfo1-depth-val', pct, v => `${v}<span class="unit">%</span>`);
      if (window.lfo1Viz) window.lfo1Viz.setDepth(normalizedValue);
      break;
    }
    case Params.LFO1_SYNC: {
      const syncCheckbox = document.getElementById('lfo1-sync');
      if (syncCheckbox) syncCheckbox.checked = normalizedValue > 0.5;
      break;
    }
    // Note: LFO1 Delay has no bound parameter; handled in UI only

    // === LFO 2 ===
    case Params.LFO2_WAVE: {
      const waveIndex = Math.round(denormalize(normalizedValue, 0, 5));
      updateToggleGroup('lfo2-wave-group', waveIndex);
      if (window.lfo2Viz) window.lfo2Viz.setWave(waveIndex);
      break;
    }
    case Params.LFO2_RATE: {
      const hz = logScale(normalizedValue, 0.01, 20);
      updateSlider('lfo2-rate', 'lfo2-rate-val', normalizedValue * 100,
        () => `${hz.toFixed(2)}<span class="unit">Hz</span>`);
      if (window.lfo2Viz) window.lfo2Viz.setRate(normalizedValue);
      break;
    }
    case Params.LFO2_SHAPE: {
      const pct = Math.round(normalizedValue * 100);
      updateSlider('lfo2-shape', 'lfo2-shape-val', pct, v => `${v}<span class="unit">%</span>`);
      break;
    }
    case Params.LFO2_DEPTH: {
      const pct = Math.round(normalizedValue * 100);
      updateSlider('lfo2-depth', 'lfo2-depth-val', pct, v => `${v}<span class="unit">%</span>`);
      break;
    }
    case Params.LFO2_SYNC: {
      const syncCheckbox = document.getElementById('lfo2-sync');
      if (syncCheckbox) syncCheckbox.checked = normalizedValue > 0.5;
      break;
    }
    // Note: LFO2 Delay has no bound parameter; handled in UI only

    // === DELAY ===
    case Params.DELAY_TIME: {
      const ms = logScale(normalizedValue, 1, 2000);
      updateSlider('delay-time', 'delay-time-val', normalizedValue * 100,
        () => ms < 1000 ? `${Math.round(ms)}<span class="unit">ms</span>`
          : `${(ms / 1000).toFixed(2)}<span class="unit">s</span>`);
      const fb = (document.getElementById('delay-feedback') ? parseInt(document.getElementById('delay-feedback').value) / 100 : 0.3);
      const mix = (document.getElementById('delay-mix') ? parseInt(document.getElementById('delay-mix').value) / 100 : 0.2);
      const c1 = document.getElementById('delay-graph'); if (c1) drawDelayGraph(c1, normalizedValue, fb, mix, THEME_COLORS.effects);
      break;
    }
    case Params.DELAY_FEEDBACK: {
      const pct = Math.round(normalizedValue * 100);
      updateSlider('delay-feedback', 'delay-feedback-val', pct, v => `${v}<span class="unit">%</span>`);
      const tnorm = (document.getElementById('delay-time') ? parseInt(document.getElementById('delay-time').value) / 100 : 0.25);
      const mix = (document.getElementById('delay-mix') ? parseInt(document.getElementById('delay-mix').value) / 100 : 0.2);
      const c2 = document.getElementById('delay-graph'); if (c2) drawDelayGraph(c2, tnorm, normalizedValue, mix, THEME_COLORS.effects);
      break;
    }
    case Params.DELAY_MIX: {
      // Bipolar: normalized 0-1 → actual -1 to +1
      const bipolar = (normalizedValue * 2.0) - 1.0;
      const pct = Math.round(bipolar * 100);
      const sliderValue = pct;  // Slider is now -100 to +100 (bipolar)
      updateSlider('delay-mix', 'delay-mix-val', sliderValue, v => {
        const sign = pct >= 0 ? '+' : '';
        return `${sign}${pct}<span class="unit">%</span>`;
      });
      break;
    }
    case Params.DELAY_SYNC: {
      const syncCheckbox = document.getElementById('delay-sync');
      if (syncCheckbox) syncCheckbox.checked = normalizedValue > 0.5;
      break;
    }

    // === CHORUS ===
    case Params.CHORUS_RATE: {
      const hz = logScale(normalizedValue, 0.1, 10);
      updateSlider('chorus-rate', 'chorus-rate-val', normalizedValue * 100,
        () => `${hz.toFixed(2)}<span class="unit">Hz</span>`);
      const depth = (document.getElementById('chorus-depth') ? parseInt(document.getElementById('chorus-depth').value) / 100 : 0.5);
      const mix = (document.getElementById('chorus-mix') ? parseInt(document.getElementById('chorus-mix').value) / 100 : 0.3);
      const cc = document.getElementById('chorus-graph'); if (cc) drawChorusGraph(cc, normalizedValue, depth, mix, THEME_COLORS.effects);
      break;
    }
    case Params.CHORUS_DEPTH: {
      const pct = Math.round(normalizedValue * 100);
      updateSlider('chorus-depth', 'chorus-depth-val', pct, v => `${v}<span class="unit">%</span>`);
      const rate = (document.getElementById('chorus-rate') ? parseInt(document.getElementById('chorus-rate').value) / 100 : 0.2);
      const mix = (document.getElementById('chorus-mix') ? parseInt(document.getElementById('chorus-mix').value) / 100 : 0.3);
      const cc2 = document.getElementById('chorus-graph'); if (cc2) drawChorusGraph(cc2, rate, normalizedValue, mix, THEME_COLORS.effects);
      break;
    }
    case Params.CHORUS_MIX: {
      // Bipolar: normalized 0-1 → actual -1 to +1
      const bipolar = (normalizedValue * 2.0) - 1.0;
      const pct = Math.round(bipolar * 100);
      const sliderValue = pct;  // Slider is now -100 to +100 (bipolar)
      updateSlider('chorus-mix', 'chorus-mix-val', sliderValue, v => {
        const sign = pct >= 0 ? '+' : '';
        return `${sign}${pct}<span class="unit">%</span>`;
      });
      // Redraw chorus graph with current rate/depth and this mix
      const rateEl = document.getElementById('chorus-rate');
      const depthEl = document.getElementById('chorus-depth');
      const rate = rateEl ? parseInt(rateEl.value) / 100 : 0.2;
      const depth = depthEl ? parseInt(depthEl.value) / 100 : 0.5;
      const cg = document.getElementById('chorus-graph'); if (cg) drawChorusGraph(cg, rate, depth, normalizedValue, THEME_COLORS.effects);
      break;
    }

    // === REVERB ===
    case Params.REVERB_SIZE: {
      const pct = Math.round(normalizedValue * 100);
      updateSlider('reverb-size', 'reverb-size-val', pct, v => `${v}<span class="unit">%</span>`);
      const mix = (document.getElementById('reverb-mix') ? parseInt(document.getElementById('reverb-mix').value) / 100 : 0.25);
      const cr = document.getElementById('reverb-graph'); if (cr) {
        const dEl = document.getElementById('reverb-damp'); const dmp = dEl ? parseInt(dEl.value) / 100 : 0.4;
        drawReverbGraph(cr, normalizedValue, dmp, mix, THEME_COLORS.effects);
      }
      break;
    }
    case Params.REVERB_DAMP: {
      const pct = Math.round(normalizedValue * 100);
      updateSlider('reverb-damp', 'reverb-damp-val', pct, v => `${v}<span class="unit">%</span>`);
      break;
    }
    case Params.REVERB_MIX: {
      // Bipolar: normalized 0-1 → actual -1 to +1
      const bipolar = (normalizedValue * 2.0) - 1.0;
      const pct = Math.round(bipolar * 100);
      const sliderValue = pct;  // Slider is now -100 to +100 (bipolar)
      updateSlider('reverb-mix', 'reverb-mix-val', sliderValue, v => {
        const sign = pct >= 0 ? '+' : '';
        return `${sign}${pct}<span class="unit">%</span>`;
      });
      const size = (document.getElementById('reverb-size') ? parseInt(document.getElementById('reverb-size').value) / 100 : 0.5);
      const cr2 = document.getElementById('reverb-graph'); if (cr2) {
        const dEl = document.getElementById('reverb-damp'); const dmp = dEl ? parseInt(dEl.value) / 100 : 0.4;
        drawReverbGraph(cr2, size, dmp, normalizedValue, THEME_COLORS.effects);
      }
      break;
    }

    // === MASTER ===
    case Params.MASTER_VOLUME: {
      const pct = Math.round(normalizedValue * 100);
      updateSlider('master-vol', 'master-vol-val', pct, v => `${v}<span class="unit">%</span>`);
      break;
    }
    case Params.MASTER_PAN: {
      const value = Math.round(normalizedValue * 200 - 100);  // 0..1 → -100..+100
      updateSlider('master-pan', 'master-pan-val', value);
      break;
    }
    case Params.MASTER_PORTAMENTO: {
      const seconds = normalizedValue;  // 0-1 seconds (linear range, no log scaling needed)
      if (masterPortaVal) {
        masterPortaVal.innerHTML = seconds.toFixed(2) + '<span class="unit">s</span>';
      }
      if (masterPortaSlider) {
        masterPortaSlider.value = normalizedValue * 100;  // Slider range is 0-100
      }
      break;
    }
    case Params.MASTER_TUNE: {
      const cents = Math.round(denormalize(normalizedValue, -100, 100));
      updateSlider('master-tune', 'master-tune-val', cents, v => (v >= 0 ? '+' : '') + v);
      break;
    }
    case Params.MASTER_VOICE_NUM: {
      const voices = Math.round(denormalize(normalizedValue, 1, 8));
      updateSlider('voice-num', 'voice-num-val', voices, v => v.toString());
      break;
    }
    case Params.MASTER_VOICING_MODE: {
      const mode = Math.round(denormalize(normalizedValue, 0, 2));
      updateToggleGroup('voice-mode-group', mode);
      const modeNames = ['Mono', 'Poly', 'Unison'];
      const display = document.getElementById('voice-mode-val');
      if (display) display.textContent = modeNames[mode];
      // Update Unison Detune enabled state
      updateUnisonDetuneState(mode);
      break;
    }
    case Params.UNISON_DETUNE: {
      const cents = Math.round(denormalize(normalizedValue, 0, 200));
      updateSlider('unison-detune', 'unison-detune-val', cents, v => `${v}<span class="unit">¢</span>`);
      break;
    }
    case Params.MASTER_BEND_AMOUNT: {
      const semitones = Math.round(denormalize(normalizedValue, 0, 24));
      updateSlider('bend-range', 'bend-range-val', semitones, v => `${v}<span class="unit">semi</span>`);
      break;
    }
    // DEPRECATED: Analog Feel removed (2025-12-22)
    // case Params.MASTER_ANALOG_FEEL: {
    //   const pct = Math.round(normalizedValue * 100);
    //   updateSlider('master-analog', 'master-analog-val', pct, v => `${v}<span class="unit">%</span>`);
    //   break;
    // }

    // === GLOBAL ===
    case Params.GLOBAL_OCTAVE: {
      const octave = Math.round(denormalize(normalizedValue, -2, 2));
      updateSlider('global-octave', 'global-octave-val', octave, v => (v >= 0 ? '+' : '') + v);
      break;
    }
    case Params.GLOBAL_SEMITONE: {
      const semi = Math.round(denormalize(normalizedValue, -12, 12));
      updateSlider('global-semi', 'global-semi-val', semi, v => (v >= 0 ? '+' : '') + v);
      break;
    }

    default:
      // console.log(`Parameter ${paramIdx} updated to ${normalizedValue} (no UI handler)`);
      break;
  }

  // Clear flag after ALL queued events have processed (setTimeout pushes to end of event queue)
  setTimeout(() => {
    isUpdatingFromPlugin = false;
  }, 0);
};

// Process any pending parameter updates that arrived before script.js loaded
if (window.pendingParamUpdates && window.pendingParamUpdates.length > 0) {
  console.log(`Processing ${window.pendingParamUpdates.length} pending parameter updates...`);
  window.pendingParamUpdates.forEach(({ paramIdx, normalizedValue }) => {
    window.SPVFD(paramIdx, normalizedValue);
  });
  window.pendingParamUpdates = [];
}

// Alias for compatibility
window.IPlugSendParameterValueFromDelegate = window.SPVFD;

// ============================================================
// PRESET FILE BRIDGE FUNCTIONS
// ============================================================
// These functions send preset file commands to C++ via SPVFUI
// (SendParameterValueFromUI for control messages, not parameters)

// Send preset to file system (User/ directory)
window.presetSaveToFile = function (filename, presetData) {
  try {
    if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.callback) {
      window.webkit.messageHandlers.callback.postMessage({
        msg: 'SCMFUI',
        ctrlTag: 'PRESET_SAVE',
        filename: filename,
        data: JSON.stringify(presetData)
      });
      console.log(`Preset save request sent: ${filename}`, presetData);
    } else {
      console.error('WebKit bridge not available');
    }
  } catch (err) {
    console.error('Failed to send preset save request', err);
  }
};

// Request preset load from file system
window.presetLoadFromFile = function (filename) {
  try {
    const hasWebkit = !!window.webkit;
    const hasHandlers = hasWebkit && !!window.webkit.messageHandlers;
    const hasCallback = hasHandlers && !!window.webkit.messageHandlers.callback;

    if (hasCallback) {
      window.webkit.messageHandlers.callback.postMessage({
        msg: 'SCMFUI',
        ctrlTag: 'PRESET_LOAD',
        filename: filename
      });
    } else {
      console.error('WebKit bridge not available!');
    }
  } catch (err) {
    console.error('Error sending preset load request:', err);
  }
};

// Request preset list from file system
window.presetListRequest = function () {
  try {
    if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.callback) {
      window.webkit.messageHandlers.callback.postMessage({
        msg: 'SCMFUI',
        ctrlTag: 'PRESET_LIST'
      });
      console.log('Preset list request sent');
    } else {
      console.error('WebKit bridge not available');
    }
  } catch (err) {
    console.error('Failed to request preset list', err);
  }
};

//==============================================================================
// Wavetable File Management Bridge Functions
//==============================================================================

// Save wavetable to binary file (.wtb format)
window.wavetableSaveToFile = function (filename, samples) {
  try {
    if (!filename.endsWith('.wtb')) {
      filename += '.wtb';
    }

    if (!samples || samples.length !== 2048) {
      console.error('❌ Invalid wavetable: must be 2048 samples');
      return;
    }

    // Convert Float32Array to regular array for JSON serialization
    const samplesArray = Array.from(samples);

    if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.callback) {
      window.webkit.messageHandlers.callback.postMessage({
        msg: 'SCMFUI',
        ctrlTag: 'WAVETABLE_SAVE',
        filename: filename,
        samples: samplesArray
      });
      console.log(`💾 Wavetable save request sent: ${filename}`);
    } else {
      console.error('WebKit bridge not available');
    }
  } catch (err) {
    console.error('Failed to save wavetable:', err);
  }
};

// Load wavetable from binary file (.wtb format)
window.wavetableLoadFromFile = function (filename, callback) {
  try {
    if (!filename.endsWith('.wtb')) {
      filename += '.wtb';
    }

    // Store callback for when data arrives
    if (!window.__wavetableLoadCallbacks) {
      window.__wavetableLoadCallbacks = {};
    }
    window.__wavetableLoadCallbacks[filename] = callback;

    if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.callback) {
      window.webkit.messageHandlers.callback.postMessage({
        msg: 'SCMFUI',
        ctrlTag: 'WAVETABLE_LOAD',
        filename: filename
      });
      console.log(`📂 Wavetable load request sent: ${filename}`);
    } else {
      console.error('WebKit bridge not available');
    }
  } catch (err) {
    console.error('Failed to load wavetable:', err);
  }
};

// Request list of all wavetables from file system
// C++ will respond via SCMFD with WAVETABLE_LIST message
window.wavetableListRequest = function () {
  try {
    if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.callback) {
      window.webkit.messageHandlers.callback.postMessage({
        msg: 'SCMFUI',
        ctrlTag: 'WAVETABLE_LIST'
      });
      console.log('📂 Wavetable list request sent');
    } else {
      console.error('WebKit bridge not available');
    }
  } catch (err) {
    console.error('Failed to request wavetable list', err);
  }
};

// Load wavetable preview (256 samples) for catalog display
// C++ will respond via SCMFD with WAVETABLE_PREVIEW_LOADED message
window.wavetableLoadPreview = function (filename, callback) {
  try {
    if (!filename.endsWith('.wtb')) {
      filename += '.wtb';
    }

    // Store callback for when preview arrives
    if (!window.__wavetablePreviewCallbacks) {
      window.__wavetablePreviewCallbacks = {};
    }
    window.__wavetablePreviewCallbacks[filename] = callback;

    if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.callback) {
      window.webkit.messageHandlers.callback.postMessage({
        msg: 'SCMFUI',
        ctrlTag: 'WAVETABLE_LOAD_PREVIEW',
        filename: filename
      });
    } else {
      console.error('WebKit bridge not available');
      if (callback) callback(null, filename, 'Bridge not available');
    }
  } catch (err) {
    console.error('Failed to load wavetable preview:', err);
    if (callback) callback(null, filename, err.message);
  }
};

// Delete preset from file system (User/ directory only)
window.presetDelete = function (filename) {
  const msg = {
    msg: 'SPVFUI',
    ctrlTag: 'PRESET_DELETE',
    filename: filename
  };
  const msgStr = JSON.stringify(msg);
  if (window.SPVFUI) {
    window.SPVFUI(msgStr);
    console.log(`Preset delete request sent: ${filename}`);
  } else {
    console.error('SPVFUI not available');
  }
};

// ============================================================

// SCMFD - SendControlMsgFromDelegate
// Receives control messages from C++ (e.g., matrix config, wavetable data, preset responses)
// Signature: SCMFD(ctrlTag, msgTag, dataSize, base64Data)
window.SCMFD = function (ctrlTag, msgTag, dataSize, base64Data) {
  // Decode base64 data to string
  let decodedStr;
  try {
    decodedStr = atob(base64Data);
  } catch (err) {
    console.error('Failed to decode base64 data:', err);
    return;
  }

  // Parse the JSON message
  let tag, data;
  try {
    const msgObj = JSON.parse(decodedStr);
    tag = msgObj.ctrlTag;
    data = msgObj.data;
  } catch (err) {
    console.error('Failed to parse SCMFD JSON message:', err, decodedStr);
    return;
  }

  if (tag === 'MATRIX_CONFIG') {
    try {
      const matrixData = JSON.parse(data);
      if (matrixData.slots && Array.isArray(matrixData.slots)) {
        // Update __matrixRoutes array with data from C++
        __matrixRoutes = matrixData.slots.slice(0, MAX_MATRIX_SLOTS).map(slot => ({
          source: slot.source,
          slot: slot.slot || 0,  // Matrix slot index (0-15)
          destination: slot.destination,
          amount: slot.amount
        }));

        // Re-render matrix UI
        if (typeof renderModMatrix === 'function') {
          renderModMatrix();
        }
      }
    } catch (err) {
      console.error('Failed to parse matrix config:', err);
    }
  }
  else if (tag === 'PRESET_LIST') {
    console.log('🔵 ========== PRESET_LIST HANDLER CALLED ==========');
    console.log(`📋 Received PRESET_LIST message, data type: ${typeof data}`);
    console.log(`📋 Raw data:`, data);
    console.log(`📋 Data JSON.stringify:`, JSON.stringify(data));
    console.log(`📋 Data length: ${typeof data === 'string' ? data.length : 'N/A'}`);
    try {
      let presetList;

      // Handle both string and array formats
      if (typeof data === 'string') {
        console.log('📋 Parsing preset list from string...');
        console.log(`📋 String data: "${data}"`);
        presetList = JSON.parse(data);
      } else {
        console.log('📋 Preset list already parsed (array object)');
        presetList = data;
      }

      console.log('📋 Received preset list from C++:', presetList);
      console.log(`📋 Preset list type: ${typeof presetList}, is array: ${Array.isArray(presetList)}, length: ${presetList ? presetList.length : 'N/A'}`);

      // Validate each preset object
      if (Array.isArray(presetList)) {
        console.log(`✓ Preset list is array with ${presetList.length} items`);
        presetList.forEach((p, idx) => {
          console.log(`  [${idx}] name="${p?.name}", filename="${p?.filename}", category="${p?.category}", author="${p?.author}", version="${p?.version}"`);
        });
      } else {
        console.error('⚠️ Preset list is not an array:', presetList);
      }

      // Update PresetManager with file-based preset list
      if (window.presetManager && typeof window.presetManager.updatePresetList === 'function') {
        console.log(`📥 Calling updatePresetList with ${Array.isArray(presetList) ? presetList.length : '?'} presets`);
        window.presetManager.updatePresetList(presetList);
        console.log(`✓ updatePresetList completed`);
      } else {
        console.error('❌ presetManager.updatePresetList not available');
      }
    } catch (err) {
      console.error('Failed to parse preset list:', err);
      console.error('Raw data:', data);
    }
    console.log('🔵 ========== PRESET_LIST HANDLER DONE ==========');
  }
  else if (tag === 'PRESET_LOAD_ERROR') {
    console.log('[INIT] PRESET_LOAD_ERROR received');
    // PRESET_LOAD_ERROR message contains error info directly in msgObj (not in data field)
    // msgObj structure: { msg: "SCMFD", ctrlTag: "PRESET_LOAD_ERROR", error: "...", filename: "..." }

    // If this is the startup Init load, mark it as failed
    if (window.__loadingInitOnStartup) {
      window.__initLoadFailed = true;
      console.error('[INIT] Init.json load failed on startup');
      // Reset all parameters to 0 when Init.json is not found
      resetAllParametersToZero();

      // Update preset display to show "(not loaded)"
      if (window.presetManager && window.presetManager.nameEl) {
        window.presetManager.nameEl.textContent = '(not loaded)';
      }
      if (window.presetManager && window.presetManager.categoryEl) {
        window.presetManager.categoryEl.textContent = '(not loaded)';
      }
    }

    // Use error message directly from msgObj (parsed at line 1516)
    // Access the original msgObj by re-parsing decodedStr
    try {
      const msgObj = JSON.parse(decodedStr);
      showErrorBalloon('Init Preset Not Found', `Cannot load ${msgObj.filename || 'Init'}`);
    } catch (err) {
      showErrorBalloon('Init Preset Error', 'Unknown error loading Init preset');
    }
  }
  else if (tag === 'PRESET_LOADED') {
    console.log('📦 Raw PRESET_LOADED data:', data);

    if (!data) {
      console.error('❌ ERROR: Received empty data from C++');
      return;
    }

    try {
      // Data may be already parsed JSON object (from C++ side) or a string
      const presetData = typeof data === 'string' ? JSON.parse(data) : data;
      console.log('✓ Received preset data from C++:', presetData);

      // Apply preset FIRST before hiding loading screen
      if (window.presetManager && typeof window.presetManager.applyPreset === 'function') {
        console.log('📥 Calling applyPreset() to load parameters...');
        window.presetManager.applyPreset(presetData);
        console.log('✓ applyPreset() completed');
      } else {
        console.error('❌ presetManager.applyPreset not available');
      }

      // If this is the startup Init load, mark it as successful (AFTER apply)
      if (window.__loadingInitOnStartup) {
        window.__initLoadFailed = false;
        window.__loadingInitOnStartup = false;
        console.log('✅ Init.awaon loaded successfully on startup');
        // Hide the loading progress bar AFTER parameter updates complete
        updateLoadingProgress(100);
        setTimeout(() => {
          console.log('🔄 Hiding loading screen...');
          hideLoadingScreen();
        }, 1000);  // Increased delay to ensure all parameters are processed
      }
    } catch (err) {
      console.error('❌ Failed to parse loaded preset:', err);
      console.error('❌ Raw data that failed to parse:', data);
    }
  }
  else if (tag === 'WAVETABLE_SAVED') {
    try {
      const response = JSON.parse(data);
      console.log('✅ Wavetable saved successfully:', response.filename);
      // Optional: trigger UI notification or update wavetable library list
      if (window.onWavetableSaved && typeof window.onWavetableSaved === 'function') {
        window.onWavetableSaved(response.filename);
      }
    } catch (err) {
      console.error('❌ Failed to parse wavetable save response:', err);
    }
  }
  else if (tag === 'WAVETABLE_LOADED') {
    try {
      const response = JSON.parse(data);
      console.log('✅ Wavetable loaded successfully:', response.filename, `(${response.samples.length} samples)`);

      // Convert array to Float32Array
      const samples = new Float32Array(response.samples);

      // Invoke callback registered by wavetableLoadFromFile()
      if (window.__wavetableLoadCallbacks && window.__wavetableLoadCallbacks[response.filename]) {
        const callback = window.__wavetableLoadCallbacks[response.filename];
        callback(samples, response.filename);
        delete window.__wavetableLoadCallbacks[response.filename];
      } else {
        console.warn('No callback registered for wavetable:', response.filename);
      }
    } catch (err) {
      console.error('❌ Failed to parse wavetable load response:', err);
    }
  }
  else if (tag === 'WAVETABLE_LOAD_ERROR') {
    try {
      const errorData = JSON.parse(data);
      console.error('❌ Wavetable Load Error:', errorData.filename, '-', errorData.error);

      // Invoke callback with null to signal error
      if (window.__wavetableLoadCallbacks && window.__wavetableLoadCallbacks[errorData.filename]) {
        const callback = window.__wavetableLoadCallbacks[errorData.filename];
        callback(null, errorData.filename, errorData.error);
        delete window.__wavetableLoadCallbacks[errorData.filename];
      }

      alert(`Failed to load wavetable: ${errorData.filename}\n${errorData.error}`);
    } catch (err) {
      console.error('❌ Failed to parse wavetable load error:', err);
    }
  }
  else if (tag === 'WAVETABLE_LIST') {
    try {
      console.log('📂 WAVETABLE_LIST raw data length:', data.length);
      console.log('📂 WAVETABLE_LIST raw data (first 200 chars):', data.substring(0, 200));

      const wavetableList = JSON.parse(data);
      console.log('📂 Parsed wavetable list:', wavetableList);
      console.log('📂 Number of wavetables:', wavetableList.length);

      if (wavetableList.length > 0) {
        console.log('📂 First wavetable:', {
          id: wavetableList[0].id,
          name: wavetableList[0].name,
          hasData: !!wavetableList[0].data,
          dataLength: wavetableList[0].data ? wavetableList[0].data.length : 0
        });
      }

      // Update WavetableLibrary with file-based wavetables
      if (window.wavetableLibrary && typeof window.wavetableLibrary.updateUserWavetables === 'function') {
        window.wavetableLibrary.updateUserWavetables(wavetableList);
        console.log('📂 WavetableLibrary updated successfully');
      } else {
        console.warn('⚠️ WavetableLibrary.updateUserWavetables not available');
      }
    } catch (err) {
      console.error('❌ Failed to parse wavetable list:', err);
      console.error('❌ Error details:', err.message, err.stack);
    }
  }
  else if (tag === 'WAVETABLE_PREVIEW_LOADED') {
    try {
      const response = JSON.parse(data);
      console.log('✅ Wavetable preview loaded:', response.filename, `(${response.samples.length} samples)`);

      // Convert array to Float32Array
      const samples = new Float32Array(response.samples);

      // Invoke callback registered by wavetableLoadPreview()
      if (window.__wavetablePreviewCallbacks && window.__wavetablePreviewCallbacks[response.filename]) {
        const callback = window.__wavetablePreviewCallbacks[response.filename];
        callback(samples, response.filename);
        delete window.__wavetablePreviewCallbacks[response.filename];
      } else {
        console.warn('No preview callback registered for:', response.filename);
      }
    } catch (err) {
      console.error('❌ Failed to parse wavetable preview:', err);
    }
  }
  else if (tag === 'WAVETABLE_PREVIEW_ERROR') {
    try {
      const errorData = JSON.parse(data);
      console.error('❌ Wavetable Preview Error:', errorData.filename, '-', errorData.error);

      // Invoke callback with null to signal error
      if (window.__wavetablePreviewCallbacks && window.__wavetablePreviewCallbacks[errorData.filename]) {
        const callback = window.__wavetablePreviewCallbacks[errorData.filename];
        callback(null, errorData.filename, errorData.error);
        delete window.__wavetablePreviewCallbacks[errorData.filename];
      }
    } catch (err) {
      console.error('❌ Failed to parse wavetable preview error:', err);
    }
  }
  else if (tag === 'MIDI_NOTE_ON') {
    // MIDI Note On visualization - activate keyboard key
    try {
      const msgObj = JSON.parse(decodedStr);
      const noteNum = msgObj.note;
      const velocity = msgObj.velocity;

      const key = document.querySelector(`[data-note="${noteNum}"]`);
      if (key) {
        key.classList.add('active');
      }
    } catch (err) {
      console.error('Failed to handle MIDI_NOTE_ON:', err);
    }
  }
  else if (tag === 'MIDI_NOTE_OFF') {
    // MIDI Note Off visualization - deactivate keyboard key
    try {
      const msgObj = JSON.parse(decodedStr);
      const noteNum = msgObj.note;

      const key = document.querySelector(`[data-note="${noteNum}"]`);
      if (key) {
        key.classList.remove('active');
      }
    } catch (err) {
      console.error('Failed to handle MIDI_NOTE_OFF:', err);
    }
  }
  else if (tag === 'MIDI_PITCH_BEND') {
    // MIDI Pitch Bend visualization - update indicator position
    try {
      const msgObj = JSON.parse(decodedStr);
      const value = msgObj.value;  // -1.0 to +1.0

      const indicator = document.querySelector('.keyboard-wheel-indicator-bend');
      if (indicator) {
        // Convert -1..+1 to 0..100%
        const percent = ((value + 1.0) / 2.0) * 100;
        indicator.style.bottom = `${percent}%`;
      }
    } catch (err) {
      console.error('Failed to handle MIDI_PITCH_BEND:', err);
    }
  }
  else if (tag === 'MIDI_MOD_WHEEL') {
    // MIDI Mod Wheel visualization - update indicator position
    try {
      const msgObj = JSON.parse(decodedStr);
      const value = msgObj.value;  // 0.0 to 1.0

      const indicator = document.querySelector('.keyboard-wheel-indicator-mod');
      if (indicator) {
        // Convert 0..1 to 0..100%
        indicator.style.bottom = `${value * 100}%`;
      }
    } catch (err) {
      console.error('Failed to handle MIDI_MOD_WHEEL:', err);
    }
  }
};

// Alias for compatibility
window.IPlugSendControlMsgFromDelegate = window.SCMFD;

// SAMFD - SendArbitraryMsgFromDelegate
// Receives arbitrary messages from C++ (JSON or base64-encoded data)
// Signature: SAMFD(msgTag, dataSize, base64Data)
window.SAMFD = function (msgTag, dataSize, base64Data) {
  console.log(`SAMFD received: msgTag=${msgTag}, dataSize=${dataSize}`);

  // Decode base64 data if present
  if (dataSize > 0 && base64Data) {
    try {
      const decodedStr = atob(base64Data);
      console.log('SAMFD decoded data:', decodedStr.substring(0, 200));

      // Try to parse as JSON
      try {
        const jsonData = JSON.parse(decodedStr);
        console.log('SAMFD JSON data:', jsonData);

        // Handle based on msgTag or JSON content
        if (jsonData.id) {
          // Delegate to SCMFD handler if it has an 'id' field
          window.SCMFD(jsonData.id, msgTag, dataSize, base64Data);
        }
      } catch (jsonError) {
        console.warn('SAMFD: Not JSON data, raw string:', decodedStr);
      }
    } catch (decodeError) {
      console.error('SAMFD: Failed to decode base64:', decodeError);
    }
  }
};

// SMMFD - SendMidiMsgFromDelegate
// Receives MIDI messages from C++ (currently unused in this UI)
// Signature: SMMFD(status, data1, data2)
window.SMMFD = function (status, data1, data2) {
  console.log('MIDI from plugin:', status, data1, data2);
  // Currently unused in this UI, but required to prevent errors
};

// Signal to C++ that UI is ready to receive parameters
if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.callback) {
  window.webkit.messageHandlers.callback.postMessage({
    msg: 'UI_READY'
  });
  console.log('UI_READY signal sent successfully');

  // NOTE: Preset list is now requested from waitForBridgeAndLoadInit() AFTER Init.json loads
  // This ensures Init.json is loaded before showing other presets
  // Wavetable list can still be requested independently
  setTimeout(() => {
    if (typeof window.wavetableListRequest === 'function') {
      window.wavetableListRequest();
      console.log('Initial wavetable list requested');
    }
  }, 200);
} else {
  console.warn('Cannot send UI_READY - bridge not available');
}

// Check bridge status
function checkBridge() {
  const statusEl = document.getElementById('status');
  const hasBridge = !!(window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.callback);
  if (statusEl) {
    if (hasBridge) {
      statusEl.textContent = 'Connected to iPlug2';
      statusEl.className = 'status connected';
    } else {
      statusEl.textContent = 'Not connected (running in browser)';
      statusEl.className = 'status error';
    }
  }
  return hasBridge;
}

// ============================================================================
// Parameter Controls
// ============================================================================

// Global: disable right-click context menu
if (RIGHT_CLICK) {
  document.addEventListener('contextmenu', (e) => {
    e.preventDefault();
  });
}
// Header navigator smooth scroll
function setupHeaderNavigator() {
  const nav = document.querySelector('.header-navigator');
  if (!nav) return;
  nav.querySelectorAll('.control-btn[data-target]').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const targetSel = btn.getAttribute('data-target');
      if (!targetSel) return;
      const el = document.querySelector(targetSel);
      if (el) {
        const offset = -80; // requested offset
        const groupEl = el.closest('.grid-group');
        const headerEl = groupEl ? groupEl.querySelector('.grid-header') : null;
        const scrollTarget = headerEl || el;
        const didExpand = window.__expandGroupForTarget && window.__expandGroupForTarget(scrollTarget);
        const delay = didExpand && window.__groupToggleDurations
          ? window.__groupToggleDurations.groupCollapseMs
          : 0;
        const scroll = () => {
          const y = scrollTarget.getBoundingClientRect().top + window.scrollY + offset;
          window.scrollTo({ top: y, behavior: 'smooth' });
        };
        if (delay) {
          setTimeout(scroll, delay);
        } else {
          scroll();
        }
      }
    });
  });
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', setupHeaderNavigator);
} else {
  setupHeaderNavigator();
}

// Preset name marquee scrolling
let __presetMarquee = { interval: null, timeout: null };
function clearPresetMarquee() {
  if (__presetMarquee.interval) { clearInterval(__presetMarquee.interval); __presetMarquee.interval = null; }
  if (__presetMarquee.timeout) { clearTimeout(__presetMarquee.timeout); __presetMarquee.timeout = null; }
}

function setupPresetNameMarquee() {
  const container = document.querySelector('.preset-display');
  const text = container ? container.querySelector('.preset-display-inner') : null;
  if (!container || !text) return;
  // Do not scroll in expanded preset viewer
  const header = document.querySelector('.app-header');
  if (header && header.classList.contains('preset-viewing')) { clearPresetMarquee(); text.style.transform = 'translateX(0px)'; return; }
  clearPresetMarquee();
  // Reset position
  text.style.transform = 'translateX(0px)';

  const distance = Math.max(0, text.scrollWidth - container.clientWidth);
  if (distance <= 4) return; // no need to scroll

  const stepPx = 1;
  const stepMs = 20;
  const holdMs = 1000;
  let pos = 0;

  const startScroll = () => {
    __presetMarquee.interval = setInterval(() => {
      pos -= stepPx;
      if (-pos >= distance) {
        clearPresetMarquee();
        // hold at end, then reset
        __presetMarquee.timeout = setTimeout(() => {
          pos = 0;
          text.style.transform = 'translateX(0px)';
          __presetMarquee.timeout = setTimeout(() => { startScroll(); }, holdMs);
        }, holdMs);
      } else {
        text.style.transform = `translateX(${pos}px)`;
      }
    }, stepMs);
  };

  // initial hold, then start scrolling
  __presetMarquee.timeout = setTimeout(startScroll, holdMs);

  // Recalculate on resize
  const onResize = () => {
    clearPresetMarquee();
    setupPresetNameMarquee();
  };
  // Debounce resize
  let resizeTimer;
  window.addEventListener('resize', () => {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(onResize, 150);
  });
}

// ---------------------------------------------------------------------------
// Submenu portal manager (portal-based positioning for nested submenus)
// ---------------------------------------------------------------------------
const SubmenuPortal = (() => {
  let portal = null;
  let submenu = null;
  let currentParent = null;
  let hideTimeout = null;
  const viewportPadding = 8;

  function ensurePortal() {
    if (portal && submenu) return;
    portal = document.getElementById('submenu-portal');
    if (!portal) {
      portal = document.createElement('div');
      portal.id = 'submenu-portal';
      portal.className = 'submenu-portal';
      portal.setAttribute('aria-hidden', 'true');
      document.body.appendChild(portal);
    }
    submenu = portal.querySelector('.dropdown-submenu');
    if (!submenu) {
      submenu = document.createElement('div');
      submenu.className = 'dropdown-submenu';
      submenu.setAttribute('role', 'menu');
      portal.appendChild(submenu);
    }
  }

  function buildSubmenu(data) {
    if (!submenu) return;
    submenu.innerHTML = '';

    data.children.forEach((child) => {
      const childItem = document.createElement('button');
      childItem.type = 'button';
      childItem.className = 'dropdown-item';

      const childIcon = document.createElement('span');
      childIcon.className = 'fukiai dropdown-item-icon';
      const childIconText = data.kind === 'source'
        ? (child.icon || MOD_SOURCES[child.index]?.icon || ' ')
        : (child.icon || getMatrixDestinationChildIcon(child.index) || ' ');
      childIcon.textContent = childIconText || ' ';
      childItem.appendChild(childIcon);

      const childLabel = document.createElement('span');
      childLabel.className = 'dropdown-item-label';
      childLabel.textContent = child.label;
      childItem.appendChild(childLabel);

      // Disable if not implemented
      if (child.implemented === false || (data.implementedDests && !data.implementedDests.has(child.index))) {
        childItem.disabled = true;
        childItem.style.color = '#666';
        childItem.style.fontStyle = 'italic';
      }

      childItem.addEventListener('click', (evt) => {
        evt.preventDefault();
        if (childItem.disabled) return;
        // Set the hidden select to the correct flat index
        data.select.value = String(child.index);
        data.select.dispatchEvent(new Event('change', { bubbles: true }));
        data.closeFn(); // Close main dropdown
        hide(); // Close submenu
      });

      submenu.appendChild(childItem);
    });
  }

  function positionSubmenu(parentElement) {
    if (!submenu || !parentElement) return;
    const rect = parentElement.getBoundingClientRect();

    // Reset position before measuring
    submenu.style.left = '0px';
    submenu.style.top = '0px';

    requestAnimationFrame(() => {
      const submenuRect = submenu.getBoundingClientRect();

      // Position to the right of parent item
      let left = rect.right + 2;
      // Check if submenu would overflow right edge
      if (left + submenuRect.width > window.innerWidth - viewportPadding) {
        // Position to the left of parent item instead
        left = rect.left - submenuRect.width - 2;
      }
      if (left < viewportPadding) left = viewportPadding;

      // Align top with parent item
      let top = rect.top - 4;
      // Check if submenu would overflow bottom edge
      if (top + submenuRect.height > window.innerHeight - viewportPadding) {
        top = window.innerHeight - submenuRect.height - viewportPadding;
      }
      if (top < viewportPadding) top = viewportPadding;

      submenu.style.left = `${left}px`;
      submenu.style.top = `${top}px`;
    });
  }

  function show(parentElement) {
    if (hideTimeout) {
      clearTimeout(hideTimeout);
      hideTimeout = null;
    }

    ensurePortal();
    if (!portal || !submenu || !parentElement._submenuData) return;

    currentParent = parentElement;
    buildSubmenu(parentElement._submenuData);
    portal.setAttribute('data-open', 'true');
    portal.removeAttribute('aria-hidden');
    positionSubmenu(parentElement);

    // Add mouseenter/mouseleave to submenu portal to keep it open
    submenu.addEventListener('mouseenter', () => {
      if (hideTimeout) {
        clearTimeout(hideTimeout);
        hideTimeout = null;
      }
    });
    submenu.addEventListener('mouseleave', () => {
      hide();
    });
  }

  function hide() {
    // Delay hide to allow moving from parent to submenu
    if (hideTimeout) clearTimeout(hideTimeout);
    hideTimeout = setTimeout(() => {
      if (!portal || !submenu) return;
      portal.setAttribute('data-open', 'false');
      portal.setAttribute('aria-hidden', 'true');
      currentParent = null;
    }, 100);
  }

  return {
    show,
    hide
  };
})();

// Global dropdown manager (portal-based positioning)
// ---------------------------------------------------------------------------
const DropdownManager = (() => {
  let portal = null;
  let menu = null;
  let current = null;
  const viewportPadding = 8;

  function ensurePortal() {
    if (portal && menu) return;
    portal = document.getElementById('dropdown-portal');
    if (!portal) {
      portal = document.createElement('div');
      portal.id = 'dropdown-portal';
      portal.className = 'dropdown-portal';
      portal.setAttribute('aria-hidden', 'true');
      portal.innerHTML = '<div class="dropdown-menu" role="menu"></div>';
      document.body.appendChild(portal);
    }
    menu = portal.querySelector('.dropdown-menu');
  }

  function handleDocumentClick(e) {
    if (!current) return;
    if ((menu && menu.contains(e.target)) || (current.button && current.button.contains(e.target))) {
      return;
    }
    close();
  }

  // Build hierarchical menu for matrix destinations
  function buildHierarchicalMenu(select, hierarchy) {
    if (!menu) return;
    menu.innerHTML = '';

    const implementedDests = new Set([
      1, 2, 3, 5, 6, 7, 10, 11, 12, 13, 14, 16, 18, 19,
      20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30,
      31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43,
      44, 45, 46, 47, 48, 49, 50, 51,  // NEW: Enum/Toggle destinations
      52  // Master → Pitch
    ]);

    hierarchy.forEach((item) => {
      // Handle separator
      if (item.type === 'separator') {
        const separator = document.createElement('hr');
        separator.className = 'dropdown-separator';
        menu.appendChild(separator);
        return;
      }

      if (item.children) {
        // Parent item with submenu
        const parent = document.createElement('div');
        parent.className = 'dropdown-item has-submenu';
        parent.setAttribute('tabindex', '0');

        // Icon (only for parent)

        const icon = document.createElement('span');
        icon.className = 'fukiai dropdown-item-icon';
        icon.textContent = item.icon || ' ';
        parent.appendChild(icon);


        // Label
        const label = document.createElement('span');
        label.className = 'dropdown-item-label';
        label.textContent = item.label;
        parent.appendChild(label);

        // Chevron for submenu indicator
        const chevron = document.createElement('span');
        chevron.className = 'fukiai submenu-chevron';
        chevron.textContent = '\uEACA'; // chevron right
        parent.appendChild(chevron);

        // Store submenu data on parent element
        parent._submenuData = {
          children: item.children,
          select: select,
          implementedDests: implementedDests,
          closeFn: close,
          parentIcon: item.icon,
          kind: 'destination'
        };

        // Hover events to show/hide submenu portal
        parent.addEventListener('mouseenter', (evt) => {
          SubmenuPortal.show(parent);
        });
        parent.addEventListener('mouseleave', (evt) => {
          SubmenuPortal.hide();
        });

        menu.appendChild(parent);

      } else {
        // Single item (no submenu)
        const singleItem = document.createElement('button');
        singleItem.type = 'button';
        singleItem.className = 'dropdown-item';

        const icon = document.createElement('span');
        icon.className = 'fukiai dropdown-item-icon';
        const itemIcon = item.icon || getMatrixDestinationChildIcon(item.index) || ' ';
        icon.textContent = itemIcon || ' ';
        singleItem.appendChild(icon);

        const singleLabel = document.createElement('span');
        singleLabel.className = 'dropdown-item-label';
        singleLabel.textContent = item.label;
        singleItem.appendChild(singleLabel);

        // Disable if not implemented
        if (item.implemented === false || (item.index > 0 && !implementedDests.has(item.index))) {
          singleItem.disabled = true;
          singleItem.style.color = '#666';
          singleItem.style.fontStyle = 'italic';
        }

        singleItem.addEventListener('click', (evt) => {
          evt.preventDefault();
          if (singleItem.disabled) return;
          select.value = String(item.index);
          select.dispatchEvent(new Event('change', { bubbles: true }));
          close();
        });

        menu.appendChild(singleItem);
      }
    });
  }

  function buildSourceMenu(select) {
    if (!menu) return;
    menu.innerHTML = '';

    MOD_SOURCES_HIERARCHY.forEach((item) => {
      if (item.type === 'separator') {
        const separator = document.createElement('hr');
        separator.className = 'dropdown-separator';
        menu.appendChild(separator);
        return;
      }

      if (item.children) {
        const parent = document.createElement('div');
        parent.className = 'dropdown-item has-submenu';
        parent.setAttribute('tabindex', '0');

        const icon = document.createElement('span');
        icon.className = 'fukiai dropdown-item-icon';
        icon.textContent = item.icon || ' ';
        parent.appendChild(icon);

        const label = document.createElement('span');
        label.className = 'dropdown-item-label';
        label.textContent = item.label;
        parent.appendChild(label);

        const chevron = document.createElement('span');
        chevron.className = 'fukiai submenu-chevron';
        chevron.textContent = '\uEACA';
        parent.appendChild(chevron);

        parent._submenuData = {
          children: item.children,
          select: select,
          closeFn: close,
          kind: 'source'
        };

        parent.addEventListener('mouseenter', () => {
          SubmenuPortal.show(parent);
        });
        parent.addEventListener('mouseleave', () => {
          SubmenuPortal.hide();
        });

        menu.appendChild(parent);
      } else {
        const idx = item.index;
        if (typeof idx === 'number' && MOD_SOURCES[idx]?.hidden) return;

        const singleItem = document.createElement('button');
        singleItem.type = 'button';
        singleItem.className = 'dropdown-item';

        const icon = document.createElement('span');
        icon.className = 'fukiai dropdown-item-icon';
        icon.textContent = item.icon || MOD_SOURCES[idx]?.icon || ' ';
        singleItem.appendChild(icon);

        const singleLabel = document.createElement('span');
        singleLabel.className = 'dropdown-item-label';
        singleLabel.textContent = item.label;
        singleItem.appendChild(singleLabel);

        if (item.implemented === false) {
          singleItem.disabled = true;
          singleItem.style.color = '#666';
          singleItem.style.fontStyle = 'italic';
        }

        singleItem.addEventListener('click', (evt) => {
          evt.preventDefault();
          if (singleItem.disabled) return;
          select.value = String(idx);
          select.dispatchEvent(new Event('change', { bubbles: true }));
          close();
        });

        menu.appendChild(singleItem);
      }
    });
  }

  function buildMenu(select) {
    if (!menu) return;

    // Check if this is a matrix destination dropdown (use hierarchical menu)
    if (select.id && select.id.startsWith('matrix-dest-')) {
      buildHierarchicalMenu(select, MOD_DESTINATIONS_HIERARCHY);
      return;
    }
    if (select.id && select.id.startsWith('matrix-source-')) {
      buildSourceMenu(select);
      return;
    }

    // Standard menu for other dropdowns
    menu.innerHTML = '';
    const options = Array.from(select.options).filter(opt => opt.value || opt.dataset.divider === 'true');
    if (!options.length) {
      const empty = document.createElement('div');
      empty.className = 'dropdown-empty';
      empty.textContent = 'No actions';
      menu.appendChild(empty);
      return;
    }
    options.forEach(opt => {
      if (opt.dataset.divider === 'true') {
        const divider = document.createElement('div');
        divider.className = 'dropdown-divider';
        menu.appendChild(divider);
        return;
      }
      const item = document.createElement('button');
      item.type = 'button';
      item.className = 'dropdown-item';
      const icon = document.createElement('span');
      icon.className = 'fukiai dropdown-item-icon';
      icon.textContent = opt.dataset.icon || ' ';
      item.appendChild(icon);
      const label = document.createElement('span');
      label.className = 'dropdown-item-label';
      label.textContent = opt.textContent;
      item.appendChild(label);

      if (opt.disabled) item.disabled = true;
      item.addEventListener('click', (evt) => {
        evt.preventDefault();
        if (opt.disabled) return;
        select.value = opt.value;
        select.dispatchEvent(new Event('change', { bubbles: true }));
        close();
      });
      menu.appendChild(item);
    });
  }

  function positionMenu(button) {
    if (!menu || !button) return;
    const rect = button.getBoundingClientRect();
    // Reset position before measuring
    menu.style.left = '0px';
    menu.style.top = '0px';
    requestAnimationFrame(() => {
      const menuRect = menu.getBoundingClientRect();
      let left = rect.left;
      if (left + menuRect.width > window.innerWidth - viewportPadding) {
        left = window.innerWidth - menuRect.width - viewportPadding;
      }
      if (left < viewportPadding) left = viewportPadding;

      let top = rect.bottom + 6;
      if (top + menuRect.height > window.innerHeight - viewportPadding) {
        top = rect.top - menuRect.height - 6;
      }
      if (top < viewportPadding) top = viewportPadding;

      menu.style.left = `${left}px`;
      menu.style.top = `${top}px`;
    });
  }

  function handleScroll(e) {
    // Only close if scroll is happening outside the dropdown menu
    if (portal && menu && (e.target === menu || menu.contains(e.target))) {
      return; // Allow scrolling within the menu
    }
    close();
  }

  function open(select, button) {
    ensurePortal();
    if (!portal || !menu) return;
    buildMenu(select);
    portal.setAttribute('data-open', 'true');
    portal.removeAttribute('aria-hidden');
    current = { select, button };
    if (button) {
      button.setAttribute('aria-expanded', 'true');
      button.classList.add('dropdown-active');
    }
    positionMenu(button);
    document.addEventListener('click', handleDocumentClick, true);
    window.addEventListener('resize', close);
    window.addEventListener('scroll', handleScroll, true);
  }

  function close() {
    if (!portal || !menu) return;
    if (current && current.button) {
      current.button.classList.remove('dropdown-active');
      current.button.setAttribute('aria-expanded', 'false');
    }
    current = null;
    portal.removeAttribute('data-open');
    portal.setAttribute('aria-hidden', 'true');
    menu.innerHTML = '';
    document.removeEventListener('click', handleDocumentClick, true);
    window.removeEventListener('resize', close);
    window.removeEventListener('scroll', handleScroll, true);
  }

  function toggle(select, button) {
    if (!select || !button) return;
    if (current && current.button === button) {
      close();
    } else {
      open(select, button);
    }
  }

  return { toggle, close, init: ensurePortal };
})();

function setupDropdownTriggers() {
  const bindTrigger = (btn) => {
    if (!btn || btn.__dropdownBound) return;
    btn.__dropdownBound = true;
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      const targetId = btn.getAttribute('data-dropdown-toggle');
      if (!targetId) return;
      const select = document.getElementById(targetId);
      if (!select) return;
      DropdownManager.toggle(select, btn);
    });
  };

  DropdownManager.init();
  document.querySelectorAll('[data-dropdown-toggle]').forEach(bindTrigger);
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', setupDropdownTriggers);
} else {
  setupDropdownTriggers();
}

// MIDI dropdown actions (custom menu + native select)
function setupMidiDropdown() {
  const sel = document.getElementById('midi-dropdown-select');
  if (!sel) return;
  sel.addEventListener('change', () => {
    const value = sel.value;
    sel.selectedIndex = 0;
    handleMidiDropdownAction(value);
  });
}

function handleMidiDropdownAction(value) {
  switch (value) {
    case 'monitor':
      console.log('Open MIDI Monitor (TODO)');
      break;
    case 'devices':
      console.log('Open MIDI Devices (TODO)');
      break;
    case 'panic': {
      try {
        const payload = JSON.stringify({ type: 'midi:panic' });
        if (window.SCMFUI) window.SCMFUI(0, 0, payload.length, payload);
      } catch (err) {
        console.warn('Failed to send panic control message', err);
      }
      break;
    }
    default:
      break;
  }
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', setupMidiDropdown);
} else {
  setupMidiDropdown();
}

function setupAiFloat() {
  const trigger = document.getElementById('ai-trigger');
  const panel = document.getElementById('ai-float');
  const input = document.getElementById('ai-input');
  if (!trigger || !panel) return;

  const close = () => {
    panel.classList.remove('is-open');
    panel.setAttribute('aria-hidden', 'true');
  };

  trigger.addEventListener('click', (e) => {
    e.preventDefault();
    e.stopPropagation();
    const isOpen = panel.classList.toggle('is-open');
    panel.setAttribute('aria-hidden', isOpen ? 'false' : 'true');
    if (isOpen && input) input.focus();
  });

  panel.addEventListener('click', (e) => {
    e.stopPropagation();
  });

  document.addEventListener('click', close);
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') close();
  });
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', setupAiFloat);
} else {
  setupAiFloat();
}

// Master Volume
const masterVolSlider = document.getElementById('master-vol');
const masterVolVal = document.getElementById('master-vol-val');
if (masterVolSlider) {
  masterVolSlider.addEventListener('input', (e) => {
    const value = parseInt(e.target.value);
    const normalized = value / 100;
    masterVolVal.innerHTML = `${value}<span class="unit">%</span>`;
    sendParam(Params.MASTER_VOLUME, normalized);
  });
}

// Master Pan
const masterPanSlider = document.getElementById('master-pan');
const masterPanVal = document.getElementById('master-pan-val');
if (masterPanSlider) {
  masterPanSlider.addEventListener('input', (e) => {
    const value = parseInt(e.target.value);
    const normalized = (value + 100) / 200;  // -100..+100 → 0..1
    masterPanVal.textContent = value;
    sendParam(Params.MASTER_PAN, normalized);
  });
}

// Global Octave
const globalOctaveSlider = document.getElementById('global-octave');
const globalOctaveVal = document.getElementById('global-octave-val');
if (globalOctaveSlider) {
  globalOctaveSlider.addEventListener('input', (e) => {
    const value = parseInt(e.target.value);
    const normalized = normalize(value, -2, 2);
    globalOctaveVal.textContent = (value >= 0 ? '+' : '') + value;
    sendParam(Params.GLOBAL_OCTAVE, normalized);
  });
}

// Global Semitone
const globalSemiSlider = document.getElementById('global-semi');
const globalSemiVal = document.getElementById('global-semi-val');
if (globalSemiSlider) {
  globalSemiSlider.addEventListener('input', (e) => {
    const value = parseInt(e.target.value);
    const normalized = normalize(value, -12, 12);
    globalSemiVal.textContent = (value >= 0 ? '+' : '') + value;
    sendParam(Params.GLOBAL_SEMITONE, normalized);
  });
}

// Bend Range
const bendRangeSlider = document.getElementById('bend-range');
const bendRangeVal = document.getElementById('bend-range-val');
if (bendRangeSlider) {
  bendRangeSlider.addEventListener('input', (e) => {
    const value = parseInt(e.target.value);
    const normalized = normalize(value, 0, 24);
    bendRangeVal.innerHTML = `${value}<span class="unit">semi</span>`;
    sendParam(Params.MASTER_BEND_AMOUNT, normalized);
  });
}

// Signals Drive
const signalsDriveSlider = document.getElementById('signals-drive');
const signalsDriveVal = document.getElementById('signals-drive-val');
if (signalsDriveSlider) {
  signalsDriveSlider.addEventListener('input', (e) => {
    const value = parseFloat(e.target.value);
    const normalized = normalize(value, 0, 24);
    signalsDriveVal.innerHTML = `${value.toFixed(1)}<span class="unit">dB</span>`;
    sendParam(Params.SIGNALS_DRIVE, normalized);
  });
}

// Signals Tone
const signalsToneSlider = document.getElementById('signals-tone');
const signalsToneVal = document.getElementById('signals-tone-val');
if (signalsToneSlider) {
  signalsToneSlider.addEventListener('input', (e) => {
    const value = parseInt(e.target.value);
    const normalized = normalize(value, -100, 100);
    signalsToneVal.textContent = (value >= 0 ? '+' : '') + value;
    sendParam(Params.SIGNALS_TONE, normalized);
  });
}

// DEPRECATED: Analog Feel removed (2025-12-22)

// Voice Number
const voiceNumSlider = document.getElementById('voice-num');
const voiceNumVal = document.getElementById('voice-num-val');
if (voiceNumSlider) {
  voiceNumSlider.addEventListener('input', (e) => {
    const value = parseInt(e.target.value);
    const normalized = normalize(value, 1, 8);
    voiceNumVal.textContent = value;
    sendParam(Params.MASTER_VOICE_NUM, normalized);
  });
}

// OSC1 Level
const osc1LevelSlider = document.getElementById('osc1-level');
const osc1LevelVal = document.getElementById('osc1-level-val');
if (osc1LevelSlider) {
  osc1LevelSlider.addEventListener('input', (e) => {
    const value = parseInt(e.target.value);
    const normalized = value / 100;
    osc1LevelVal.innerHTML = `${value}<span class="unit">%</span>`;
    sendParam(Params.OSC1_LEVEL, normalized);
  });
}

// OSC1 Semitone
const osc1SemiSlider = document.getElementById('osc1-semi');
const osc1SemiVal = document.getElementById('osc1-semi-val');
if (osc1SemiSlider) {
  osc1SemiSlider.addEventListener('input', (e) => {
    const value = parseInt(e.target.value);
    const normalized = normalize(value, -24, 24);
    osc1SemiVal.textContent = (value >= 0 ? '+' : '') + value;
    sendParam(Params.OSC1_SEMI, normalized);
  });
}

// OSC1 Fine Tune
const osc1FineSlider = document.getElementById('osc1-fine');
const osc1FineVal = document.getElementById('osc1-fine-val');
if (osc1FineSlider) {
  osc1FineSlider.addEventListener('input', (e) => {
    const value = parseInt(e.target.value);
    const normalized = normalize(value, -100, 100);
    osc1FineVal.textContent = (value >= 0 ? '+' : '') + value;
    sendParam(Params.OSC1_FINE, normalized);
  });
}

// OSC2 Level
const osc2LevelSlider = document.getElementById('osc2-level');
const osc2LevelVal = document.getElementById('osc2-level-val');
if (osc2LevelSlider) {
  osc2LevelSlider.addEventListener('input', (e) => {
    const value = parseInt(e.target.value);
    const normalized = value / 100;
    osc2LevelVal.innerHTML = `${value}<span class="unit">%</span>`;
    sendParam(Params.OSC2_LEVEL, normalized);
  });
}

// OSC2 Semitone
const osc2SemiSlider = document.getElementById('osc2-semi');
const osc2SemiVal = document.getElementById('osc2-semi-val');
if (osc2SemiSlider) {
  osc2SemiSlider.addEventListener('input', (e) => {
    const value = parseInt(e.target.value);
    const normalized = normalize(value, -24, 24);
    osc2SemiVal.textContent = (value >= 0 ? '+' : '') + value;
    sendParam(Params.OSC2_SEMI, normalized);
  });
}

// OSC2 Fine Tune
const osc2FineSlider = document.getElementById('osc2-fine');
const osc2FineVal = document.getElementById('osc2-fine-val');
if (osc2FineSlider) {
  osc2FineSlider.addEventListener('input', (e) => {
    const value = parseInt(e.target.value);
    const normalized = normalize(value, -100, 100);
    osc2FineVal.textContent = (value >= 0 ? '+' : '') + value;
    sendParam(Params.OSC2_FINE, normalized);
  });
}

// Noise Level
const noiseLevelSlider = document.getElementById('noise-level');
const noiseLevelVal = document.getElementById('noise-level-val');
if (noiseLevelSlider) {
  noiseLevelSlider.addEventListener('input', (e) => {
    const value = parseInt(e.target.value);
    const normalized = value / 100;
    noiseLevelVal.innerHTML = `${value}<span class="unit">%</span>`;
    sendParam(Params.NOISE_LEVEL, normalized);
    if (window.noiseViz) window.noiseViz.setLevel(normalized);
  });
}



// Noise Variant (type-specific)
const noiseVariantSlider = document.getElementById('noise-variant');
const noiseVariantLabel = document.getElementById('noise-variant-label');
const noiseVariantVal = document.getElementById('noise-variant-val');
if (noiseVariantSlider) {
  noiseVariantSlider.addEventListener('input', (e) => {
    const value = parseInt(e.target.value); // 0..100
    const normalized = value / 100;
    // Update readable value based on current type
    const group = document.getElementById('noise-type-group');
    let typeIdx = 0;
    if (group) {
      const btns = [...group.querySelectorAll('.toggle-btn')];
      typeIdx = btns.findIndex(b => b.classList.contains('is-active') || b.classList.contains('active'));
      if (typeIdx < 0) typeIdx = 0;
    }
    if (typeIdx === 1) {
      const bits = 3 + Math.round((value / 100) * 7);
      noiseVariantVal.textContent = bits + ' bit';
    } else if (typeIdx === 2) {
      const mode = (value < 50) ? 1 : 2; // two modes only
      noiseVariantVal.textContent = mode.toString();
    } else {
      noiseVariantVal.textContent = (value / 100).toFixed(2);
    }
    sendParam(Params.NOISE_VARIANT, normalized);
    if (window.noiseViz) window.noiseViz.setVariant(normalized);
  });
}


// 
// OSC MOD section removed (UI and bindings deleted)

// Filter 1 Cutoff (logarithmic scale)
const filterCutoffSlider = document.getElementById('filter-cutoff');
const filterCutoffVal = document.getElementById('filter-cutoff-val');
if (filterCutoffSlider) {
  filterCutoffSlider.addEventListener('input', (e) => {
    const sliderValue = parseInt(e.target.value) / 100; // 0-1
    const hz = logScale(sliderValue, 20, 20000);
    const normalized = sliderValue;

    filterCutoffVal.innerHTML =
      hz < 1000 ? Math.round(hz) + ' <span class="unit">Hz</span>' : (hz / 1000).toFixed(1) + ' <span class="unit">kHz</span>';

    sendParam(Params.FILTER_1_CUTOFF, normalized);
    setRangeProgress(filterCutoffSlider);

    // Update filter visualizer
    if (window.filter1Viz) {
      window.filter1Viz.setCutoff(hz);
    }
  });
}

// Filter 1 Resonance
const filterResoSlider = document.getElementById('filter-reso');
const filterResoVal = document.getElementById('filter-reso-val');
if (filterResoSlider) {
  filterResoSlider.addEventListener('input', (e) => {
    const value = parseInt(e.target.value);
    const normalized = value / 100;
    filterResoVal.innerHTML = `${value}<span class="unit">%</span>`;
    sendParam(Params.FILTER_1_RESO, normalized);

    // Update filter visualizer
    if (window.filter1Viz) {
      window.filter1Viz.setResonance(normalized);
    }
  });
}

// Filter 2 Cutoff (logarithmic scale)
const filter2CutoffSlider = document.getElementById('filter2-cutoff');
const filter2CutoffVal = document.getElementById('filter2-cutoff-val');
if (filter2CutoffSlider) {
  filter2CutoffSlider.addEventListener('input', (e) => {
    const sliderValue = parseInt(e.target.value) / 100; // 0-1
    const hz = logScale(sliderValue, 20, 20000);
    const normalized = sliderValue;

    filter2CutoffVal.innerHTML =
      hz < 1000 ? Math.round(hz) + ' <span class="unit">Hz</span>' : (hz / 1000).toFixed(1) + ' <span class="unit">kHz</span>';

    sendParam(Params.FILTER_2_CUTOFF, normalized);
    setRangeProgress(filter2CutoffSlider);

    // Update filter visualizer
    if (window.filter2Viz) {
      window.filter2Viz.setCutoff(hz);
    }
  });
}

// Filter 2 Resonance
const filter2ResoSlider = document.getElementById('filter2-reso');
const filter2ResoVal = document.getElementById('filter2-reso-val');
if (filter2ResoSlider) {
  filter2ResoSlider.addEventListener('input', (e) => {
    const value = parseInt(e.target.value);
    const normalized = value / 100;
    filter2ResoVal.innerHTML = `${value}<span class="unit">%</span>`;
    sendParam(Params.FILTER_2_RESO, normalized);

    // Update filter visualizer
    if (window.filter2Viz) {
      window.filter2Viz.setResonance(normalized);
    }
  });
}

// Modal Filter: placeholder only (no JS wiring)

// Envelope 1 Attack (logarithmic)
const env1AttackSlider = document.getElementById('env1-attack');
const env1AttackVal = document.getElementById('env1-attack-val');
if (env1AttackSlider) {
  env1AttackSlider.addEventListener('input', (e) => {
    const sliderValue = parseInt(e.target.value) / 100;
    const seconds = logScale(sliderValue, 0.001, 5);
    const normalized = invLogScale(seconds, 0.001, 10);

    env1AttackVal.innerHTML =
      seconds < 1 ? Math.round(seconds * 1000) + ' <span class="unit">ms</span>' : seconds.toFixed(2) + ' <span class="unit">s</span>';

    sendParam(Params.ENV1_ATTACK, normalized);

    // Update envelope visualizer
    if (window.env1Viz) {
      window.env1Viz.setAttack(seconds * 1000);
    }
  });
}

// Envelope 1 Decay (logarithmic)
const env1DecaySlider = document.getElementById('env1-decay');
const env1DecayVal = document.getElementById('env1-decay-val');
if (env1DecaySlider) {
  env1DecaySlider.addEventListener('input', (e) => {
    const sliderValue = parseInt(e.target.value) / 100;
    const seconds = logScale(sliderValue, 0.001, 5);
    const normalized = invLogScale(seconds, 0.001, 10);

    env1DecayVal.innerHTML =
      seconds < 1 ? Math.round(seconds * 1000) + ' <span class="unit">ms</span>' : seconds.toFixed(2) + ' <span class="unit">s</span>';

    sendParam(Params.ENV1_DECAY, normalized);

    // Update envelope visualizer
    if (window.env1Viz) {
      window.env1Viz.setDecay(seconds * 1000);
    }
  });
}

// Envelope 1 Sustain
const env1SustainSlider = document.getElementById('env1-sustain');
const env1SustainVal = document.getElementById('env1-sustain-val');
if (env1SustainSlider) {
  env1SustainSlider.addEventListener('input', (e) => {
    const value = parseInt(e.target.value);
    const normalized = value / 100;
    env1SustainVal.innerHTML = `${value}<span class="unit">%</span>`;
    sendParam(Params.ENV1_SUSTAIN, normalized);

    // Update envelope visualizer
    if (window.env1Viz) {
      window.env1Viz.setSustain(normalized);
    }
  });
}

// Envelope 1 Release (logarithmic)
const env1ReleaseSlider = document.getElementById('env1-release');
const env1ReleaseVal = document.getElementById('env1-release-val');
if (env1ReleaseSlider) {
  env1ReleaseSlider.addEventListener('input', (e) => {
    const sliderValue = parseInt(e.target.value) / 100;
    const seconds = logScale(sliderValue, 0.001, 5);
    const normalized = invLogScale(seconds, 0.001, 10);

    env1ReleaseVal.innerHTML =
      seconds < 1 ? Math.round(seconds * 1000) + ' <span class="unit">ms</span>' : seconds.toFixed(2) + ' <span class="unit">s</span>';

    sendParam(Params.ENV1_RELEASE, normalized);

    // Update envelope visualizer
    if (window.env1Viz) {
      window.env1Viz.setRelease(seconds * 1000);
    }
  });
}

// Envelope 1 Level
const env1LevelSlider = document.getElementById('env1-level');
const env1LevelVal = document.getElementById('env1-level-val');
if (env1LevelSlider) {
  env1LevelSlider.addEventListener('input', (e) => {
    const value = parseInt(e.target.value);
    const normalized = value / 100;
    env1LevelVal.innerHTML = `${value}<span class="unit">%</span>`;
    sendParam(Params.ENV1_LEVEL, normalized);
  });
}

// Envelope 1 Linearity
const env1CurveSlider = document.getElementById('env1-curve');
const env1CurveVal = document.getElementById('env1-curve-val');
if (env1CurveSlider) {
  env1CurveSlider.addEventListener('input', (e) => {
    const value = parseInt(e.target.value);
    const normalized = value / 100;
    env1CurveVal.innerHTML = `${value}<span class="unit">%</span>`;
    sendParam(Params.ENV1_CURVE, normalized);
    if (window.env1Viz) window.env1Viz.setLinearity(normalized);
  });
}

// Envelope 2 Attack (logarithmic)
const env2AttackSlider = document.getElementById('env2-attack');
const env2AttackVal = document.getElementById('env2-attack-val');
if (env2AttackSlider) {
  env2AttackSlider.addEventListener('input', (e) => {
    const sliderValue = parseInt(e.target.value) / 100;
    const seconds = logScale(sliderValue, 0.001, 5);
    const normalized = invLogScale(seconds, 0.001, 10);

    env2AttackVal.innerHTML =
      seconds < 1 ? Math.round(seconds * 1000) + ' <span class="unit">ms</span>' : seconds.toFixed(2) + ' <span class="unit">s</span>';

    sendParam(Params.ENV2_ATTACK, normalized);

    // Update envelope visualizer
    if (window.env2Viz) {
      window.env2Viz.setAttack(seconds * 1000);
    }
  });
}

// Envelope 2 Decay (logarithmic)
const env2DecaySlider = document.getElementById('env2-decay');
const env2DecayVal = document.getElementById('env2-decay-val');
if (env2DecaySlider) {
  env2DecaySlider.addEventListener('input', (e) => {
    const sliderValue = parseInt(e.target.value) / 100;
    const seconds = logScale(sliderValue, 0.001, 5);
    const normalized = invLogScale(seconds, 0.001, 10);

    env2DecayVal.innerHTML =
      seconds < 1 ? Math.round(seconds * 1000) + ' <span class="unit">ms</span>' : seconds.toFixed(2) + ' <span class="unit">s</span>';

    sendParam(Params.ENV2_DECAY, normalized);

    // Update envelope visualizer
    if (window.env2Viz) {
      window.env2Viz.setDecay(seconds * 1000);
    }
  });
}

// Envelope 2 Sustain
const env2SustainSlider = document.getElementById('env2-sustain');
const env2SustainVal = document.getElementById('env2-sustain-val');
if (env2SustainSlider) {
  env2SustainSlider.addEventListener('input', (e) => {
    const value = parseInt(e.target.value);
    const normalized = value / 100;
    env2SustainVal.innerHTML = `${value}<span class="unit">%</span>`;
    sendParam(Params.ENV2_SUSTAIN, normalized);

    // Update envelope visualizer
    if (window.env2Viz) {
      window.env2Viz.setSustain(normalized);
    }
  });
}

// Envelope 2 Release (logarithmic)
const env2ReleaseSlider = document.getElementById('env2-release');
const env2ReleaseVal = document.getElementById('env2-release-val');
if (env2ReleaseSlider) {
  env2ReleaseSlider.addEventListener('input', (e) => {
    const sliderValue = parseInt(e.target.value) / 100;
    const seconds = logScale(sliderValue, 0.001, 5);
    const normalized = invLogScale(seconds, 0.001, 10);

    env2ReleaseVal.innerHTML =
      seconds < 1 ? Math.round(seconds * 1000) + ' <span class="unit">ms</span>' : seconds.toFixed(2) + ' <span class="unit">s</span>';

    sendParam(Params.ENV2_RELEASE, normalized);

    // Update envelope visualizer
    if (window.env2Viz) {
      window.env2Viz.setRelease(seconds * 1000);
    }
  });
}

// Envelope 2 Level
const env2LevelSlider = document.getElementById('env2-level');
const env2LevelVal = document.getElementById('env2-level-val');
if (env2LevelSlider) {
  env2LevelSlider.addEventListener('input', (e) => {
    const value = parseInt(e.target.value);
    const normalized = value / 100;
    env2LevelVal.innerHTML = `${value}<span class="unit">%</span>`;
    sendParam(Params.ENV2_LEVEL, normalized);
  });
}

// Envelope 2 Linearity
const env2CurveSlider = document.getElementById('env2-curve');
const env2CurveVal = document.getElementById('env2-curve-val');
if (env2CurveSlider) {
  env2CurveSlider.addEventListener('input', (e) => {
    const value = parseInt(e.target.value);
    const normalized = value / 100;
    env2CurveVal.innerHTML = `${value}<span class="unit">%</span>`;
    sendParam(Params.ENV2_CURVE, normalized);
    if (window.env2Viz) window.env2Viz.setLinearity(normalized);
  });
}

// LFO 1 Rate with tempo sync support
let lfo1Sync = false;
const lfo1SyncCheckbox = document.getElementById('lfo1-sync');
const lfo1RateSlider = document.getElementById('lfo1-rate');
const lfo1RateVal = document.getElementById('lfo1-rate-val');
const lfo1Saved = { freeValue: null, syncIndex: null };

function updateLfo1Rate() {
  if (!lfo1RateSlider) return;

  if (lfo1Sync) {
    // Tempo sync mode - send division index to LFO1_TEMPO_DIV parameter
    const idx = parseInt(lfo1RateSlider.value);
    const rate = musicalRateOptions[idx];
    if (rate) {
      lfo1RateVal.textContent = rate.label;
      // Send division index (0-11) to LFO1_TEMPO_DIV parameter
      const normalized = idx / 11;  // Normalize 0-11 to 0-1
      sendParam(Params.LFO1_TEMPO_DIV, normalized);
      if (window.lfo1Viz) window.lfo1Viz.setRate(normalized);
    }
  } else {
    // Free Hz mode - send to LFO1_RATE parameter
    const sliderValue = parseInt(lfo1RateSlider.value) / 100;
    const hz = logScale(sliderValue, 0.1, 60);
    lfo1RateVal.innerHTML = hz.toFixed(1) + '<span class="unit">Hz</span>';
    sendParam(Params.LFO1_RATE, sliderValue);
    if (window.lfo1Viz) window.lfo1Viz.setRate(sliderValue);
  }
}

if (lfo1SyncCheckbox) {
  lfo1SyncCheckbox.addEventListener('change', (e) => {
    lfo1Sync = e.target.checked;

    if (lfo1Sync) {
      // Switch to musical rate mode
      // backup current free value
      lfo1Saved.freeValue = Number(lfo1RateSlider.value);
      lfo1RateSlider.min = 0;
      lfo1RateSlider.max = musicalRateOptions.length - 1;
      lfo1RateSlider.step = 1;
      // use previous sync index if available, otherwise default to 6 (1/2)
      lfo1RateSlider.value = (lfo1Saved.syncIndex != null) ? lfo1Saved.syncIndex : 6;
      lfo1RateSlider.classList.add('tempo-sync', 'steps-12');
    } else {
      // Switch back to Hz mode
      // backup current sync index
      lfo1Saved.syncIndex = Number(lfo1RateSlider.value);
      lfo1RateSlider.min = 0;
      lfo1RateSlider.max = 100;
      lfo1RateSlider.step = 1;
      // restore previous free value or default
      lfo1RateSlider.value = (lfo1Saved.freeValue != null) ? lfo1Saved.freeValue : 20; // ~5Hz
      lfo1RateSlider.classList.remove('tempo-sync', 'steps-12');
    }
    setRangeProgress(lfo1RateSlider);
    updateLfo1Rate();
  });
}

if (lfo1RateSlider) {
  lfo1RateSlider.addEventListener('input', updateLfo1Rate);
}

// LFO 1 Depth
const lfo1DepthSlider = document.getElementById('lfo1-depth');
const lfo1DepthVal = document.getElementById('lfo1-depth-val');
if (lfo1DepthSlider) {
  lfo1DepthSlider.addEventListener('input', (e) => {
    const value = parseInt(e.target.value);
    const normalized = value / 100;
    lfo1DepthVal.innerHTML = `${value}<span class="unit">%</span>`;
    sendParam(Params.LFO1_DEPTH, normalized);
    if (window.lfo1Viz) window.lfo1Viz.setDepth(normalized);
  });
}

// LFO 1 Delay (UI only; send control message if available)
const lfo1DelaySlider = document.getElementById('lfo1-delay');
const lfo1DelayVal = document.getElementById('lfo1-delay-val');
if (lfo1DelaySlider) {
  lfo1DelaySlider.addEventListener('input', (e) => {
    const value = parseInt(e.target.value); // 0..100
    // map to 0..2s linearly
    const ms = Math.round((value / 100) * 2000);
    if (lfo1DelayVal) lfo1DelayVal.innerHTML = `${ms}<span class="unit">ms</span>`;
    // optional: notify DSP via control message
    const payload = JSON.stringify({ type: 'lfo:delay', index: 1, value: value / 100 });
    if (window.SCMFUI) window.SCMFUI(0, 0, payload.length, payload);
  });
}

// LFO 2 Rate with tempo sync support
let lfo2Sync = false;
const lfo2SyncCheckbox = document.getElementById('lfo2-sync');
const lfo2RateSlider = document.getElementById('lfo2-rate');
const lfo2RateVal = document.getElementById('lfo2-rate-val');
const lfo2Saved = { freeValue: null, syncIndex: null };

function updateLfo2Rate() {
  if (!lfo2RateSlider) return;

  if (lfo2Sync) {
    // Tempo sync mode - send division index to LFO2_TEMPO_DIV parameter
    const idx = parseInt(lfo2RateSlider.value);
    const rate = musicalRateOptions[idx];
    if (rate) {
      lfo2RateVal.textContent = rate.label;
      // Send division index (0-11) to LFO2_TEMPO_DIV parameter
      const normalized = idx / 11;  // Normalize 0-11 to 0-1
      sendParam(Params.LFO2_TEMPO_DIV, normalized);
      if (window.lfo2Viz) window.lfo2Viz.setRate(normalized);
    }
  } else {
    // Free Hz mode - send to LFO2_RATE parameter
    const sliderValue = parseInt(lfo2RateSlider.value) / 100;
    const hz = logScale(sliderValue, 0.1, 60);
    lfo2RateVal.innerHTML = hz.toFixed(1) + '<span class="unit">Hz</span>';
    sendParam(Params.LFO2_RATE, sliderValue);
    if (window.lfo2Viz) window.lfo2Viz.setRate(sliderValue);
  }
}

if (lfo2SyncCheckbox) {
  lfo2SyncCheckbox.addEventListener('change', (e) => {
    lfo2Sync = e.target.checked;

    if (lfo2Sync) {
      // Switch to musical rate mode
      lfo2Saved.freeValue = Number(lfo2RateSlider.value);
      lfo2RateSlider.min = 0;
      lfo2RateSlider.max = musicalRateOptions.length - 1;
      lfo2RateSlider.step = 1;
      lfo2RateSlider.value = (lfo2Saved.syncIndex != null) ? lfo2Saved.syncIndex : 6; // Default to 1/2
      lfo2RateSlider.classList.add('tempo-sync', 'steps-12');
    } else {
      // Switch back to Hz mode
      lfo2Saved.syncIndex = Number(lfo2RateSlider.value);
      lfo2RateSlider.min = 0;
      lfo2RateSlider.max = 100;
      lfo2RateSlider.step = 1;
      lfo2RateSlider.value = (lfo2Saved.freeValue != null) ? lfo2Saved.freeValue : 5; // ~1Hz
      lfo2RateSlider.classList.remove('tempo-sync', 'steps-12');
    }
    setRangeProgress(lfo2RateSlider);
    updateLfo2Rate();
  });
}

if (lfo2RateSlider) {
  lfo2RateSlider.addEventListener('input', updateLfo2Rate);
}

// LFO 2 Depth
const lfo2DepthSlider = document.getElementById('lfo2-depth');
const lfo2DepthVal = document.getElementById('lfo2-depth-val');
if (lfo2DepthSlider) {
  lfo2DepthSlider.addEventListener('input', (e) => {
    const value = parseInt(e.target.value);
    const normalized = value / 100;
    lfo2DepthVal.innerHTML = `${value}<span class="unit">%</span>`;
    sendParam(Params.LFO2_DEPTH, normalized);
    if (window.lfo2Viz) window.lfo2Viz.setDepth(normalized);
  });
}

// LFO 2 Delay (UI only; send control message if available)
const lfo2DelaySlider = document.getElementById('lfo2-delay');
const lfo2DelayVal = document.getElementById('lfo2-delay-val');
if (lfo2DelaySlider) {
  lfo2DelaySlider.addEventListener('input', (e) => {
    const value = parseInt(e.target.value); // 0..100
    const ms = Math.round((value / 100) * 2000);
    if (lfo2DelayVal) lfo2DelayVal.innerHTML = `${ms}<span class="unit">ms</span>`;
    const payload = JSON.stringify({ type: 'lfo:delay', index: 2, value: value / 100 });
    if (window.SCMFUI) window.SCMFUI(0, 0, payload.length, payload);
  });
}

// ============================================================================
// Initialization
// ============================================================================

window.addEventListener('load', () => {
  console.log('Awaon UI loaded');
  checkBridge();
  // Build linear scrollable keyboard C0–C5 and (legacy) layout helper no-ops if no black keys
  buildKeyboard();
  layoutKeyboard();
  window.addEventListener('resize', () => { layoutKeyboard(); });

  document.querySelectorAll('input[type="range"]').forEach((sl) => {
    setRangeProgress(sl);
    sl.addEventListener('input', () => setRangeProgress(sl));
  });

  // // Landscape mode helper: auto-toggle .is-landscape on small, wide viewports
  // const updateLandscapeClass = () => {
  //   const should = (window.innerWidth <= 940 && window.innerHeight <= 430);
  //   document.body.classList.toggle('is-landscape', should);
  // };
  // updateLandscapeClass();
  // window.addEventListener('resize', updateLandscapeClass);
  // window.addEventListener('orientationchange', updateLandscapeClass);

  // Initial effect graphs render from current sliders (in case DSP hasn't sent values yet)
  const delayTimeSlider = document.getElementById('delay-time');
  const delayFeedbackSlider = document.getElementById('delay-feedback');
  const delayMixSlider = document.getElementById('delay-mix');
  const chorusRateSlider = document.getElementById('chorus-rate');
  const chorusDepthSlider = document.getElementById('chorus-depth');
  const reverbSizeSlider = document.getElementById('reverb-size');
  const reverbMixSlider = document.getElementById('reverb-mix');
  const dg = document.getElementById('delay-graph');
  const cg = document.getElementById('chorus-graph');
  const rg = document.getElementById('reverb-graph');
  // Header Preset Viewer: toggle via preset-controls
  (function () {
    const headerEl = document.querySelector('.app-header');
    const overlayEl = document.querySelector('.app-header-overlay');
    const presetControls = document.querySelector('.preset-controls');
    const closeBtn = document.getElementById('preset-close');
    const pvList = document.getElementById('pv-list');
    const pvCat = document.getElementById('pv-category');
    const pvSearch = document.getElementById('pv-search');
    const pvSort = document.getElementById('pv-sort');
    const pvCount = document.getElementById('pv-count');
    const pvTable = document.getElementById('pv-table');
    const pvTbody = document.getElementById('pv-tbody');
    const pvThead = document.getElementById('pv-thead');
    if (!headerEl || !overlayEl || !presetControls) return;
    const LET_HIDE_DELAY_MS = 80; const LET_HIDE_FADE_MS = 280; const STAGE2_MS = 220;
    let timers = []; const clearTimers = () => { timers.forEach(clearTimeout); timers = []; };
    const state = { cat: '', q: '', sort: 'nameAsc' };
    function applySortIndicators() {
      if (!pvThead) return;
      pvThead.querySelectorAll('th').forEach(function (th) { th.classList.remove('sort-asc'); th.classList.remove('sort-desc'); });
      var key = state.sort.replace(/(Asc|Desc)$/, '').toLowerCase();
      var dir = /Desc$/.test(state.sort) ? 'sort-desc' : 'sort-asc';
      var th = pvThead.querySelector('[data-sort="' + key + '"]');
      if (th) th.classList.add(dir);
    }
    // OLD renderPV() DISABLED - replaced with PresetManager.renderPresetTable() (file-based presets)
    const renderPV = () => {
      // Delegate to new PresetManager.renderPresetTable() which supports file-based presets
      if (window.presetManager && typeof window.presetManager.renderPresetTable === 'function') {
        window.presetManager.renderPresetTable();
      }
    };
    // Event listeners now use PresetManager methods (which use file-based loading)
    if (pvCat) pvCat.addEventListener('change', () => { state.cat = pvCat.value; renderPV(); });
    if (pvSort) pvSort.addEventListener('change', () => { state.sort = pvSort.value; renderPV(); });
    if (pvThead) { pvThead.addEventListener('click', function (e) { var th = e.target.closest('th[data-sort]'); if (!th) return; var key = th.getAttribute('data-sort'); if (key === 'name') { state.sort = (state.sort === 'nameAsc') ? 'nameDesc' : 'nameAsc'; } else if (key === 'category') { state.sort = 'category'; } else if (key === 'author') { state.sort = 'author'; } else if (key === 'fav') { state.sort = 'favFirst'; } renderPV(); }); }
    if (pvSearch) {
      let sTimer; pvSearch.addEventListener('input', () => { clearTimeout(sTimer); sTimer = setTimeout(() => { state.q = pvSearch.value || ''; renderPV(); }, 120); });
    }
    let __scrollYBeforeLock = 0;
    const openViewer = () => {
      // Lock scroll without overflow:hidden by fixing the body in place
      __scrollYBeforeLock = window.scrollY || window.pageYOffset || 0;
      document.body.style.setProperty('--scroll-lock-top', `-${__scrollYBeforeLock}px`);
      clearTimers(); headerEl.classList.add('preset-viewing'); overlayEl.classList.add('full'); document.body.classList.add('noscroll'); clearPresetMarquee();
      const letHides = Array.from(headerEl.querySelectorAll('.let-hide'));
      headerEl.classList.add('preset-stage-1');
      letHides.forEach((el, i) => { const rect = el.getBoundingClientRect(); el.dataset.origMaxWidth = `${rect.width}`; el.style.maxWidth = `${rect.width}px`; el.style.overflow = 'hidden'; timers.push(setTimeout(() => { el.style.opacity = '0'; el.style.maxWidth = '0px'; }, i * LET_HIDE_DELAY_MS)); });
      const STAGE1_MS = (Math.max(0, letHides.length - 1) * LET_HIDE_DELAY_MS) + LET_HIDE_FADE_MS + 40;
      timers.push(setTimeout(() => { headerEl.classList.add('preset-stage-2'); timers.push(setTimeout(() => { headerEl.classList.add('preset-stage-3'); renderPV(); }, STAGE2_MS)); }, STAGE1_MS));
    };
    const closeViewer = () => {
      clearTimers(); headerEl.classList.remove('preset-stage-3');
      timers.push(setTimeout(() => {
        headerEl.classList.remove('preset-stage-2'); const letHides = Array.from(headerEl.querySelectorAll('.let-hide'));
        letHides.slice().reverse().forEach((el, idx) => { timers.push(setTimeout(() => { el.style.opacity = '1'; el.style.maxWidth = (el.dataset.origMaxWidth ? `${parseFloat(el.dataset.origMaxWidth)}px` : 'none'); }, idx * LET_HIDE_DELAY_MS)); });
        const stage1Dur = (Math.max(0, letHides.length - 1) * LET_HIDE_DELAY_MS) + LET_HIDE_FADE_MS + 40;
        timers.push(setTimeout(() => { headerEl.classList.remove('preset-stage-1'); letHides.forEach((el) => { el.style.maxWidth = ''; el.style.opacity = ''; el.style.overflow = ''; delete el.dataset.origMaxWidth; }); headerEl.classList.remove('preset-viewing'); overlayEl.classList.remove('full'); document.body.classList.remove('noscroll'); const y = __scrollYBeforeLock || 0; document.body.style.removeProperty('--scroll-lock-top'); window.scrollTo(0, y); }, stage1Dur));
      }, STAGE2_MS));
    };
    presetControls.addEventListener('click', () => { headerEl.classList.contains('preset-viewing') ? closeViewer() : openViewer(); });
    overlayEl.addEventListener('click', () => { if (overlayEl.classList.contains('full')) closeViewer(); });
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeViewer(); });
    if (closeBtn) closeBtn.addEventListener('click', closeViewer);
  })();
  // OSC waveform label -> Toggle Wavetable Catalog (via showcase)
  (function () {
    function bindWaveLabel(showcaseInstance) {
      if (!showcaseInstance || !showcaseInstance.label) return;
      showcaseInstance.label.style.cursor = 'pointer';
      showcaseInstance.label.title = 'Browse Wavetables';
      showcaseInstance.label.addEventListener('click', (event) => {
        event.stopPropagation();
        if (showcaseInstance.label.dataset.catalogDisabled === 'true') {
          return;
        }
        try {
          // Toggle: if catalog is visible, close it; otherwise open it
          const canvas = document.getElementById(`${showcaseInstance.prefix}-waveform-canvas`);
          const container = canvas?.parentElement;
          const overlay = container?.querySelector('.catalog-overlay');

          if (overlay && overlay.classList.contains('visible')) {
            // Catalog is open - close it
            overlay.classList.remove('visible');
            showcaseInstance.label.classList.remove('is-open');
          } else {
            // Catalog is closed - open it
            showcaseInstance.openGrid();
          }
        } catch (e) {
          console.warn('Open catalog failed:', e);
        }
      });
    }

    // Bind after showcases are created
    setTimeout(() => {
      if (window.osc1Showcase) bindWaveLabel(window.osc1Showcase);
      if (window.osc2Showcase) bindWaveLabel(window.osc2Showcase);
    }, 100);
  })();

  if (dg && delayTimeSlider && delayFeedbackSlider) {
    const t = parseInt(delayTimeSlider.value) / 100; const f = parseInt(delayFeedbackSlider.value) / 100;
    const m = delayMixSlider ? parseInt(delayMixSlider.value) / 100 : 0.2;
    drawDelayGraph(dg, t, f, m, THEME_COLORS.effects);
  }
  if (cg && chorusRateSlider && chorusDepthSlider) {
    const r = parseInt(chorusRateSlider.value) / 100; const d = parseInt(chorusDepthSlider.value) / 100;
    const mEl = document.getElementById('chorus-mix');
    const m = mEl ? parseInt(mEl.value) / 100 : 0.3;
    drawChorusGraph(cg, r, d, m, THEME_COLORS.effects);
  }
  if (rg && reverbSizeSlider && reverbMixSlider) {
    const s = parseInt(reverbSizeSlider.value) / 100;
    const m = parseInt(reverbMixSlider.value) / 100;
    const dampEl = document.getElementById('reverb-damp');
    const dmp = dampEl ? parseInt(dampEl.value) / 100 : 0.4;
    drawReverbGraph(rg, s, dmp, m, THEME_COLORS.effects);
  }

  // Initialize Modal graph
  const mg = document.getElementById('modal-graph');
  if (mg) {
    const t = (document.getElementById('modal-tone') ? parseInt(document.getElementById('modal-tone').value) / 100 : 0.5);
    const r = (document.getElementById('modal-reso') ? parseInt(document.getElementById('modal-reso').value) / 100 : 0.5);
    const mx = (document.getElementById('modal-mix') ? parseInt(document.getElementById('modal-mix').value) / 100 : 0.5);
    drawModalGraph(mg, 'formant', t, r, mx, '32, 208, 176');
  }

  // Modal controls wiring
  const modalTypeGroup = document.getElementById('modal-type-group');
  const modalTypeVal = document.getElementById('modal-type-val');
  const modalTone = document.getElementById('modal-tone');
  const modalToneVal = document.getElementById('modal-tone-val');
  const modalReso = document.getElementById('modal-reso');
  const modalResoVal = document.getElementById('modal-reso-val');
  const modalMix = document.getElementById('modal-mix');
  const modalMixVal = document.getElementById('modal-mix-val');
  let modalType = 'formant';
  const redrawModal = () => {
    const mgc = document.getElementById('modal-graph'); if (!mgc) return;
    const t = modalTone ? parseInt(modalTone.value) / 100 : 0.5;
    const r = modalReso ? parseInt(modalReso.value) / 100 : 0.5;
    const m = modalMix ? parseInt(modalMix.value) / 100 : 0.5;
    drawModalGraph(mgc, modalType, t, r, m, '32, 208, 176');
  };
  if (modalTypeGroup && !modalTypeGroup.hasAttribute('data-toggle-group')) {
    setupToggleGroup(modalTypeGroup, modalTypeVal, (btn) => {
      const type = parseInt(btn.getAttribute('data-type'));  // 0=Formant (passthrough), 1=Modal (8-mode resonator)
      modalType = (type === 1) ? 'modal' : 'formant';
      const typeNames = ['Formant', 'Modal'];
      if (modalTypeVal) modalTypeVal.textContent = typeNames[type];
      sendParam(Params.MODAL_TYPE, normalize(type, 0, 1));  // 0-1 range (2 types)
      redrawModal();
    });
  }
  if (modalTone) modalTone.addEventListener('input', () => {
    if (modalToneVal) modalToneVal.innerHTML = `${modalTone.value}<span class=\"unit\">%</span>`;
    sendParam(Params.MODAL_TONE, parseInt(modalTone.value) / 100);
    redrawModal();
  });
  if (modalReso) modalReso.addEventListener('input', () => {
    if (modalResoVal) modalResoVal.innerHTML = `${modalReso.value}<span class=\"unit\">%</span>`;
    sendParam(Params.MODAL_RESO, parseInt(modalReso.value) / 100);
    redrawModal();
  });
  if (modalMix) modalMix.addEventListener('input', () => {
    if (modalMixVal) modalMixVal.innerHTML = `${modalMix.value}<span class=\"unit\">%</span>`;
    sendParam(Params.MODAL_MIX, parseInt(modalMix.value) / 100);
    redrawModal();
  });

  // Test connection
  // NOTE: DSP側の OnWebViewReady() がすべてのパラメータ値を GUI に送信するため、
  // ここから初期値を送信する必要はない。DSP が master of truth。
  setTimeout(() => {
    if (checkBridge()) {
      console.log('Bridge is ready! Waiting for parameter values from DSP...');
    }
  }, 100);

  // Initialize sliding toggle groups
  document.querySelectorAll('[data-toggle-group]').forEach((el) => {
    const id = el.id;
    const instance = new SlidingToggleGroup(el, {
      onChange: (value, index) => {
        switch (id) {
          case 'voice-mode-group': {
            const modeNames = ['Mono', 'Poly', 'Unison'];
            const display = document.getElementById('voice-mode-val');
            if (display) display.textContent = modeNames[index] || 'Mono';
            sendParam(Params.MASTER_VOICING_MODE, normalize(index, 0, 2));
            break;
          }
          case 'noise-type-group': {
            const typeNames = ['Analog', 'Digital', 'Arcade'];
            const display = document.getElementById('noise-type-val');
            if (display) display.textContent = typeNames[index] || 'Analog';
            sendParam(Params.NOISE_TYPE, normalize(index, 0, 2));
            if (window.noiseViz) window.noiseViz.setType(index);
            const label = document.getElementById('noise-variant-label');
            const val = document.getElementById('noise-variant-val');
            const slider = document.getElementById('noise-variant');
            if (label && val && slider) {
              const v = parseInt(slider.value);
              if (index === 1) { label.textContent = 'Resolution'; const bits = 2 + Math.round((v / 100) * 15); val.textContent = bits + ' bit'; }
              else if (index === 2) { label.textContent = 'Length'; const length = 7 + Math.round((v / 100) * 10); val.textContent = String(length); }
              else { label.textContent = 'Color'; val.textContent = (v / 100).toFixed(2); }
            }
            break;
          }
          case 'transient-mode-group': {
            const modeIds = ['modal', 'karplus', 'kick', 'snare', 'hihat', 'zap'];
            const modeNames = ['Modal', 'Karplus', 'Kick', 'Snare', 'Hi-Hat', 'Zap'];
            const display = document.getElementById('transient-mode-val');
            if (display) display.textContent = modeNames[index] || 'Modal';
            if (window.transientViz) window.transientViz.setMode(modeIds[index] || 'modal');
            // Send mode index to plugin (0-5 normalized)
            const normalized = normalize(index, 0, 5);
            console.log(`🔧 TRANSIENT MODE: index=${index}, name=${modeNames[index]}, normalized=${normalized}`);
            sendParam(Params.TRANSIENT_MODE, normalized);
            break;
          }
          case 'lfo1-wave-group': {
            const waveNames = ['Sine', 'Triangle', 'Square', 'Saw', 'Random'];
            const display = document.getElementById('lfo1-wave-val');
            if (display) display.textContent = waveNames[index] || 'Sine';
            sendParam(Params.LFO1_WAVE, normalize(index, 0, 4));
            if (window.lfo1Viz) window.lfo1Viz.setWave(index);
            break;
          }
          case 'lfo2-wave-group': {
            const waveNames = ['Sine', 'Triangle', 'Square', 'Saw', 'Random'];
            const display = document.getElementById('lfo2-wave-val');
            if (display) display.textContent = waveNames[index] || 'Sine';
            sendParam(Params.LFO2_WAVE, normalize(index, 0, 4));
            if (window.lfo2Viz) window.lfo2Viz.setWave(index);
            break;
          }
          case 'filter-type-group': {
            const typeNames = ['Lowpass', 'Highpass', 'Bandpass', 'Notch', 'Ladder', 'Acid'];
            const display = document.getElementById('filter-type-val');
            if (display) display.textContent = typeNames[index] || 'Lowpass';
            sendParam(Params.FILTER_1_TYPE, normalize(index, 0, 5));
            if (window.filter1Viz) window.filter1Viz.setType(index >= 4 ? 0 : index);
            break;
          }
          case 'filter2-type-group': {
            const typeNames = ['Lowpass', 'Highpass', 'Bandpass', 'Notch', 'Ladder', 'Acid'];
            const display = document.getElementById('filter2-type-val');
            if (display) display.textContent = typeNames[index] || 'Lowpass';
            sendParam(Params.FILTER_2_TYPE, normalize(index, 0, 5));
            if (window.filter2Viz) window.filter2Viz.setType(index >= 4 ? 0 : index);
            break;
          }
          case 'modal-type-group': {
            const typeNames = ['Formant', 'Modal'];
            const typeIndex = Math.max(0, Math.min(typeNames.length - 1, index));
            modalType = (typeIndex === 1) ? 'modal' : 'formant';
            if (modalTypeVal) modalTypeVal.textContent = typeNames[typeIndex];
            sendParam(Params.MODAL_TYPE, normalize(typeIndex, 0, 1));  // 0-1 range (2 types)
            redrawModal();
            break;
          }
          case 'filter-slope-group': {
            // Map button values to parameter index (0=12dB, 1=24dB)
            const slopeIndex = value === '12' ? 0 : 1;
            const slopeValue = value === '12' ? 12 : 24;
            window.filterSlope = slopeValue;
            localStorage.setItem('awaon_filter_slope', slopeValue);
            // Send parameter to plugin (normalize 0-1 for enum: 0/1)
            sendParam(Params.FILTER_SLOPE, normalize(slopeIndex, 0, 1));
            console.log(`🔧 FILTER SLOPE: ${slopeValue}dB/octave (index=${slopeIndex})`);
            break;
          }
          case 'filter2-slope-group': {
            // Map button values to parameter index (0=12dB, 1=24dB)
            const slopeIndex = value === '12' ? 0 : 1;
            const slopeValue = value === '12' ? 12 : 24;
            window.filter2Slope = slopeValue;
            localStorage.setItem('awaon_filter2_slope', slopeValue);
            // Send parameter to plugin (normalize 0-1 for enum: 0/1)
            sendParam(Params.FILTER2_SLOPE, normalize(slopeIndex, 0, 1));
            console.log(`🔧 FILTER 2 SLOPE: ${slopeValue}dB/octave (index=${slopeIndex})`);
            break;
          }
          case 'osc1-clip-toggle': {
            if (window.osc1Showcase) {
              window.osc1Showcase.clipMode = value;
              window.osc1Showcase.updateDisplay();
              window.osc1Showcase.sendClipModeToPlugin();
            }
            break;
          }
          case 'osc2-clip-toggle': {
            if (window.osc2Showcase) {
              window.osc2Showcase.clipMode = value;
              window.osc2Showcase.updateDisplay();
              window.osc2Showcase.sendClipModeToPlugin();
            }
            break;
          }
          case 'signals-clip-toggle': {
            const modeNames = ['Limit', 'Fold', 'Loop'];
            const display = document.getElementById('signals-clip-val');
            if (display) display.textContent = modeNames[index] || 'Limit';
            sendParam(Params.SIGNALS_CLIP_MODE, normalize(index, 0, 2));
            break;
          }
          default: break;
        }
      }
    });
    if (id) window.__toggleGroups[id] = instance;
  });

  // Restore filter slope from localStorage
  const savedFilterSlope = localStorage.getItem('awaon_filter_slope');
  if (savedFilterSlope) {
    const slopeValue = parseInt(savedFilterSlope, 10);
    const slopeIndex = slopeValue === 12 ? 0 : 1;
    window.filterSlope = slopeValue;
    const filterSlopeGroup = document.getElementById('filter-slope-group');
    if (filterSlopeGroup) {
      // Restore the active button state based on saved value
      const buttons = filterSlopeGroup.querySelectorAll('.toggle-btn');
      buttons.forEach(btn => btn.classList.remove('active'));
      const targetBtn = filterSlopeGroup.querySelector(`[data-value="${slopeValue}"]`);
      if (targetBtn) {
        targetBtn.classList.add('active');
      }
      // Send parameter to plugin after restoration
      if (typeof sendParam === 'function') {
        sendParam(Params.FILTER_SLOPE, normalize(slopeIndex, 0, 1));
      }
      console.log(`🔧 Restored Filter Slope: ${slopeValue}dB/octave from localStorage`);
    }
  }

  // Restore filter 2 slope from localStorage
  const savedFilter2Slope = localStorage.getItem('awaon_filter2_slope');
  if (savedFilter2Slope) {
    const slopeValue = parseInt(savedFilter2Slope, 10);
    const slopeIndex = slopeValue === 12 ? 0 : 1;
    window.filter2Slope = slopeValue;
    const filter2SlopeGroup = document.getElementById('filter2-slope-group');
    if (filter2SlopeGroup) {
      // Restore the active button state based on saved value
      const buttons = filter2SlopeGroup.querySelectorAll('.toggle-btn');
      buttons.forEach(btn => btn.classList.remove('active'));
      const targetBtn = filter2SlopeGroup.querySelector(`[data-value="${slopeValue}"]`);
      if (targetBtn) {
        targetBtn.classList.add('active');
      }
      // Send parameter to plugin after restoration
      if (typeof sendParam === 'function') {
        sendParam(Params.FILTER2_SLOPE, normalize(slopeIndex, 0, 1));
      }
      console.log(`🔧 Restored Filter 2 Slope: ${slopeValue}dB/octave from localStorage`);
    }
  }

  // Setup keyboard dock toggle from header button
  setupKeyboardDock();
  setupKeyboardOctaveControls();
  setupKeyboardWheelIndicators();

  // UI initialization complete - hide loading screen
  updateLoadingProgress(100);
  setTimeout(() => {
    hideLoadingScreen();
  }, 500);
});

// ============================================================================
// Toggle Button Groups
// ============================================================================

// Helper function for toggle button groups
function setupToggleGroup(groupElement, valueSpan, onChangeCallback) {
  const buttons = groupElement.querySelectorAll('.toggle-btn');
  buttons.forEach(btn => {
    btn.addEventListener('click', () => {
      // Remove active class from all buttons
      buttons.forEach(b => b.classList.remove('active'));
      // Add active class to clicked button
      btn.classList.add('active');
      // Call callback
      if (onChangeCallback) {
        onChangeCallback(btn);
      }
    });
  });
}

// ============================================================================
// Build linear keyboard (C0–C5) with horizontal scroll
// ============================================================================

function midiToName(n) {
  const names = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];
  const name = names[n % 12];
  const octave = Math.floor(n / 12) - 1;
  return name + octave;
}

const KEYBOARD_MIN_NOTE = 12; // C0
const KEYBOARD_MAX_NOTE = 72; // C5
const KEYBOARD_MAX_ABS_NOTE = 108; // C8 boundary
const KEYBOARD_STEP = 12; // octave shift
let keyboardOctaveOffset = 0;

function getKeyboardContainer() {
  const root = document.getElementById('virtual-keyboard');
  if (!root) return null;
  if (root.classList.contains('keyboard-inner')) return root;
  const inner = root.querySelector('.keyboard-inner');
  return inner || root;
}

function buildKeyboard() {
  const root = document.getElementById('virtual-keyboard');
  if (!root) return;
  const kb = getKeyboardContainer();
  if (!kb) return;
  // ensure global reference used by refreshKeyToNote / event delegation
  keyboard = kb;
  kb.innerHTML = '';

  const keyMap = new Map([
    ['a', 48], ['w', 49], ['s', 50], ['e', 51], ['d', 52], ['f', 53], ['t', 54], ['g', 55], ['y', 56], ['h', 57], ['u', 58], ['j', 59],
    ['k', 60], ['o', 61], ['l', 62], ['p', 63], [';', 64], ["'", 65]
  ]);

  const minOffset = 0 - KEYBOARD_MIN_NOTE;
  const maxOffset = KEYBOARD_MAX_ABS_NOTE - KEYBOARD_MAX_NOTE;
  keyboardOctaveOffset = Math.max(minOffset, Math.min(maxOffset, keyboardOctaveOffset));
  const startNote = Math.max(0, KEYBOARD_MIN_NOTE + keyboardOctaveOffset);
  const endNote = Math.min(KEYBOARD_MAX_ABS_NOTE, KEYBOARD_MAX_NOTE + keyboardOctaveOffset);

  for (let n = startNote; n <= endNote; n++) {
    const el = document.createElement('div');
    el.className = 'key';
    if ([1, 3, 6, 8, 10].includes(n % 12)) {
      el.classList.add('black');
    } else {
      el.classList.add('white');
    }
    el.setAttribute('data-note', String(n));
    for (const [k, val] of keyMap) { if (val === n) { el.setAttribute('data-key', k); break; } }
    const span = document.createElement('span');
    span.textContent = midiToName(n);
    el.appendChild(span);
    el.addEventListener('mousedown', () => {
      el.classList.add('active');
      try { if (typeof noteOn === 'function') noteOn(n); } catch { }
    });
    el.addEventListener('mouseup', () => {
      el.classList.remove('active');
      try { if (typeof noteOff === 'function') noteOff(n); } catch { }
    });
    el.addEventListener('mouseleave', () => { el.classList.remove('active'); });
    kb.appendChild(el);
  }

  // After building keys, refresh keyboard mapping and attach mouse handlers
  refreshKeyToNote();

  // Attach mouse handlers now that keys exist
  const keys = kb.querySelectorAll('.key');
  keys.forEach(key => {
    const noteNumber = parseInt(key.getAttribute('data-note'));
    key.addEventListener('mousedown', (e) => {
      e.preventDefault();
      if (!activeNotes.has(noteNumber)) {
        activeNotes.add(noteNumber);
        key.classList.add('active');
        noteOn(noteNumber, 100);
      }
    });
    const handleMouseUp = () => {
      if (activeNotes.has(noteNumber)) {
        activeNotes.delete(noteNumber);
        key.classList.remove('active');
        noteOff(noteNumber);
      }
    };
    key.addEventListener('mouseup', handleMouseUp);
    key.addEventListener('mouseleave', handleMouseUp);
  });

  // Scroll to C3 vicinity
  const c3Index = 60 - 12; // start at 12
  const approxWidth = 42 + 4; // key width + gap
  kb.scrollLeft = Math.max(0, c3Index * approxWidth - kb.clientWidth / 2);

  updateOctaveButtons();
}

// ============================================================================
// Arpeggiator Controls (disabled: prefab only)
// ============================================================================
// NOTE: UI remains in HTML as a prefab. Interactive bindings intentionally removed.

// Voicing Mode
const voiceModeGroup = document.getElementById('voice-mode-group');
// Skip legacy wiring if using sliding toggle implementation
if (voiceModeGroup && !voiceModeGroup.hasAttribute('data-toggle-group')) {
  setupToggleGroup(voiceModeGroup, document.getElementById('voice-mode-val'), (btn) => {
    const mode = parseInt(btn.getAttribute('data-value'));  // Fixed: HTML uses data-value, not data-mode
    const modeNames = ['Mono', 'Poly', 'Unison'];
    document.getElementById('voice-mode-val').textContent = modeNames[mode];
    sendParam(Params.MASTER_VOICING_MODE, normalize(mode, 0, 2));

    // Enable/disable Unison Detune based on voice mode
    updateUnisonDetuneState(mode);
  });
}

// Unison Detune control (enabled only in Unison mode)
const unisonDetuneSlider = document.getElementById('unison-detune');
if (unisonDetuneSlider) {
  unisonDetuneSlider.addEventListener('input', (e) => {
    const cents = parseInt(e.target.value);
    const valDisplay = document.getElementById('unison-detune-val');
    if (valDisplay) {
      valDisplay.textContent = cents + '¢';
    }
    sendParam(Params.UNISON_DETUNE, normalize(cents, 0, 200));
  });
}

// Helper function to enable/disable Unison Detune based on voice mode
function updateUnisonDetuneState(voiceMode) {
  const slider = document.getElementById('unison-detune');
  if (slider) {
    // Enable only when in Unison mode (voiceMode === 2)
    slider.disabled = (voiceMode !== 2);
    if (voiceMode === 2) {
      slider.style.opacity = '1';
      slider.style.pointerEvents = 'auto';
    } else {
      slider.style.opacity = '0.5';
      slider.style.pointerEvents = 'none';
    }
  }
}

// OSC1 Wavetable Select
const osc1WaveSelect = document.getElementById('osc1-wave');
if (osc1WaveSelect) {
  osc1WaveSelect.addEventListener('change', (e) => {
    const value = parseInt(e.target.value);
    const waveNames = ['Sine', 'Saw', 'Square', 'Triangle'];
    document.getElementById('osc1-wave-val').textContent = waveNames[value] || 'Sine';
    sendParam(Params.OSC1_WAVE, value);
  });
}

// OSC2 Wavetable Select
const osc2WaveSelect = document.getElementById('osc2-wave');
if (osc2WaveSelect) {
  osc2WaveSelect.addEventListener('change', (e) => {
    const value = parseInt(e.target.value);
    const waveNames = ['Sine', 'Saw', 'Square', 'Triangle'];
    document.getElementById('osc2-wave-val').textContent = waveNames[value] || 'Sine';
    sendParam(Params.OSC2_WAVE, value);
  });
}

// OSC1 Sync Checkbox
const osc1SyncCheckbox = document.getElementById('osc1-sync');
if (osc1SyncCheckbox) {
  osc1SyncCheckbox.addEventListener('change', (e) => {
    sendParam(Params.OSC1_SYNC, e.target.checked ? 1.0 : 0.0);
  });
}

// OSC2 Detune Checkbox
const osc2DetuneCheckbox = document.getElementById('osc2-detune');
if (osc2DetuneCheckbox) {
  osc2DetuneCheckbox.addEventListener('change', (e) => {
    const isDetune = e.target.checked;
    sendParam(Params.OSC2_DETUNE, isDetune ? 1.0 : 0.0);

    // Disable OSC2 Semi slider when in DETUNE mode
    const osc2SemiSlider = document.getElementById('osc2-semi');
    if (osc2SemiSlider) {
      osc2SemiSlider.disabled = isDetune;
    }
  });
}

// Noise Type Toggle
const noiseTypeGroup = document.getElementById('noise-type-group');
if (noiseTypeGroup && !noiseTypeGroup.hasAttribute('data-toggle-group')) {
  setupToggleGroup(noiseTypeGroup, document.getElementById('noise-type-val'), (btn) => {
    const type = parseInt(btn.getAttribute('data-value'));  // Fixed: HTML uses data-value, not data-type
    const typeNames = ['Analog', 'Digital', 'Arcade'];
    document.getElementById('noise-type-val').textContent = typeNames[type];
    sendParam(Params.NOISE_TYPE, normalize(type, 0, 2));
  });
}

// LFO1 Waveform Toggle
const lfo1WaveGroup = document.getElementById('lfo1-wave-group');
if (lfo1WaveGroup && !lfo1WaveGroup.hasAttribute('data-toggle-group')) {
  setupToggleGroup(lfo1WaveGroup, document.getElementById('lfo1-wave-val'), (btn) => {
    const wave = parseInt(btn.getAttribute('data-wave'));
    const waveNames = ['Sine', 'Triangle', 'Square', 'Saw', 'Random'];
    document.getElementById('lfo1-wave-val').textContent = waveNames[wave];
    sendParam(Params.LFO1_WAVE, normalize(wave, 0, 4));
  });
}

// LFO2 Waveform Toggle
const lfo2WaveGroup = document.getElementById('lfo2-wave-group');
if (lfo2WaveGroup && !lfo2WaveGroup.hasAttribute('data-toggle-group')) {
  setupToggleGroup(lfo2WaveGroup, document.getElementById('lfo2-wave-val'), (btn) => {
    const wave = parseInt(btn.getAttribute('data-wave'));
    const waveNames = ['Sine', 'Triangle', 'Square', 'Saw', 'Random'];
    document.getElementById('lfo2-wave-val').textContent = waveNames[wave];
    sendParam(Params.LFO2_WAVE, normalize(wave, 0, 4));
  });
}

// Filter 1 Type Toggle
const filterTypeGroup = document.getElementById('filter-type-group');
if (filterTypeGroup && !filterTypeGroup.hasAttribute('data-toggle-group')) {
  setupToggleGroup(filterTypeGroup, document.getElementById('filter-type-val'), (btn) => {
    const type = parseInt(btn.getAttribute('data-type'));
    const typeNames = ['Lowpass', 'Highpass', 'Bandpass', 'Notch', 'Ladder', 'Acid'];
    document.getElementById('filter-type-val').textContent = typeNames[type];
    sendParam(Params.FILTER_1_TYPE, normalize(type, 0, 5));  // 6 types: 0..5

    // Update filter visualizer
    if (window.filter1Viz) {
      window.filter1Viz.setType(type >= 4 ? 0 : type);
    }
  });
}

// Filter 2 Type Toggle
const filter2TypeGroup = document.getElementById('filter2-type-group');
if (filter2TypeGroup && !filter2TypeGroup.hasAttribute('data-toggle-group')) {
  setupToggleGroup(filter2TypeGroup, document.getElementById('filter2-type-val'), (btn) => {
    const type = parseInt(btn.getAttribute('data-type'));
    const typeNames = ['Lowpass', 'Highpass', 'Bandpass', 'Notch', 'Ladder', 'Acid'];
    document.getElementById('filter2-type-val').textContent = typeNames[type];
    sendParam(Params.FILTER_2_TYPE, normalize(type, 0, 5));  // 6 types: 0..5

    // Update filter visualizer
    if (window.filter2Viz) {
      window.filter2Viz.setType(type >= 4 ? 0 : type);
    }
  });
}

// Master Portamento
const masterPortaSlider = document.getElementById('master-porta');
const masterPortaVal = document.getElementById('master-porta-val');
if (masterPortaSlider) {
  masterPortaSlider.addEventListener('input', (e) => {
    const sliderValue = parseInt(e.target.value) / 100; // 0-1
    const seconds = sliderValue;  // Linear range 0-1 seconds (no log scaling)
    const normalized = sliderValue;

    masterPortaVal.innerHTML = seconds.toFixed(2) + '<span class="unit">s</span>';

    sendParam(Params.MASTER_PORTAMENTO, normalized);
  });
}

// ============================================================================
// Wavetable Showcase
// ============================================================================

// Factory wavetable template
const factoryWavetableTemplate = [
  { id: 0, name: 'Sine', type: 'sine', isCustom: false, isUnsaved: false, customData: null, originalName: 'Sine', originalType: 'sine' },
  { id: 1, name: 'Sawtooth', type: 'saw', isCustom: false, isUnsaved: false, customData: null, originalName: 'Sawtooth', originalType: 'saw' },
  { id: 2, name: 'Square', type: 'square', isCustom: false, isUnsaved: false, customData: null, originalName: 'Square', originalType: 'square' },
  { id: 3, name: 'Triangle', type: 'triangle', isCustom: false, isUnsaved: false, customData: null, originalName: 'Triangle', originalType: 'triangle' },
  { id: 4, name: 'Ramp', type: 'ramp', isCustom: false, isUnsaved: false, customData: null, originalName: 'Ramp', originalType: 'ramp' },
  { id: 5, name: 'Parabola', type: 'parabola', isCustom: false, isUnsaved: false, customData: null, originalName: 'Parabola', originalType: 'parabola' },
];

// Create independent wavetable arrays for each bank (OSC1 A/B, OSC2 A/B)
// Each bank has its own 6 wavetable slots (factory primitives)
let wavetablesOsc1A = JSON.parse(JSON.stringify(factoryWavetableTemplate));
let wavetablesOsc1B = JSON.parse(JSON.stringify(factoryWavetableTemplate));
let wavetablesOsc2A = JSON.parse(JSON.stringify(factoryWavetableTemplate));
let wavetablesOsc2B = JSON.parse(JSON.stringify(factoryWavetableTemplate));

// Snapshot storage (key: "oscN_bank_index")
const wavetableSnapshots = new Map();

// Helper: Get wavetable array for a specific showcase and bank
// Cache for wavetable arrays to ensure object persistence
const __wavetableArrayCache = {};

function getWavetableArray(showcasePrefix, bank) {
  const key = `${showcasePrefix}_${bank}`;

  // Get base factory wavetables
  let factoryWavetables;
  switch (key) {
    case 'osc1_A': factoryWavetables = wavetablesOsc1A; break;
    case 'osc1_B': factoryWavetables = wavetablesOsc1B; break;
    case 'osc2_A': factoryWavetables = wavetablesOsc2A; break;
    case 'osc2_B': factoryWavetables = wavetablesOsc2B; break;
    default: factoryWavetables = wavetablesOsc1A;
  }

  // Get user wavetables from library
  const userWaveforms = window.wavetableLibrary?.getUserWaveforms() || [];

  // Check if cache is valid (same number of user wavetables)
  if (__wavetableArrayCache[key] && __wavetableArrayCache[key].userCount === userWaveforms.length) {
    return __wavetableArrayCache[key].array;
  }

  // Convert user wavetables to factory format and append
  const userWavetables = userWaveforms.map((wf, idx) => ({
    id: factoryWavetables.length + idx,
    name: wf.name,
    type: 'user',
    isCustom: true,
    isUnsaved: false,
    customData: null,  // Will be loaded on demand
    filename: wf.filename,
    originalName: wf.name,
    originalType: 'user'
  }));

  // Create and cache combined array: factory (0-5) + user (6+)
  const combinedArray = [...factoryWavetables, ...userWavetables];
  __wavetableArrayCache[key] = {
    array: combinedArray,
    userCount: userWaveforms.length
  };

  return combinedArray;
}

// Helper: Get C++ slot index for a specific showcase and bank
function getCppSlot(showcasePrefix, bank) {
  const key = `${showcasePrefix}_${bank}`;
  switch (key) {
    case 'osc1_A': return 0;  // Osc1A
    case 'osc1_B': return 1;  // Osc1B
    case 'osc2_A': return 2;  // Osc2A
    case 'osc2_B': return 3;  // Osc2B
    default: return 0;
  }
}

// Legacy: Keep global wavetables for backward compatibility (points to Osc1A)
let wavetables = wavetablesOsc1A;

// Reset a wavetable slot to its original primitive
function resetWavetable(index) {
  if (index >= 0 && index < wavetables.length) {
    wavetables[index].isCustom = false;
    wavetables[index].customData = null;
    wavetables[index].name = wavetables[index].originalName;
    wavetables[index].type = wavetables[index].originalType;
    wavetableSnapshots.delete(index);
    console.log(`Reset wavetable ${index} to ${wavetables[index].originalName}`);
  }
}

// Find wavetable index by bank and name (for preset loading)
// Returns the index in the wavetable array, or -1 if not found
function findWavetableIndexByBankName(bank, name, oscShowcasePrefix) {
  const wavetableArray = getWavetableArray(oscShowcasePrefix, 'A');  // Get factory + user wavetables

  if (bank === 'Factory') {
    // Search factory wavetables (first 6 items in the array)
    const factoryIndex = wavetableArray.findIndex(wt => wt.name === name && !wt.isCustom);
    if (factoryIndex !== -1) {
      console.log(`✓ Found Factory wavetable "${name}" at index ${factoryIndex}`);
      return factoryIndex;
    }
  } else if (bank === 'User') {
    // Search user wavetables (items after factory ones)
    const userIndex = wavetableArray.findIndex(wt => wt.name === name && wt.isCustom);
    if (userIndex !== -1) {
      console.log(`✓ Found User wavetable "${name}" at index ${userIndex}`);
      return userIndex;
    }
  }

  console.warn(`⚠️  Wavetable not found: bank="${bank}", name="${name}"`);
  return -1;
}

// Update waveform preview canvas
function updateWaveformPreview(oscId, waveformData) {
  const canvas = document.getElementById(`osc${oscId}-waveform-canvas`);
  if (!canvas) return;

  const ctx = canvas.getContext('2d');
  const width = canvas.width;
  const height = canvas.height;

  // Get theme color based on OSC
  const themeColor = oscId === 1 ? THEME_COLORS.osc1 : THEME_COLORS.osc2;

  // Clear canvas
  ctx.fillStyle = '#0a0a0a';
  ctx.fillRect(0, 0, width, height);

  // Draw waveform
  ctx.strokeStyle = `rgba(${themeColor}, 0.9)`;
  ctx.lineWidth = 2;
  ctx.beginPath();

  for (let i = 0; i < width; i++) {
    const dataIndex = Math.floor((i / width) * waveformData.length);
    const value = waveformData[dataIndex];
    const y = height / 2 - (value * height / 2);

    if (i === 0) {
      ctx.moveTo(i, y);
    } else {
      ctx.lineTo(i, y);
    }
  }
  ctx.stroke();
}

//==============================================================================
// Primitive Waveform Library (Single Source of Truth)
//==============================================================================
// All waveforms start at phase 0 (value = 0) for consistency
const PRIMITIVE_WAVEFORMS = {
  sine: (phase) => {
    // Sine: 0 → 1 → 0 → -1 → 0
    return Math.sin(2 * Math.PI * phase);
  },

  saw: (phase) => {
    // Sawtooth: 0 → 1 → -1 → 0 (starts at 0, rises to peak)
    const p = (phase + 0.5) % 1;
    return p * 2 - 1;
  },

  square: (phase) => {
    // Square: 0→1 for first half, -1 for second half
    // Shifted so rising edge is at phase=0
    return phase < 0.5 ? 1 : -1;
  },

  triangle: (phase) => {
    // Triangle: 0 → 1 → 0 → -1 → 0
    if (phase < 0.25) {
      return 4 * phase;  // 0 → 1
    } else if (phase < 0.75) {
      return 2 - 4 * phase;  // 1 → 0 → -1
    } else {
      return 4 * phase - 4;  // -1 → 0
    }
  },

  ramp: (phase) => {
    // Ramp (inverse saw): 0 → -1 → 1 → 0 (descending)
    const p = (phase + 0.5) % 1;
    return 1 - p * 2;
  },

  parabola: (phase) => {
    // Parabola: smooth cubic curve, less harmonics than triangle
    // 0 → 1 → 0 → -1 → 0
    if (phase < 0.25) {
      // Rising: 0 → 1
      const x = phase * 4;  // 0..1
      return x * x * (3 - 2 * x);  // smoothstep
    } else if (phase < 0.75) {
      // Falling: 1 → 0 → -1
      const x = (phase - 0.25) * 2;  // 0..1
      return 1 - x * x * (3 - 2 * x) * 2;
    } else {
      // Rising: -1 → 0
      const x = (phase - 0.75) * 4;  // 0..1
      return -1 + x * x * (3 - 2 * x);
    }
  },
};

// Get list of primitive waveform names
function getPrimitiveWaveformNames() {
  return Object.keys(PRIMITIVE_WAVEFORMS);
}

// Generate samples for a primitive waveform
function generatePrimitiveSamples(type = 'sine', sampleCount = 1024) {
  const samples = new Float32Array(sampleCount);
  const generator = PRIMITIVE_WAVEFORMS[type];

  if (!generator) {
    console.warn(`Unknown primitive type: ${type}, using sine`);
    const sineGen = PRIMITIVE_WAVEFORMS.sine;
    for (let i = 0; i < sampleCount; i++) {
      samples[i] = sineGen(i / sampleCount);
    }
    return samples;
  }

  for (let i = 0; i < sampleCount; i++) {
    const phase = i / sampleCount;
    samples[i] = generator(phase);
  }

  return samples;
}

// Initialize C++ with JS-generated primitives (replaces C++ fallback arrays)
// Called on page load to ensure C++ uses JS-managed primitives from the start
function initializePrimitivesInCpp() {
  console.log('Initializing C++ with JS-generated primitive waveforms...');

  // Default primitive for each bank on initialization: Sine (index 0)
  // This matches the UI default display and Voice constructor in C++
  const defaultPrimitive = 'sine';
  const primitiveData = generatePrimitiveSamples(defaultPrimitive, 2048);

  // Send to all 4 C++ slots
  // Note: These will be overridden when presets load or user selects different waveforms
  sendWavetable(0, primitiveData);  // OSC1 A
  sendWavetable(1, primitiveData);  // OSC1 B
  sendWavetable(2, primitiveData);  // OSC2 A
  sendWavetable(3, primitiveData);  // OSC2 B

  console.log(`✓ Initialized all oscillator banks with JS primitive: ${defaultPrimitive}`);
}

// Initialize primitives when page loads (after sendWavetable is available)
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    // Wait a bit for sendWavetable to be ready
    setTimeout(initializePrimitivesInCpp, 100);
  });
} else {
  setTimeout(initializePrimitivesInCpp, 100);
}

// Generate waveform samples (defaults to 1024 samples for preview)
function generateWaveform(waveTable, sampleCount = 1024) {
  // If custom wavetable, use custom data
  if (waveTable.isCustom && waveTable.customData) {
    const samples = new Array(sampleCount);
    const customData = waveTable.customData;
    for (let i = 0; i < sampleCount; i++) {
      const idx = Math.floor((i / sampleCount) * customData.length);
      samples[i] = customData[idx];
    }
    return samples;
  }

  // Otherwise generate primitive waveform
  const type = waveTable.type || waveTable.originalType || 'sine';
  return Array.from(generatePrimitiveSamples(type, sampleCount));
}

function getWavetableSamplesForEditing(waveTable) {
  if (!waveTable) return new Float32Array(2048);
  if (waveTable.isCustom && waveTable.customData) {
    return new Float32Array(waveTable.customData);
  }
  const type = waveTable.type || waveTable.originalType || 'sine';
  return generatePrimitiveSamples(type, 2048);
}

function ensureWaveNameHasMarker(waveTable, preferredBase = '') {
  if (!waveTable) return '';
  const currentBase = preferredBase || waveTable.name || waveTable.originalName || 'Custom';
  const stripped = currentBase.replace(/\*+$/, '').trim() || 'Custom';
  const starred = `${stripped}*`;
  waveTable.name = starred;
  return starred;
}

// Draw waveform on canvas
// Canvas drawing padding (pixels) - makes edges easier to draw
const CANVAS_PADDING = 8;

function drawWaveform(canvas, waveform, themeColor) {
  const ctx = canvas.getContext('2d');
  const { cssWidth: width, cssHeight: height } = resizeCanvasToDisplaySize(canvas);
  const centerY = height / 2;
  const amplitude = height * 0.42;

  // Drawing area with padding
  const drawLeft = CANVAS_PADDING;
  const drawRight = width - CANVAS_PADDING;
  const drawWidth = drawRight - drawLeft;

  // Clear canvas (no background grid)
  ctx.clearRect(0, 0, width, height);

  // Waveform stroke
  ctx.strokeStyle = `rgba(${themeColor}, 1)`;
  ctx.lineWidth = 2;
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';
  ctx.beginPath();
  for (let i = 0; i <= drawWidth; i++) {
    const t = i / drawWidth;
    const sampleIndex = Math.floor(t * (waveform.length - 1));
    const sample = waveform[sampleIndex];
    const y = centerY - sample * amplitude;
    const x = drawLeft + i;
    if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
  }
  ctx.stroke();
}

// Draw two waveforms overlaid (A/B), with non-selected at 50% alpha
function drawWaveformsOverlay(canvas, waveA, waveB, themeColor, active = 'A', skipClear = false) {
  const ctx = canvas.getContext('2d');
  const { cssWidth: width, cssHeight: height } = resizeCanvasToDisplaySize(canvas);
  const centerY = height / 2;
  const amplitude = height * 0.42;

  // Drawing area with padding
  const drawLeft = CANVAS_PADDING;
  const drawRight = width - CANVAS_PADDING;
  const drawWidth = drawRight - drawLeft;

  if (!skipClear) {
    ctx.clearRect(0, 0, width, height);
  }
  ctx.lineWidth = 2;
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';
  ctx.strokeStyle = `rgba(${themeColor}, 1)`;

  const drawOne = (wave, alpha) => {
    ctx.globalAlpha = alpha;
    ctx.beginPath();
    for (let i = 0; i <= drawWidth; i++) {
      const t = i / drawWidth;
      const sampleIndex = Math.floor(t * (wave.length - 1));
      const sample = wave[sampleIndex];
      const y = centerY - sample * amplitude;
      const x = drawLeft + i;
      if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
    }
    ctx.stroke();
  };

  // Active bank at 1.0 opacity, inactive at 0.3
  const alphaA = (active === 'A') ? 1.0 : 0.3;
  const alphaB = (active === 'B') ? 1.0 : 0.3;
  drawOne(waveA, alphaA);
  drawOne(waveB, alphaB);
  ctx.globalAlpha = 1;
}

// Wavetable Showcase Controller
class WavetableShowcase {
  constructor(prefix, paramIndex, themeColor) {
    this.prefix = prefix;
    this.paramIndex = paramIndex;
    this.themeColor = themeColor;
    this.currentIndex = 0; // legacy single bank index
    this.banks = { A: 0, B: 0 };
    this.mode = 'A'; // 'A' or 'B' (default to A)
    this.compoundMode = 'fade';
    this.clipMode = 'limit'; // 'limit', 'fold', or 'loop'
    this.inlineEditor = null;

    this.canvas = document.getElementById(`${prefix}-waveform-canvas`);
    this.label = document.getElementById(`${prefix}-wave-label`);
    this.prevBtn = document.getElementById(`${prefix}-prev-btn`);
    this.nextBtn = document.getElementById(`${prefix}-next-btn`);
    this.gridBtn = document.getElementById(`${prefix}-grid-btn`);
    this.editBtn = document.getElementById(`${prefix}-edit-btn`);

    // Optional A/B bank group
    this.abGroup = document.getElementById(`${prefix}-ab-group`);
    this.compGroup = document.getElementById(`${prefix}-comp-group`);

    this.setupEventListeners();
    this.updateModeUI();  // Set initial UI state based on mode
    this.updateDisplay();
  }

  setupEventListeners() {
    if (this.prevBtn) {
      this.prevBtn.addEventListener('click', () => this.previous());
    }
    if (this.nextBtn) {
      this.nextBtn.addEventListener('click', () => this.next());
    }
    if (this.gridBtn) {
      this.gridBtn.addEventListener('click', () => this.openGrid());
    }
    // NOTE: Edit button handler is managed by standalone code (lines ~2024-2055)
    // to properly handle custom wavetable uploads with parameter synchronization
    if (this.abGroup && window.__toggleGroups) {
      // instantiate if not already
      const group = new SlidingToggleGroup(this.abGroup, {
        onChange: (val) => {
          const v = String(val).toUpperCase();
          this.mode = (v === 'B') ? 'B' : 'A';
          this.updateDisplay();
          this.sendToPlugin();  // Send BANK parameter when switching A/B
        }
      });
      // ensure indicator respects vertical layout
      window.__toggleGroups[this.abGroup.id] = group;
    }
    if (this.compGroup) {
      const tg = new SlidingToggleGroup(this.compGroup, {
        onChange: (val) => {
          const m = String(val).toLowerCase();
          if (['fade', 'phase', 'multiply', 'mask'].includes(m)) this.compoundMode = m;
          this.updateDisplay();  // Refresh display with new compound mode
          this.sendCompoundToPlugin();  // Send COMPOUND parameter when mode changes
        }
      });
      window.__toggleGroups[this.compGroup.id] = tg;
    }
  }

  setInlineEditor(editor) {
    this.inlineEditor = editor;
  }

  // Get the wavetable array for the current bank
  getWavetables(bank) {
    const b = bank || this.mode;
    return getWavetableArray(this.prefix, b);
  }

  // Get C++ slot for the current bank
  getCppSlotForBank(bank) {
    const b = bank || this.mode;
    return getCppSlot(this.prefix, b);
  }

  previous() {
    const key = (this.mode === 'B') ? 'B' : 'A';
    const wavetables = this.getWavetables(key);
    const idx = this.banks[key];
    this.banks[key] = (idx - 1 + wavetables.length) % wavetables.length;
    this.loadWavetableIfNeeded(key);
  }

  next() {
    const key = (this.mode === 'B') ? 'B' : 'A';
    const wavetables = this.getWavetables(key);
    const idx = this.banks[key];
    this.banks[key] = (idx + 1) % wavetables.length;
    this.loadWavetableIfNeeded(key);
  }

  // Load user wavetable data if needed (async)
  loadWavetableIfNeeded(bank) {
    const wavetables = this.getWavetables(bank);
    const currentIndex = this.banks[bank];
    const table = wavetables[currentIndex];

    // If it's a user wavetable and data not loaded yet
    if (table.type === 'user' && table.filename && !table.customData) {
      console.log(`📂 Loading user wavetable: ${table.filename}`);

      // Load full wavetable data (2048 samples)
      if (typeof wavetableLoadFromFile === 'function') {
        wavetableLoadFromFile(table.filename, (samples) => {
          if (samples && samples.length === 2048) {
            table.customData = new Float32Array(samples);
            console.log(`✅ Loaded user wavetable: ${table.name} (${samples.length} samples)`);

            // Now update display and send to plugin
            this.updateDisplay();
            this.sendToPlugin();
          } else {
            console.error(`❌ Failed to load user wavetable: ${table.filename}`);
            // Fallback to first factory wavetable
            this.banks[bank] = 0;
            this.updateDisplay();
            this.sendToPlugin();
          }
        });
      } else {
        console.error('❌ wavetableLoadFromFile not available');
        // Fallback to first factory wavetable
        this.banks[bank] = 0;
        this.updateDisplay();
        this.sendToPlugin();
      }
    } else {
      // Factory wavetable or already loaded user wavetable
      this.updateDisplay();
      this.sendToPlugin();
    }
  }

  openGrid() {
    const key = (this.mode === 'B') ? 'B' : 'A';
    const wavetables = this.getWavetables(key);
    const catalog = new WavetableCatalog(wavetables, this.banks[key], this.themeColor, (selectedIndex) => {
      this.banks[key] = selectedIndex;
      this.updateDisplay();
      this.sendToPlugin();
    }, this.prefix, key);  // Pass showcase info for proper array access
    catalog.open();
  }

  // Select a wavetable by index for a specific bank (used by preset loading)
  selectWavetable(bank, wavetableIndex) {
    if (!['A', 'B'].includes(bank)) {
      console.warn(`⚠️  Invalid bank: ${bank}`);
      return;
    }

    const wavetables = this.getWavetables(bank);
    if (wavetableIndex < 0 || wavetableIndex >= wavetables.length) {
      console.warn(`⚠️  Invalid wavetable index: ${wavetableIndex} (max ${wavetables.length - 1})`);
      return;
    }

    // Set the wavetable index for this bank
    this.banks[bank] = wavetableIndex;
    // console.log(`Selected wavetable for ${this.prefix}_${bank}: index ${wavetableIndex} (${wavetables[wavetableIndex].name})`);

    // Load if needed (async for user wavetables)
    this.loadWavetableIfNeeded(bank);
  }

  sendWavetableDataToPlugin(float32Data) {
    // Convert Float32Array to regular array for iPlug2
    const samples = Array.from(float32Data);

    // Send via SCMFUI (Send Control Message From UI)
    try {
      window.webkit.messageHandlers.callback.postMessage({
        msg: 'SCMFUI',
        ctrlTag: this.prefix.toUpperCase() + '_WAVETABLE',  // e.g., "OSC1_WAVE"
        data: samples
      });
      console.log(`Sent ${samples.length} samples to ${this.prefix}`);
    } catch (e) {
      console.error('Failed to send wavetable data:', e);
    }
  }

  updateModeUI() {
    // Always show all controls (no hiding based on mode)
    const compGroup = document.getElementById(`${this.prefix}-comp-group`);
    const waveformControls = document.getElementById(`${this.prefix}-controls`);

    if (compGroup) compGroup.style.display = '';
    if (waveformControls) waveformControls.style.display = '';

    // Always enable catalog
    if (this.label) {
      this.label.dataset.catalogDisabled = 'false';
    }
  }

  applyPhaseOffset(waveform, offset) {
    // offset: 0-1, rotate samples by offset * 2048
    if (offset === 0) return waveform;

    const shiftSamples = Math.floor(offset * 2048);
    const result = new Float32Array(2048);
    for (let i = 0; i < 2048; i++) {
      result[i] = waveform[(i + shiftSamples) % 2048];
    }
    return result;
  }

  applyClipping(waveform) {
    // Apply clipping based on clipMode: limit, fold, or loop
    const result = new Float32Array(2048);
    for (let i = 0; i < 2048; i++) {
      let sample = waveform[i];

      switch (this.clipMode) {
        case 'limit':
          // Hard clip to -1.0 to +1.0
          result[i] = Math.max(-1.0, Math.min(1.0, sample));
          break;

        case 'fold':
          // Fold/reflect at boundaries (折り返し)
          while (sample > 1.0 || sample < -1.0) {
            if (sample > 1.0) {
              sample = 2.0 - sample;
            } else if (sample < -1.0) {
              sample = -2.0 - sample;
            }
          }
          result[i] = sample;
          break;

        case 'loop':
          // Wrap around (modulo)
          sample = sample % 2.0;
          if (sample > 1.0) sample -= 2.0;
          if (sample < -1.0) sample += 2.0;
          result[i] = sample;
          break;

        default:
          result[i] = sample;
      }
    }
    return result;
  }

  generateCompoundWaveform() {
    // Generate compound waveform based on A + B banks and compound mode/amount
    const wavetablesA = this.getWavetables('A');
    const wavetablesB = this.getWavetables('B');
    let waveA = generateWaveform(wavetablesA[this.banks['A']], 2048);
    let waveB = generateWaveform(wavetablesB[this.banks['B']], 2048);

    // Apply phase offsets
    const offsets = this.getOffsets();
    if (offsets.a > 0) {
      waveA = this.applyPhaseOffset(waveA, offsets.a);
    }
    if (offsets.b > 0) {
      waveB = this.applyPhaseOffset(waveB, offsets.b);
    }

    const amountSlider = document.getElementById(`${this.prefix}-amount`);
    const amount = amountSlider ? (parseInt(amountSlider.value) / 100) : 0.5;  // 0-1

    const result = new Float32Array(2048);

    for (let i = 0; i < 2048; i++) {
      const a = waveA[i];
      const b = waveB[i];

      switch (this.compoundMode) {
        case 'fade':
          // Crossfade: lerp(A, B, amount)
          result[i] = a * (1 - amount) + b * amount;
          break;

        case 'phase':
          // Phase modulation: A modulates phase of B
          const phaseOffset = b * amount * 2048;  // Use B as modulator
          const modulatedIndex = (i + phaseOffset) % 2048;
          const idx = Math.floor(modulatedIndex);
          result[i] = waveA[Math.abs(idx) % 2048];
          break;

        case 'multiply':
          // Ring modulation: A * (1 + B * amount)
          result[i] = a * (1 + b * amount);
          break;

        case 'mask':
          // Waveshaping: A * (1-amt) + (A*B) * amt
          result[i] = a * (1 - amount) + (a * b) * amount;
          break;

        default:
          result[i] = a;
      }
    }

    // Apply clipping after compound processing
    return this.applyClipping(result);
  }

  updateDisplay() {
    const key = (this.mode === 'B') ? 'B' : 'A';

    // Get waveform data from bank-specific wavetables arrays (handles both primitive and custom)
    const wavetablesA = this.getWavetables('A');
    const wavetablesB = this.getWavetables('B');
    const wa = generateWaveform(wavetablesA[this.banks['A']]);
    const wb = generateWaveform(wavetablesB[this.banks['B']]);

    // Update label visibility/text (show wavetable name)
    if (this.label) {
      this.label.hidden = false;
      if (!this.label.classList.contains('is-renaming')) {
        const wavetables = this.getWavetables(key);
        const currentWavetable = wavetables[this.banks[key]];
        const wavetableName = currentWavetable.name;

        // Update bank and name spans
        const bankSpan = this.label.querySelector('.waveform-overlay-label-bank');
        const nameSpan = this.label.querySelector('.waveform-overlay-label-name');

        if (bankSpan && nameSpan) {
          // Determine if this is a user or factory wavetable
          const bankLabel = currentWavetable.isCustom ? 'User' : 'Factory';
          bankSpan.textContent = bankLabel;
          nameSpan.textContent = wavetableName;
        } else {
          // Fallback for compatibility
          this.label.textContent = wavetableName;
        }
      }
    }

    // Always draw compound waveform as background, then A/B overlay on top
    if (this.canvas) {
      const ctx = this.canvas.getContext('2d');

      // First, draw compound waveform at 30% opacity
      ctx.save();
      ctx.globalAlpha = 0.3;
      const compoundWaveform = this.generateCompoundWaveform();
      drawWaveform(this.canvas, compoundWaveform, this.themeColor);
      ctx.restore();

      // Then draw A/B overlay on top (active at 100%, inactive at 30%)
      drawWaveformsOverlay(this.canvas, wa, wb, this.themeColor, key, true);  // true = skip background clear
    }

    // Controls: always show all controls
    const navGroup = document.getElementById(`${this.prefix}-nav-group`);
    if (this.editBtn) this.editBtn.hidden = false;
    if (navGroup) navGroup.hidden = false;
    if (this.inlineEditor) this.inlineEditor.onShowcaseUpdated();
    const compVal = document.getElementById(`${this.prefix}-comp-val`);
    const clipVal = document.getElementById(`${this.prefix}-clip-val`);
    const compNames = {
      fade: 'Fade',
      phase: 'Phase',
      multiply: 'Multiply',
      mask: 'Mask'
    };
    const clipNames = {
      limit: 'Limit',
      fold: 'Fold',
      loop: 'Loop'
    };
    if (compVal) compVal.textContent = compNames[this.compoundMode] || 'Fade';
    if (clipVal) clipVal.textContent = clipNames[this.clipMode] || 'Limit';
  }

  sendToPlugin() {
    const key = (this.mode === 'B') ? 'B' : 'A';
    const inactiveKey = (key === 'A') ? 'B' : 'A';

    // Get wavetable arrays (factory + user, dynamic length)
    const wavetablesActive = this.getWavetables(key);
    const wavetablesInactive = this.getWavetables(inactiveKey);

    // Send WAVE parameter (currently active bank - A or B) - dynamic range based on array length
    const activeWaveIndex = this.banks[key];
    const maxIndex = Math.max(5, wavetablesActive.length - 1);  // At least 0-5 for C++ param range
    sendParam(this.paramIndex, normalize(Math.min(activeWaveIndex, 5), 0, 5));  // Clamp to 0-5 for C++ compatibility

    // Send BANK parameter (the inactive bank for compound blending) - dynamic range
    const bankParamIndex = (this.prefix === 'osc1') ? Params.OSC1_BANK : Params.OSC2_BANK;
    const inactiveWaveIndex = this.banks[inactiveKey];
    sendParam(bankParamIndex, normalize(Math.min(inactiveWaveIndex, 5), 0, 5));  // Clamp to 0-5 for C++ compatibility

    // Send actual wavetable data to C++ for both banks (factory primitives or custom)
    const activeSlot = wavetablesActive[this.banks[key]];
    const inactiveSlot = wavetablesInactive[this.banks[inactiveKey]];

    // Send active bank wavetable data
    const cppSlotActive = getCppSlot(this.prefix, key);
    if (activeSlot.customData) {
      sendWavetable(cppSlotActive, activeSlot.customData);
    } else {
      const primitiveData = generatePrimitiveSamples(activeSlot.type, 2048);
      sendWavetable(cppSlotActive, primitiveData);
    }

    // Send inactive bank wavetable data (for compound blending)
    const cppSlotInactive = getCppSlot(this.prefix, inactiveKey);
    if (inactiveSlot.customData) {
      sendWavetable(cppSlotInactive, inactiveSlot.customData);
    } else {
      const primitiveData = generatePrimitiveSamples(inactiveSlot.type, 2048);
      sendWavetable(cppSlotInactive, primitiveData);
    }

    // Send COMPOUND and AMOUNT parameters
    this.sendCompoundToPlugin();
    this.sendAmountToPlugin();
  }

  sendCompoundToPlugin() {
    const compoundParamIndex = (this.prefix === 'osc1') ? Params.OSC1_COMPOUND : Params.OSC2_COMPOUND;
    const modeMap = { 'fade': 0, 'phase': 1, 'multiply': 2, 'mask': 3 };
    const modeIndex = modeMap[this.compoundMode] || 0;
    sendParam(compoundParamIndex, normalize(modeIndex, 0, 3));
  }

  sendAmountToPlugin() {
    const amountParamIndex = (this.prefix === 'osc1') ? Params.OSC1_AMOUNT : Params.OSC2_AMOUNT;
    const amountSlider = document.getElementById(`${this.prefix}-amount`);
    if (amountSlider) {
      const value = parseInt(amountSlider.value) / 100;  // 0-100 → 0-1
      sendParam(amountParamIndex, value);
    }
  }

  sendOffsetsToPlugin() {
    // Send A and B offset parameters (unipolar 0-1)
    const offsetAParamIndex = (this.prefix === 'osc1') ? Params.OSC1_OFFSET_A : Params.OSC2_OFFSET_A;
    const offsetBParamIndex = (this.prefix === 'osc1') ? Params.OSC1_OFFSET_B : Params.OSC2_OFFSET_B;

    const offsetASlider = document.getElementById(`${this.prefix}-offset-a`);
    const offsetBSlider = document.getElementById(`${this.prefix}-offset-b`);

    if (offsetASlider) {
      const value = parseInt(offsetASlider.value) / 100;  // 0-100 → 0-1
      sendParam(offsetAParamIndex, value);
    }

    if (offsetBSlider) {
      const value = parseInt(offsetBSlider.value) / 100;  // 0-100 → 0-1
      sendParam(offsetBParamIndex, value);
    }
  }

  sendClipModeToPlugin() {
    // Send clip mode parameter: 0=limit, 1=fold, 2=loop
    const clipParamIndex = (this.prefix === 'osc1') ? Params.OSC1_CLIP_MODE : Params.OSC2_CLIP_MODE;
    const modeMap = { 'limit': 0, 'fold': 1, 'loop': 2 };
    const modeIndex = modeMap[this.clipMode] || 0;
    sendParam(clipParamIndex, normalize(modeIndex, 0, 2));
  }

  getOffsets() {
    // Get current offset values (0-1)
    const offsetASlider = document.getElementById(`${this.prefix}-offset-a`);
    const offsetBSlider = document.getElementById(`${this.prefix}-offset-b`);

    return {
      a: offsetASlider ? (parseInt(offsetASlider.value) / 100) : 0,
      b: offsetBSlider ? (parseInt(offsetBSlider.value) / 100) : 0
    };
  }
}

// Initialize wavetable showcases (exposed globally for edit button handlers)
window.osc1Showcase = new WavetableShowcase('osc1', Params.OSC1_WAVE, THEME_COLORS.osc1);
window.osc2Showcase = new WavetableShowcase('osc2', Params.OSC2_WAVE, THEME_COLORS.osc2);

// Amount sliders -> update values, refresh preview, and send to plugin
const osc1Amt = document.getElementById('osc1-amount');
const osc1AmtVal = document.getElementById('osc1-amount-val');
if (osc1Amt && osc1AmtVal) {
  const update = () => {
    osc1AmtVal.innerHTML = parseInt(osc1Amt.value) + '<span class="unit">%</span>';
    window.osc1Showcase.updateDisplay();
    window.osc1Showcase.sendAmountToPlugin();  // Send OSC1_AMOUNT parameter
  };
  osc1Amt.addEventListener('input', update); update();
}
const osc2Amt = document.getElementById('osc2-amount');
const osc2AmtVal = document.getElementById('osc2-amount-val');
if (osc2Amt && osc2AmtVal) {
  const update = () => {
    osc2AmtVal.innerHTML = parseInt(osc2Amt.value) + '<span class="unit">%</span>';
    window.osc2Showcase.updateDisplay();
    window.osc2Showcase.sendAmountToPlugin();  // Send OSC2_AMOUNT parameter
  };
  osc2Amt.addEventListener('input', update); update();
}

// Offset sliders (A/B) -> update values, refresh preview, and send to plugin
const osc1OffsetA = document.getElementById('osc1-offset-a');
const osc1OffsetAVal = document.getElementById('osc1-offset-a-val');
if (osc1OffsetA && osc1OffsetAVal) {
  const update = () => {
    osc1OffsetAVal.innerHTML = parseInt(osc1OffsetA.value) + '<span class="unit">%</span>';
    window.osc1Showcase.updateDisplay();
    window.osc1Showcase.sendOffsetsToPlugin();
  };
  osc1OffsetA.addEventListener('input', update); update();
}

const osc1OffsetB = document.getElementById('osc1-offset-b');
const osc1OffsetBVal = document.getElementById('osc1-offset-b-val');
if (osc1OffsetB && osc1OffsetBVal) {
  const update = () => {
    osc1OffsetBVal.innerHTML = parseInt(osc1OffsetB.value) + '<span class="unit">%</span>';
    window.osc1Showcase.updateDisplay();
    window.osc1Showcase.sendOffsetsToPlugin();
  };
  osc1OffsetB.addEventListener('input', update); update();
}

const osc2OffsetA = document.getElementById('osc2-offset-a');
const osc2OffsetAVal = document.getElementById('osc2-offset-a-val');
if (osc2OffsetA && osc2OffsetAVal) {
  const update = () => {
    osc2OffsetAVal.innerHTML = parseInt(osc2OffsetA.value) + '<span class="unit">%</span>';
    window.osc2Showcase.updateDisplay();
    window.osc2Showcase.sendOffsetsToPlugin();
  };
  osc2OffsetA.addEventListener('input', update); update();
}

const osc2OffsetB = document.getElementById('osc2-offset-b');
const osc2OffsetBVal = document.getElementById('osc2-offset-b-val');
if (osc2OffsetB && osc2OffsetBVal) {
  const update = () => {
    osc2OffsetBVal.innerHTML = parseInt(osc2OffsetB.value) + '<span class="unit">%</span>';
    window.osc2Showcase.updateDisplay();
    window.osc2Showcase.sendOffsetsToPlugin();
  };
  osc2OffsetB.addEventListener('input', update); update();
}

// ============================================================================
// Filter Response Visualizer
// ============================================================================

// Calculate filter frequency response
// Get biquad filter gain at frequency (React-style accurate implementation)
function getFilterGain(freq, cutoff, resonance, type) {
  const fc = cutoff;
  // Map resonance 0.1-20 to Q approx 0.707-15 (matching React)
  const q = Math.max(0.707, Math.pow(resonance, 1.5) * 0.5);
  const x = freq / fc; // Normalized frequency
  const x2 = x * x;

  let gainLinear = 1.0;
  const denom = Math.sqrt(Math.pow(1 - x2, 2) + Math.pow(x / q, 2));

  switch (type) {
    case 0: // Lowpass
      gainLinear = 1 / denom;
      break;
    case 1: // Highpass
      gainLinear = x2 / denom;
      break;
    case 2: // Bandpass
      gainLinear = (x / q) / denom;
      break;
    case 3: // Notch
      gainLinear = Math.abs(1 - x2) / denom;
      break;
    case 4: // Peak/Formant (simplified with two formant peaks)
      const f1 = 500; // Hz
      const f2 = 1800; // Hz
      const qF = 5; // Fixed Q for formants

      const getBandpassGain = (f, centerF, qVal) => {
        const normalizedF = f / centerF;
        const normalizedF2 = normalizedF * normalizedF;
        const d = Math.sqrt(Math.pow(1 - normalizedF2, 2) + Math.pow(normalizedF / qVal, 2));
        return (normalizedF / qVal) / d;
      };

      gainLinear = (getBandpassGain(freq, f1, qF) + getBandpassGain(freq, f2, qF)) / 2;
      break;
    case 5: // Allpass (unity gain at all frequencies, only phase shift)
      gainLinear = 1.0;
      break;
    default:
      return 0;
  }

  // Convert linear gain to dB
  return 20 * Math.log10(Math.max(0.00001, gainLinear));
}

// Draw filter response curve
function resizeCanvasToDisplaySize(canvas) {
  const dpr = window.devicePixelRatio || 1;
  let rect = canvas.getBoundingClientRect();
  // Pin CSS height once to avoid growing when we update drawing buffer size
  const isLandscape = document && document.body && document.body.classList.contains('is-landscape');
  if (!canvas.__cssHeightPx && !isLandscape) {
    const initialCssH = rect.height || parseInt(canvas.getAttribute('height') || '60', 10) || 60;
    canvas.style.height = Math.round(initialCssH) + 'px';
    canvas.__cssHeightPx = Math.round(initialCssH);
    // re-measure width after setting height style
    rect = canvas.getBoundingClientRect();
  }
  const cssWidth = Math.max(1, Math.floor(rect.width || parseInt(canvas.getAttribute('width') || '300', 10)));
  const cssHeight = Math.max(1, Math.floor(isLandscape ? rect.height : (canvas.__cssHeightPx || rect.height)));
  const displayWidth = Math.floor(cssWidth * dpr);
  const displayHeight = Math.floor(cssHeight * dpr);
  if (canvas.width !== displayWidth || canvas.height !== displayHeight) {
    canvas.width = displayWidth;
    canvas.height = displayHeight;
  }
  const ctx = canvas.getContext('2d');
  if (ctx) ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  return { cssWidth, cssHeight };
}

function drawFilterResponse(canvas, type, cutoffFreq, resonance, themeColor, mixAmount = 0.5) {
  const ctx = canvas.getContext('2d');
  const { cssWidth: W, cssHeight: H } = resizeCanvasToDisplaySize(canvas);
  ctx.clearRect(0, 0, W, H);

  // Helpers
  const clamp = (x, a, b) => Math.max(a, Math.min(b, x));
  const lerp = (a, b, t) => a + (b - a) * t;
  const logMap = (min, max, t) => { const lmin = Math.log(min), lmax = Math.log(max); return Math.exp(lerp(lmin, lmax, clamp(t, 0, 1))); };
  // Biquad (RBJ)
  function biquad(fs, fc, Q, t) {
    const w0 = (2 * Math.PI * fc) / fs, cosw0 = Math.cos(w0), sinw0 = Math.sin(w0), alpha = sinw0 / (2 * Q);
    let b0 = 0, b1 = 0, b2 = 0, a0 = 1, a1 = 0, a2 = 0;
    switch (t) {
      case 0: // lp
        b0 = (1 - cosw0) / 2; b1 = 1 - cosw0; b2 = (1 - cosw0) / 2; a0 = 1 + alpha; a1 = -2 * cosw0; a2 = 1 - alpha; break;
      case 1: // hp
        b0 = (1 + cosw0) / 2; b1 = -(1 + cosw0); b2 = (1 + cosw0) / 2; a0 = 1 + alpha; a1 = -2 * cosw0; a2 = 1 - alpha; break;
      case 2: // bp const skirt
        b0 = sinw0 / 2; b1 = 0; b2 = -sinw0 / 2; a0 = 1 + alpha; a1 = -2 * cosw0; a2 = 1 - alpha; break;
      default: // 3 notch
        b0 = 1; b1 = -2 * cosw0; b2 = 1; a0 = 1 + alpha; a1 = -2 * cosw0; a2 = 1 - alpha; break;
    }
    return { b0: b0 / a0, b1: b1 / a0, b2: b2 / a0, a1: a1 / a0, a2: a2 / a0 };
  }
  function magDb(bq, fs, f) {
    const w = (2 * Math.PI * f) / fs, c1 = Math.cos(w), s1 = Math.sin(w), c2 = Math.cos(2 * w), s2 = Math.sin(2 * w);
    const numRe = bq.b0 + bq.b1 * c1 + bq.b2 * c2;
    const numIm = -(bq.b1 * s1 + bq.b2 * s2);
    const denRe = 1 + bq.a1 * c1 + bq.a2 * c2;
    const denIm = -(bq.a1 * s1 + bq.a2 * s2);
    const mag = Math.sqrt((numRe * numRe + numIm * numIm) / (denRe * denRe + denIm * denIm));
    return 20 * Math.log10(Math.max(1e-9, mag));
  }

  // Settings
  const m = Math.max(6, Math.round(H * 0.08));
  const PW = Math.max(1, W - 2 * m);
  const PH = Math.max(1, H - 2 * m);
  const fMin = 20, fMax = 20000, fs = 48000;
  const xFromT = (t) => m + clamp(t, 0, 1) * PW;
  // Make resonance mapping more dramatic (wider Q span, stronger nonlinearity)
  // resonance is expected 0..1; push higher end aggressively
  const Q = clamp(0.35 + Math.pow(resonance, 3) * 80.0, 0.1, 80.0);
  const fc = clamp(cutoffFreq, 10, fs * 0.45);
  const bq = biquad(fs, fc, Q, type);

  // Auto-scale vertically to emphasize peak
  const N = Math.max(256, Math.floor(PW));
  const dbs = new Array(N + 1);
  let maxDb = -1e9, minDb = 1e9;
  for (let i = 0; i <= N; i++) {
    const t = i / N; const f = logMap(fMin, fMax, t); const db = magDb(bq, fs, f);
    dbs[i] = db; if (db > maxDb) maxDb = db; if (db < minDb) minDb = db;
  }
  const dbTop = Math.min(maxDb + 3, 36);
  const dbBot = Math.max(maxDb - 48, -78);
  const yFromDb = (db) => { const tt = (dbTop - db) / (dbTop - dbBot); return m + Math.max(0, Math.min(1, tt)) * PH; };

  // Draw curve only
  ctx.strokeStyle = `rgba(${themeColor}, 0.95)`;
  ctx.lineWidth = 2;
  ctx.lineJoin = 'round';
  ctx.lineCap = 'round';
  ctx.beginPath();
  for (let i = 0; i <= N; i++) {
    const t = i / N; const x = xFromT(t), y = yFromDb(dbs[i]);
    if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
  }
  ctx.stroke();

  // Fill under curve (recompute polygon from sampled points)
  const fillAlpha = 0.05 + Math.max(0, Math.min(1, mixAmount)) * 0.35;
  ctx.fillStyle = `rgba(${themeColor}, ${fillAlpha.toFixed(3)})`;
  ctx.beginPath();
  // start at left baseline
  ctx.moveTo(m, H - m);
  for (let i = 0; i <= N; i++) {
    const t = i / N;
    const x = xFromT(t);
    const y = yFromDb(dbs[i]);
    ctx.lineTo(x, y);
  }
  // close down to right baseline
  ctx.lineTo(m + PW, H - m);
  ctx.closePath();
  ctx.fill();
}

// Filter Visualizer Controller
class FilterVisualizer {
  constructor(canvasId, themeColor) {
    this.canvas = document.getElementById(canvasId);
    this.themeColor = themeColor;
    this.type = 0; // Lowpass
    this.cutoffFreq = 800;
    this.resonance = 0.3;
    this.mix = 0.5;

    this.updateDisplay();
  }

  setType(type) {
    this.type = type;
    this.updateDisplay();
  }

  setCutoff(freq) {
    this.cutoffFreq = freq;
    this.updateDisplay();
  }

  setResonance(reso) {
    this.resonance = reso;
    this.updateDisplay();
  }

  setMix(mix) {
    this.mix = Math.max(0, Math.min(1, mix));
    this.updateDisplay();
  }

  updateDisplay() {
    if (this.canvas) {
      drawFilterResponse(this.canvas, this.type, this.cutoffFreq, this.resonance, this.themeColor, this.mix);
    }
  }
}

// Initialize filter visualizers
window.filter1Viz = new FilterVisualizer('filter-1-graph', '74, 157, 255');
window.filter2Viz = new FilterVisualizer('filter2-graph', '74, 157, 255');  // Fixed: HTML uses filter2-graph not filter-2-graph

// ============================================================================
// Envelope Visualizer
// ============================================================================

const ENVELOPE_SAMPLE_RATE = 0.1; // ~100 samples per second of real time
const ENVELOPE_MIN_SAMPLES = 6;
const ENVELOPE_SUSTAIN_SAMPLES = 100;

function envelopeSampleCounts(attackMs, decayMs, releaseMs) {
  const toSamples = (ms) => Math.max(ENVELOPE_MIN_SAMPLES, Math.round(Math.max(ms, 1) * ENVELOPE_SAMPLE_RATE));
  const attackSamples = toSamples(attackMs);
  const decaySamples = toSamples(decayMs);
  const releaseSamples = toSamples(releaseMs);
  return {
    attackSamples,
    decaySamples,
    releaseSamples,
    sustainSamples: ENVELOPE_SUSTAIN_SAMPLES
  };
}

// Draw ADSR envelope curve
function drawEnvelope(canvas, attack, decay, sustain, release, themeColor, linearity = 0.5) {
  const ctx = canvas.getContext('2d');
  const { cssWidth: width, cssHeight: height } = resizeCanvasToDisplaySize(canvas);
  const margin = 6;
  const graphWidth = width - margin * 2;
  const graphHeight = height - margin * 2;

  // Clear canvas
  ctx.clearRect(0, 0, width, height);

  // Curvature modelling inspired by test.html logic (exp/lin/log) but continuous
  const lerp = (a, b, t) => a + (b - a) * clamp(t, 0, 1);
  const bias = clamp((linearity - 0.5) * 2, -1, 1); // -1 (log) .. +1 (exp)
  const attackPow = bias >= 0 ? lerp(1, 0.45, bias) : lerp(1, 2.2, -bias);
  const decayPow = bias >= 0 ? lerp(1, 2.4, bias) : lerp(1, 0.55, -bias);
  const releasePow = bias >= 0 ? lerp(1, 2.2, bias) : lerp(1, 0.5, -bias);
  const attackEase = (t) => Math.pow(clamp(t, 0, 1), attackPow);
  const decayEase = (t) => 1 - Math.pow(1 - clamp(t, 0, 1), decayPow);
  const releaseEase = (t) => 1 - Math.pow(1 - clamp(t, 0, 1), releasePow);

  const sampleCounts = envelopeSampleCounts(attack, decay, release);
  const { attackSamples, decaySamples, releaseSamples, sustainSamples } = sampleCounts;
  const values = [];
  let currentValue = 0;
  values.push(currentValue);
  const addStage = (samples, targetValue, easeFn) => {
    if (samples <= 0) samples = 1;
    for (let i = 1; i <= samples; i++) {
      const t = i / samples;
      const eased = easeFn ? easeFn(t) : t;
      const next = currentValue + (targetValue - currentValue) * eased;
      values.push(next);
    }
    currentValue = targetValue;
  };
  addStage(attackSamples, 1, attackEase);
  addStage(decaySamples, sustain, decayEase);
  for (let i = 0; i < sustainSamples; i++) {
    values.push(sustain);
  }
  addStage(releaseSamples, 0, releaseEase);
  if (values.length < 2) values.push(0);

  const totalPoints = values.length;
  const stepX = totalPoints > 1 ? graphWidth / (totalPoints - 1) : graphWidth;
  const topY = margin;
  const bottomY = margin + graphHeight;

  // Draw envelope curve
  ctx.strokeStyle = `rgba(${themeColor}, 0.9)`;
  ctx.lineWidth = 2;
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';

  ctx.beginPath();
  values.forEach((val, idx) => {
    const x = margin + idx * stepX;
    const y = bottomY - clamp(val, 0, 1) * graphHeight;
    if (idx === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  });
  ctx.stroke();

  // Fill under envelope curve down to bottom baseline
  ctx.fillStyle = `rgba(${themeColor}, 0.18)`;
  ctx.beginPath();
  ctx.moveTo(margin, bottomY);
  values.forEach((val, idx) => {
    const x = margin + idx * stepX;
    const y = bottomY - clamp(val, 0, 1) * graphHeight;
    ctx.lineTo(x, y);
  });
  ctx.lineTo(margin + graphWidth, bottomY);
  ctx.closePath();
  ctx.fill();
}

// Envelope Visualizer Controller
class EnvelopeVisualizer {
  constructor(canvasId, themeColor) {
    this.canvas = document.getElementById(canvasId);
    this.themeColor = themeColor;
    this.attack = 10; // ms
    this.decay = 300; // ms
    this.sustain = 0.7; // 0-1
    this.release = 500; // ms
    this.linearity = 0.5; // 0..1

    this.updateDisplay();
  }

  setAttack(ms) {
    this.attack = ms;
    this.updateDisplay();
  }

  setDecay(ms) {
    this.decay = ms;
    this.updateDisplay();
  }

  setSustain(level) {
    this.sustain = level;
    this.updateDisplay();
  }

  setRelease(ms) {
    this.release = ms;
    this.updateDisplay();
  }
  setLinearity(n) { this.linearity = Math.max(0, Math.min(1, n)); this.updateDisplay(); }

  updateDisplay() {
    if (this.canvas) {
      drawEnvelope(this.canvas, this.attack, this.decay, this.sustain, this.release, this.themeColor, this.linearity);
    }
  }
}

// Initialize envelope visualizers
window.env1Viz = new EnvelopeVisualizer('env1-graph', '34, 197, 94');
window.env2Viz = new EnvelopeVisualizer('env2-graph', '34, 197, 94');

// ============================================================================
// LFO Visualizer
// ============================================================================

function drawLFO(canvas, wave, depth, themeColor, rateNorm = 0.2) {
  const ctx = canvas.getContext('2d');
  const { cssWidth: width, cssHeight: height } = resizeCanvasToDisplaySize(canvas);
  // Amplitude follows DEPTH
  const amp = (height * 0.4) * Math.max(0, Math.min(1, depth));
  const mid = height / 2;

  ctx.clearRect(0, 0, width, height);
  ctx.strokeStyle = `rgba(${themeColor}, 0.9)`;
  ctx.lineWidth = 2;
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';

  const n = width; // samples across
  const cycles = 0.25 + 3.75 * Math.max(0, Math.min(1, rateNorm));
  ctx.beginPath();
  for (let x = 0; x < n; x++) {
    const t = x / (n - 1);
    let yNorm = 0;
    switch (wave) {
      case 0: // Sine
        yNorm = Math.sin(2 * Math.PI * t * cycles);
        break;
      case 1: // Triangle
        {
          const tt = (t * cycles) % 1;
          yNorm = 1 - 4 * Math.abs(Math.round(tt - 0.25) - (tt - 0.25));
        }
        break;
      case 2: // Square
        yNorm = ((t * cycles) % 1) < 0.5 ? 1 : -1;
        break;
      case 3: // Saw
        {
          const tt = (t * cycles);
          yNorm = 2 * (tt - Math.floor(tt + 0.5));
        }
        break;
      default: // Random (sample-and-hold): simple step every 1/8 width
        const step = Math.floor((t * cycles) * 8);
        const rng = (Math.sin(step * 12.9898) * 43758.5453) % 1;
        // Scale amplitude to 80%
        yNorm = ((rng * 2) - 1) * 0.8;
        break;
    }
    const y = mid - yNorm * amp;
    if (x === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  }
  ctx.stroke();

  // Fill under LFO curve down to center line
  ctx.fillStyle = `rgba(${themeColor}, 0.18)`;
  ctx.beginPath();
  ctx.moveTo(0, mid);
  for (let x = 0; x < n; x++) {
    const t = x / (n - 1);
    let yNorm = 0;
    switch (wave) {
      case 0: yNorm = Math.sin(2 * Math.PI * t * cycles); break;
      case 1: {
        const tt = (t * cycles) % 1;
        yNorm = 1 - 4 * Math.abs(Math.round(tt - 0.25) - (tt - 0.25));
        break;
      }
      case 2: yNorm = ((t * cycles) % 1) < 0.5 ? 1 : -1; break;
      case 3: {
        const tt = (t * cycles);
        yNorm = 2 * (tt - Math.floor(tt + 0.5));
        break;
      }
      default: {
        const step = Math.floor((t * cycles) * 8);
        const rng = (Math.sin(step * 12.9898) * 43758.5453) % 1;
        yNorm = (rng * 2) - 1;
      }
    }
    const y = mid - yNorm * amp;
    ctx.lineTo(x, y);
  }
  ctx.lineTo(n - 1, mid);
  ctx.closePath();
  ctx.fill();
}

class LfoVisualizer {
  constructor(canvasId, themeColor) {
    this.canvas = document.getElementById(canvasId);
    this.themeColor = themeColor;
    this.wave = 0; // sine
    this.depth = 0;
    this.rate = 0.2;
    this.updateDisplay();
  }
  setWave(idx) { this.wave = idx; this.updateDisplay(); }
  setDepth(d) { this.depth = d; this.updateDisplay(); }
  setRate(r) { this.rate = r; this.updateDisplay(); }
  updateDisplay() { if (this.canvas) drawLFO(this.canvas, this.wave, this.depth, this.themeColor, this.rate); }
}

// Initialize LFO visualizers
window.lfo1Viz = new LfoVisualizer('lfo1-graph', THEME_COLORS.lfo);
window.lfo2Viz = new LfoVisualizer('lfo2-graph', THEME_COLORS.lfo);

// ============================================================================
// Noise Visualizer
// ============================================================================

// Fixed 1-bit arcade patterns (NRZ)
const ARCADE_PATTERNS = {
  2: "01",
  3: "010",
  4: "0110",
  5: "01101",
  6: "010110",
  7: "0110101",
  8: "01011010",
  9: "011010110",
  10: "0101101011",
  11: "01101011010",
  12: "010110101101",
  13: "0110101101010",
  14: "01011010110101",
  15: "011010110101101",
  16: "0101101011010110",
};

function makeLCG(seed) { let x = seed >>> 0; return () => { x = (1664525 * x + 1013904223) >>> 0; return x / 0xffffffff; }; }

function drawGrid(ctx, width, height) {
  ctx.strokeStyle = 'rgba(255,255,255,0.06)';
  ctx.lineWidth = 1;
  ctx.beginPath();
  for (let i = 1; i < 8; i++) {
    const y = Math.round((i * height) / 8) + 0.5;
    ctx.moveTo(0, y); ctx.lineTo(width, y);
  }
  ctx.stroke();
}

function drawNoise(canvas, type, variant, level, themeColor) {
  const ctx = canvas.getContext('2d');
  const { cssWidth: width, cssHeight: height } = resizeCanvasToDisplaySize(canvas);

  // Clear and set background
  ctx.clearRect(0, 0, width, height);


  // Grid


  // Trace style
  ctx.strokeStyle = `rgba(${themeColor}, 0.9)`;
  ctx.lineWidth = 2;
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';

  // Fixed preview amplitude (independent of level)
  const amp = height * 0.35;
  const mid = height / 2;

  // RNG
  const r = makeLCG(123456789);

  ctx.beginPath();
  const v = Math.max(0, Math.min(1, variant));

  if (type === 0) {
    // Analog: white noise -> 1-pole LPF smoothing, draw with stride
    const n = Math.max(2, Math.floor(width));
    const alpha = 0.02 + 0.45 * v; // smoothing
    const drawStride = Math.max(2, Math.round(4 + v * 20)); // 4..24 px

    let yNorm = 0;
    let drewAny = false;
    for (let x = 0; x < n; x++) {
      const white = r() * 2 - 1;
      yNorm += (white - yNorm) * alpha;
      if (x % drawStride !== 0 && x !== n - 1) continue;
      const y = mid - yNorm * amp;
      if (!drewAny) { ctx.moveTo(x, y); drewAny = true; }
      else ctx.lineTo(x, y);
    }
  } else if (type === 1) {
    // Digital: fixed period with quantization, ZOH draw
    const PERIOD = 50;
    const bits = Math.max(1, Math.round(8 - v * 7)); // 8bit -> 1bit
    const levels = 1 << bits;
    const step = 2 / (levels - 1);
    const xStep = width / PERIOD;
    let yHold = mid;
    for (let i = 0; i < PERIOD; i++) {
      const raw = r() * 2 - 1;
      const q = Math.round((raw + 1) / step) * step - 1;
      const y = mid - q * amp;
      const x = i * xStep;
      if (i === 0) ctx.moveTo(x, y);
      else { ctx.lineTo(x, yHold); ctx.lineTo(x, y); }
      yHold = y;
    }
    ctx.lineTo(width, yHold);
  } else {
    // Arcade: NRZ step pattern from fixed lookup
    const bits = Math.max(2, Math.min(16, Math.round(2 + v * 14)));
    const p = ARCADE_PATTERNS[bits] || ARCADE_PATTERNS[16];
    const N = p.length;
    const xStep = width / N;
    let y0 = mid - (p[0] === '1' ? amp : -amp);
    ctx.moveTo(0, y0);
    for (let i = 1; i < N; i++) {
      const x = i * xStep;
      const y = mid - (p[i] === '1' ? amp : -amp);
      ctx.lineTo(x, y0);
      ctx.lineTo(x, y);
      y0 = y;
    }
    ctx.lineTo(width, y0);
  }

  ctx.stroke();
  // No fill for noise preview to keep it simple
  void level; // level intentionally ignored for preview
}

class NoiseVisualizer {
  constructor(canvasId, themeColor) {
    this.canvas = document.getElementById(canvasId);
    this.themeColor = themeColor;
    this.type = 0;
    this.variant = 0.5; // 0..1
    this.level = 0.0;   // 0..1
    this.updateDisplay();
  }
  setType(t) { this.type = t; this.updateDisplay(); }
  setVariant(v) { this.variant = v; this.updateDisplay(); }
  setLevel(l) { this.level = l; this.updateDisplay(); }
  updateDisplay() { if (this.canvas) drawNoise(this.canvas, this.type, this.variant, this.level, this.themeColor); }
}

window.noiseViz = new NoiseVisualizer('noise-graph', THEME_COLORS.noise);

// Transient mini-graph + control bindings
class TransientVisualizer {
  constructor(canvasId, themeColor = THEME_COLORS.transient) {
    this.canvas = document.getElementById(canvasId);
    this.themeColor = themeColor;
    this.mode = 'modal';
    this.decay = 0.5;
    this.timbre = 0.5;
    this.level = 0.5;
    this.rngState = 1;
    if (!this.canvas) return;
    this.ctx = this.canvas.getContext('2d');
    this.redraw = this.redraw.bind(this);
    window.addEventListener('resize', this.redraw);
    this.redraw();
  }

  clamp01(value) {
    return Math.max(0, Math.min(1, value));
  }

  setMode(mode) {
    this.mode = mode || 'modal';
    this.redraw();
  }

  setDecay(value) {
    this.decay = this.clamp01(value);
    this.redraw();
  }

  setTimbre(value) {
    this.timbre = this.clamp01(value);
    this.redraw();
  }

  setLevel(value) {
    this.level = this.clamp01(value);
    this.redraw();
  }

  visualLevel(min = 0.12) {
    return Math.max(min, this.level);
  }

  initRng() {
    const seedBase = Math.floor((this.decay * 997) + (this.timbre * 613) + (this.level * 311));
    this.rngState = (seedBase % 2147483646) + 1;
  }

  rand() {
    this.rngState = (this.rngState * 16807) % 2147483647;
    return (this.rngState - 1) / 2147483646;
  }

  drawOval(x, y, rx, ry, fillAlpha, strokeAlpha = 0.85) {
    if (!this.ctx) return;
    const clampedFill = Math.max(0, Math.min(1, fillAlpha));
    const clampedStroke = Math.max(0, Math.min(1, strokeAlpha));

    this.ctx.save();
    this.ctx.fillStyle = `rgba(${this.themeColor}, ${clampedFill})`;
    this.ctx.beginPath();
    this.ctx.ellipse(x, y, Math.max(0, rx), Math.max(0, ry), 0, 0, Math.PI * 2);
    this.ctx.fill();
    this.ctx.restore();

    this.ctx.save();
    this.ctx.lineWidth = 2;
    this.ctx.strokeStyle = `rgba(${this.themeColor}, ${clampedStroke})`;
    this.ctx.beginPath();
    this.ctx.ellipse(x, y, Math.max(0, rx), Math.max(0, ry), 0, 0, Math.PI * 2);
    this.ctx.stroke();
    this.ctx.restore();
  }

  clear(w, h) {
    if (!this.ctx) return;
    this.ctx.clearRect(0, 0, w, h);
  }

  drawKick(w, h) {
    const level = this.visualLevel();
    const cx = w / 2;
    const baseY = h * 0.2;
    const travel = h * (0.3 + 0.5 * this.decay);
    for (let i = 0; i < 6; i++) {
      const t = i / 5;
      const y = baseY + t * travel;
      const r = (1 - t) * (h * 0.35);
      const aspect = 1 + this.timbre * 0.5;
      this.drawOval(cx, y, r * aspect, r * 0.65, 0.35 * level * (1 - t), 0.4);
    }
  }

  drawSnare(w, h) {
    // New snare: concentric modal-style rings
    const level = this.visualLevel();
    const cx = w / 2;
    const cy = h / 2;
    const rings = 5;
    for (let i = 0; i < rings; i++) {
      const t = i / Math.max(1, rings - 1);
      const baseRadius = h * 0.08;
      const r = baseRadius + t * h * (0.22 + this.decay * 0.25);
      const aspect = 0.4 + this.timbre * 0.6;
      this.drawOval(cx, cy, r * aspect, r, 0.25 * level * (1 - t), 0.3);
    }
  }

  drawModal(w, h) {
    const level = this.visualLevel();
    const cx = w / 2;
    const cy = h / 2;
    this.drawOval(cx, cy, w * 0.13, h * 0.2, 0.45 * level);
    const count = Math.max(6, Math.floor(6 + this.timbre * 14));
    const spread = (h * 0.15) + this.decay * h * 0.25;
    for (let i = 0; i < count; i++) {
      const a = this.rand() * Math.PI * 2;
      const d = spread * (0.6 + this.rand() * 0.8);
      const size = 2 + this.rand() * 2.5;
      const x = cx + Math.cos(a) * d;
      const y = cy + Math.sin(a) * d;
      this.drawOval(x, y, size, size, 0.35 * level * this.timbre, 0.25);
    }
  }

  drawHat(w, h) {
    const level = this.visualLevel();
    const cy = h / 2;
    const layers = Math.max(3, Math.floor(5 + this.decay * 6));
    const span = w * 0.65;
    const startX = (w - span) / 2;
    for (let i = 0; i < layers; i++) {
      const t = i / Math.max(1, layers - 1);
      const x = startX + t * span;
      const fade = 1 - t * 0.85;
      const width = w * 0.035 + this.timbre * w * 0.02;
      const height = (h * 0.05) + this.timbre * h * 0.1;
      this.drawOval(x, cy, width, height, 0.35 * level * fade, 0.3);
    }
  }

  drawKarplus(w, h) {
    const level = this.visualLevel();
    const cx = w / 2;
    const cy = h / 2;
    const spikes = Math.max(6, Math.floor(8 + this.timbre * 6));
    const radius = h * (0.2 + this.decay * 0.4);
    this.ctx.save();
    this.ctx.strokeStyle = `rgba(${this.themeColor}, ${0.25 + level * 0.4})`;
    this.ctx.lineWidth = 2 + level * 1.2;
    for (let i = 0; i < spikes; i++) {
      const angle = (i / spikes) * Math.PI * 2;
      const len = radius * (0.7 + this.rand() * 0.6);
      const ex = cx + Math.cos(angle) * len;
      const ey = cy + Math.sin(angle) * len;
      this.ctx.beginPath();
      this.ctx.moveTo(cx, cy);
      this.ctx.lineTo(ex, ey);
      this.ctx.stroke();
      this.drawOval(ex, ey, 3 + level * 4, 3 + level * 4, 0.25 * level, 0.3);
    }
    this.ctx.restore();
  }

  drawZap(w, h) {
    const level = this.visualLevel();
    const ctx = this.ctx;


    const sizeNorm = Math.max(0, Math.min(1, this.decay));
    const dampNorm = Math.max(0, Math.min(1, this.timbre));
    const mixNorm = Math.max(0, Math.min(1, this.visualLevel()));

    const endX = Math.max(2, Math.round(w * Math.max(0.02, sizeNorm)));
    const k = 6.0;
    const p = 0.7 + 1.8 * dampNorm;
    const denom = (1 - Math.exp(-k)) || 1;
    const curveY = (t) => h * (1 - Math.exp(-k * Math.pow(t, p))) / denom;
    ctx.strokeStyle = `rgba(${this.themeColor},0.9)`;
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    for (let x = 0; x <= endX; x++) {
      const t = endX <= 0 ? 0 : (x / endX);
      const y = curveY(t);
      ctx.lineTo(x, y);
    }
    ctx.stroke();

    ctx.fillStyle = `rgba(${this.themeColor}, 0.18)`;
    ctx.beginPath();
    ctx.moveTo(0, h);
    for (let x = 0; x <= endX; x++) {
      const t = endX <= 0 ? 0 : (x / endX);
      const y = curveY(t);
      ctx.lineTo(x, y);
    }
    ctx.lineTo(endX, h);
    ctx.closePath();
    ctx.fill();

    const grad = ctx.createLinearGradient(0, 0, endX, 0);
    const startAlpha = Math.min(0.6, 0.5 * mixNorm);
    grad.addColorStop(0, `rgba(${this.themeColor}, ${startAlpha})`);
    grad.addColorStop(1, `rgba(${this.themeColor}, 0)`);
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.moveTo(0, h);
    for (let x = 0; x <= endX; x++) {
      const t = endX <= 0 ? 0 : (x / endX);
      const y = curveY(t);
      ctx.lineTo(x, y);
    }
    ctx.lineTo(endX, h);
    ctx.closePath();
    ctx.fill();

    const x0 = w * 0.08;
    const x1 = w * 0.92;
    const midY = h / 2;
    const thickness = h * (0.35 + this.decay * 0.25);
    const topY = midY - thickness / 2;
    const bottomY = midY + thickness / 2;
    const curvature = w * (0.25 + this.timbre * 0.15);
    ctx.save();
    ctx.fillStyle = `rgba(${this.themeColor}, ${0.2 + level * 0.4})`;
    ctx.strokeStyle = `rgba(${this.themeColor}, ${0.5 + level * 0.4})`;
    ctx.lineWidth = 2;

    ctx.beginPath();
    ctx.moveTo(x0, topY);
    ctx.bezierCurveTo(x0 + curvature, topY - h * 0.15 * (0.2 + this.decay),
      x1 - curvature * 0.4, midY - thickness * 0.2, x1, midY);
    ctx.lineTo(x1, midY);
    ctx.bezierCurveTo(x1 - curvature * 0.4, midY + thickness * 0.2,
      x0 + curvature, bottomY + h * 0.15 * (0.2 + this.decay), x0, bottomY);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.restore();
    drawReverbGraph(this.canvas, sizeNorm, dampNorm, mixNorm, this.themeColor);

  }

  redraw() {
    if (!this.ctx || !this.canvas) return;
    const { cssWidth: w, cssHeight: h } = resizeCanvasToDisplaySize(this.canvas);
    this.clear(w, h);
    this.initRng();
    switch (this.mode) {
      case 'kick':
        this.drawKick(w, h);
        break;
      case 'snare':
        this.drawSnare(w, h);
        break;
      case 'hihat':
        this.drawHat(w, h);
        break;
      case 'karplus':
        this.drawKarplus(w, h);
        break;
      case 'zap':
        this.drawZap(w, h);
        break;
      case 'modal':
      default:
        this.drawModal(w, h);
        break;
    }
  }
}

window.transientViz = new TransientVisualizer('transient-graph', THEME_COLORS.transient);

const transientDecaySlider = document.getElementById('transient-decay');
const transientDecayVal = document.getElementById('transient-decay-val');
if (transientDecaySlider) {
  const updateDecay = (raw) => {
    const pct = parseInt(raw, 10);
    if (!Number.isFinite(pct)) return;
    const normalized = pct / 100;
    // Calculate decay time in ms (20ms to 3000ms)
    const decayMs = 20 + normalized * 2980;
    const displayText = decayMs < 1000
      ? `${Math.round(decayMs)}<span class="unit">ms</span>`
      : `${(decayMs / 1000).toFixed(2)}<span class="unit">s</span>`;
    if (transientDecayVal) transientDecayVal.innerHTML = displayText;
    if (window.transientViz) window.transientViz.setDecay(normalized);
    sendParam(Params.TRANSIENT_DECAY, normalized);
  };
  updateDecay(transientDecaySlider.value);
  transientDecaySlider.addEventListener('input', (e) => updateDecay(e.target.value));
}

const transientTimbreSlider = document.getElementById('transient-timbre');
const transientTimbreVal = document.getElementById('transient-timbre-val');
if (transientTimbreSlider) {
  const updateTimbre = (raw) => {
    const pct = parseInt(raw, 10);
    if (!Number.isFinite(pct)) return;
    const normalized = pct / 100;
    if (transientTimbreVal) transientTimbreVal.innerHTML = `${pct}<span class="unit">%</span>`;
    if (window.transientViz) window.transientViz.setTimbre(normalized);
    sendParam(Params.TRANSIENT_TIMBRE, normalized);
  };
  updateTimbre(transientTimbreSlider.value);
  transientTimbreSlider.addEventListener('input', (e) => updateTimbre(e.target.value));
}

const transientLevelSlider = document.getElementById('transient-level');
const transientLevelVal = document.getElementById('transient-level-val');
if (transientLevelSlider) {
  const updateLevel = (raw) => {
    const pct = parseInt(raw, 10);
    if (!Number.isFinite(pct)) return;
    const normalized = pct / 100;
    if (transientLevelVal) transientLevelVal.innerHTML = `${pct}<span class="unit">%</span>`;
    if (window.transientViz) window.transientViz.setLevel(normalized);
    sendParam(Params.TRANSIENT_LEVEL, normalized);
  };
  updateLevel(transientLevelSlider.value);
  transientLevelSlider.addEventListener('input', (e) => updateLevel(e.target.value));
}

// ============================================================================
// Effects Placeholder Visualizers
// ============================================================================

function drawEffectPlaceholder(canvas, style = 'line', themeColor = '255,255,255') {
  const ctx = canvas.getContext('2d');
  const { cssWidth: width, cssHeight: height } = resizeCanvasToDisplaySize(canvas);
  ctx.clearRect(0, 0, width, height);
  ctx.strokeStyle = `rgba(${themeColor}, 0.9)`;
  ctx.lineWidth = 2;
  const mid = height / 2;
  ctx.beginPath();
  if (style === 'delay') {
    // draws nothing specific until parameters provided
    ctx.moveTo(0, mid); ctx.lineTo(width, mid);
  } else if (style === 'chorus') {
    // base line
    ctx.moveTo(0, mid); ctx.lineTo(width, mid);
  } else if (style === 'reverb') {
    // decay curve
    ctx.moveTo(0, mid - height * 0.35);
    for (let x = 0; x < width; x++) {
      const t = x / width;
      const y = mid - (height * 0.35) * Math.exp(-3 * t);
      ctx.lineTo(x, y);
    }
  } else {
    ctx.moveTo(0, mid); ctx.lineTo(width, mid);
  }
  ctx.stroke();
}

// init placeholders
(() => {
  const d = document.getElementById('delay-graph'); if (d) drawEffectPlaceholder(d, 'delay', THEME_COLORS.effects);
  const c = document.getElementById('chorus-graph'); if (c) drawEffectPlaceholder(c, 'chorus', THEME_COLORS.effects);
  const r = document.getElementById('reverb-graph'); if (r) drawEffectPlaceholder(r, 'reverb', THEME_COLORS.effects);
})();

// Dynamic effect graphs
function drawDelayGraph(canvas, timeNorm, fbNorm, mixNorm = 0.3, themeColor = THEME_COLORS.effects) {
  const ctx = canvas.getContext('2d'); const { cssWidth: w, cssHeight: h } = resizeCanvasToDisplaySize(canvas);
  ctx.clearRect(0, 0, w, h);
  const mid = h / 2;
  const feedback = 0.1 + 0.9 * Math.max(0, Math.min(1, fbNorm));
  const taps = Math.max(2, Math.min(12, Math.round(3 + 9 * feedback)));

  // MIX controls overall opacity
  ctx.globalAlpha = 1;
  ctx.fillStyle = `rgba(${themeColor}, 1)`;

  // Base radius larger
  const baseR = Math.max(4, Math.min(h, w) * 0.16);
  const spacing = Math.max(6, (timeNorm * w) / taps);
  const startX = Math.max(8, Math.min(w - 8, w * 0.05));
  for (let i = 0; i < taps; i++) {
    const x = Math.min(w - 8, startX + i * spacing);
    const r = baseR * Math.pow(feedback, i * 0.6); // slower decay so dots stay visible
    // Draw ellipse (300% vertical) using ellipse() to avoid blur from canvas scale
    const xC = Math.round(x) + 0.5;
    const yC = Math.round(mid) + 0.5;
    ctx.beginPath();
    ctx.ellipse(xC, yC, r, r * 3.0, 0, 0, Math.PI * 2);
    // stroke border at current global alpha
    ctx.strokeStyle = `rgba(${themeColor}, 1)`;
    ctx.lineWidth = 1.5;
    ctx.stroke();
    // fill with half transparency
    ctx.save();
    ctx.globalAlpha = 0.15 + 0.70 * Math.max(0, Math.min(1, mixNorm));
    ctx.fillStyle = `rgba(${themeColor}, 1)`;
    ctx.fill();
    ctx.restore();
  }
  ctx.globalAlpha = 1;
}

function drawChorusGraph(canvas, rateNorm, depthNorm, mixNorm, themeColor = THEME_COLORS.effects) {
  const ctx = canvas.getContext('2d');
  const { cssWidth: w, cssHeight: h } = resizeCanvasToDisplaySize(canvas);
  ctx.clearRect(0, 0, w, h);
  const mid = h / 2;
  const baseAmp = h * 0.45;
  const amp = baseAmp * Math.max(0, Math.min(1, depthNorm));
  const mixAlpha = 0.2 + 0.8 * Math.max(0, Math.min(1, mixNorm));
  // Make period increase with rate (not inverse). At min rate -> 1 cycle (syncs with half of background 2 cycles)
  const cycles = 1.0 + 5.0 * Math.max(0, Math.min(1, rateNorm));
  const omega = cycles * Math.PI * 2; // over normalized width 0..1

  // Reference sine (back) at 50% alpha, fixed 2 cycles across width (RATE-independent)
  ctx.strokeStyle = `rgba(${themeColor}, ${0.5 * 1})`;
  ctx.lineWidth = 2;
  ctx.lineJoin = 'round';
  ctx.lineCap = 'round';
  ctx.beginPath();
  for (let x = 0; x < w; x++) {
    const t = x / w;
    const yRef = mid + Math.sin(4 * Math.PI * t) * (baseAmp * 0.5);
    if (x === 0) ctx.moveTo(x, yRef); else ctx.lineTo(x, yRef);
  }
  ctx.stroke();

  // Main SINE trace (front), scaled by depth
  ctx.strokeStyle = `rgba(${themeColor}, 1.0)`;
  ctx.fillStyle = `rgba(${themeColor}, ${0.8 * mixAlpha})`;
  ctx.beginPath();
  for (let x = 0; x < w; x++) {
    const t = x / w;
    const y = mid + Math.sin(omega * t) * amp;
    if (x === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
  }
  ctx.stroke();
  ctx.fill();
}

function drawReverbGraph(canvas, sizeNorm, dampNorm = 0.4, mixNorm = 0.25, themeColor = THEME_COLORS.effects) {
  const ctx = canvas.getContext('2d'); const { cssWidth: w, cssHeight: h } = resizeCanvasToDisplaySize(canvas);
  ctx.clearRect(0, 0, w, h);
  const amp = (h * 0.5) * (0.5 + 0.5 * sizeNorm);
  // sizeで長さをコントロール（最小で左端近傍、最大で右端）
  const endX = Math.max(2, Math.round(w * Math.max(0.02, sizeNorm)));
  // decay curve
  ctx.strokeStyle = `rgba(${themeColor},0.9)`; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(0, 0);
  const k = 6.0; // 基本減衰係数
  // DAMPING: 曲率変更（低ダンピング=緩やか、高ダンピング=急峻）
  const p = 0.7 + 1.8 * Math.max(0, Math.min(1, dampNorm));
  const denom = (1 - Math.exp(-k)) || 1;
  for (let x = 0; x <= endX; x++) {
    const t = endX <= 0 ? 0 : (x / endX);
    const y = h * (1 - Math.exp(-k * Math.pow(t, p))) / denom;
    ctx.lineTo(x, y);
  }
  ctx.stroke();

  // Fill under curve based on computed decay path
  ctx.fillStyle = `rgba(${themeColor}, 0.18)`;
  ctx.beginPath();
  ctx.moveTo(0, h);
  for (let x = 0; x <= endX; x++) {
    const t = endX <= 0 ? 0 : (x / endX);
    const y = h * (1 - Math.exp(-k * Math.pow(t, p))) / denom;
    ctx.lineTo(x, y);
  }
  ctx.lineTo(endX, h);
  ctx.closePath();
  ctx.fill();
  // overlay gradient fill: 左→右で薄く、カーブ下端まで
  const grad = ctx.createLinearGradient(0, 0, endX, 0);
  const startAlpha = Math.min(0.6, 0.5 * Math.max(0, Math.min(1, mixNorm)));
  grad.addColorStop(0, `rgba(${themeColor}, ${startAlpha})`);
  grad.addColorStop(1, `rgba(${themeColor}, 0)`);
  ctx.fillStyle = grad; ctx.globalAlpha = 1;
  ctx.beginPath(); ctx.moveTo(0, h);
  for (let x = 0; x <= endX; x++) {
    const t = endX <= 0 ? 0 : (x / endX); const y = h * (1 - Math.exp(-k * Math.pow(t, p))) / denom; ctx.lineTo(x, y);
  }
  ctx.lineTo(endX, h); ctx.closePath(); ctx.fill();
}

// Modal graph: type = 'formant' | 'comb'
function drawModalGraph(canvas, type, toneNorm, resoNorm, mixNorm, themeColor = '32, 208, 176') {
  const ctx = canvas.getContext('2d');
  const { cssWidth: w, cssHeight: h } = resizeCanvasToDisplaySize(canvas);
  ctx.clearRect(0, 0, w, h);
  const mid = h - 6;
  const clamp01 = (v) => Math.max(0, Math.min(1, v));

  // draw baseline
  ctx.strokeStyle = `rgba(${themeColor}, 0.15)`;
  ctx.lineWidth = 1;
  ctx.beginPath(); ctx.moveTo(0, mid); ctx.lineTo(w, mid); ctx.stroke();

  ctx.lineWidth = 2;
  ctx.strokeStyle = `rgba(${themeColor}, 0.95)`;
  ctx.fillStyle = `rgba(${themeColor}, ${0.15 + clamp01(mixNorm) * 0.45})`;

  if (type === 'comb') {
    // Comb: render repeating half-ellipses to suggest resonant teeth
    const baseSpacing = Math.max(16, 12 + toneNorm * (w * 0.3));
    const baseHalfWidth = baseSpacing * 0.5;
    const maxFactor = 5.5;
    const minFactor = 0.1;
    const maxExtent = w + baseSpacing * 2;
    const amp = Math.max(10, 8 + resoNorm * (h * 0.75));
    const steps = 32;
    ctx.lineWidth = 2;
    const clamp = (val, min = -1, max = 1) => Math.max(min, Math.min(max, val));

    const drawCombLobe = (center, halfWidth) => {
      if (halfWidth <= 0) return;
      let thetaStart = Math.PI;
      let thetaEnd = 0;
      if (center - halfWidth < 0) {
        thetaStart = Math.acos(clamp((0 - center) / halfWidth));
      }
      if (center + halfWidth > w) {
        thetaEnd = Math.acos(clamp((w - center) / halfWidth));
      }
      if (thetaStart <= thetaEnd + 1e-3) return;
      const thetaRange = thetaStart - thetaEnd;
      const startX = center + halfWidth * Math.cos(thetaStart);
      const startY = mid - amp * Math.sin(thetaStart);

      ctx.beginPath();
      ctx.moveTo(startX, startY);
      for (let s = 1; s <= steps; s++) {
        const theta = thetaStart - (thetaRange * (s / steps));
        const x = center + halfWidth * Math.cos(theta);
        const y = mid - amp * Math.sin(theta);
        ctx.lineTo(x, Math.max(0, y));
      }
      const endX = center + halfWidth * Math.cos(thetaEnd);
      ctx.lineTo(endX, mid);
      ctx.lineTo(startX, mid);
      ctx.closePath();
      ctx.fill();

      ctx.beginPath();
      ctx.moveTo(startX, startY);
      for (let s = 1; s <= steps; s++) {
        const theta = thetaStart - (thetaRange * (s / steps));
        const x = center + halfWidth * Math.cos(theta);
        const y = mid - amp * Math.sin(theta);
        ctx.lineTo(x, Math.max(0, y));
      }
      ctx.stroke();
    };

    // Left-most lobe: show only half (right side)
    const firstHalfWidth = Math.max(8, baseHalfWidth * maxFactor);
    drawCombLobe(0, firstHalfWidth);

    let leftEdge = firstHalfWidth;
    let guard = 0;
    while (leftEdge < maxExtent && guard < 200) {
      const progress = Math.max(0, Math.min(1, leftEdge / maxExtent));
      const eased = 1 - Math.pow(progress, 0.25);
      const widthFactor = minFactor + (maxFactor - minFactor) * eased;
      const halfWidth = Math.max(6, baseHalfWidth * widthFactor);
      const center = leftEdge + halfWidth;
      drawCombLobe(center, halfWidth);
      leftEdge += halfWidth * 2;
      guard++;
    }

    // Mesh-like particles overlay
    const particleCount = Math.round(40 + 120 * clamp01(resoNorm));
    const seed = Math.floor((toneNorm + resoNorm * 2 + mixNorm * 3) * 10000) || 1;
    let s = seed;
    const rand = () => {
      s = (s * 1664525 + 1013904223) % 4294967296;
      return s / 4294967296;
    };
    const dotAlpha = 0.2 + 0.6 * clamp01(mixNorm);
    ctx.fillStyle = `rgba(${themeColor}, ${dotAlpha})`;
    for (let i = 0; i < particleCount; i++) {
      const x = rand() * w;
      const y = rand() * (h * 0.9);
      const r = 0.6 + rand() * 1.6;
      ctx.beginPath();
      ctx.arc(x, y, r, 0, Math.PI * 2);
      ctx.fill();
    }
  } else {
    const sr = 44100;
    const nyquist = sr * 0.5;
    const f0 = 20;
    const xf = (x) => f0 * Math.pow(nyquist / f0, x / w);
    const baseFreq = [500, 1500, 2500, 3500, 4500];
    const baseQ = 4.0;
    const toneShift = toneNorm * 2 - 1; // +/- 1 octave
    const q = baseQ + baseQ * 5 * clamp01(resoNorm);
    ctx.beginPath(); ctx.moveTo(0, mid);
    const verticalScale = h * 0.88;
    for (let x = 0; x <= w; x++) {
      const f = xf(x);
      let amp = 0;
      for (let i = 0; i < baseFreq.length; i++) {
        const fc = baseFreq[i] * Math.pow(2, toneShift);
        const bw = fc / q;
        const d = (f - fc) / bw;
        amp += Math.exp(-d * d);
      }
      const y = mid - amp * verticalScale;
      ctx.lineTo(x, Math.max(0, y));
    }
    ctx.lineTo(w, mid); ctx.closePath(); ctx.fill(); ctx.stroke();
  }
}

// ============================================================================
// Mini-graph Drag Controls (X/Y mapping)
// ============================================================================

function attachMiniGraphDrag(canvasId, onDrag) {
  const el = document.getElementById(canvasId);
  if (!el) return;
  const getNorm = (e) => {
    const rect = el.getBoundingClientRect();
    const clientX = e.touches ? e.touches[0].clientX : e.clientX;
    const clientY = e.touches ? e.touches[0].clientY : e.clientY;
    const x = Math.min(1, Math.max(0, (clientX - rect.left) / rect.width));
    const y = 1 - Math.min(1, Math.max(0, (clientY - rect.top) / rect.height));
    return { x, y };
  };
  let dragging = false;
  const move = (e) => { if (!dragging) return; e.preventDefault(); const { x, y } = getNorm(e); onDrag(x, y); };
  const up = () => { dragging = false; document.removeEventListener('mousemove', move); document.removeEventListener('mouseup', up); document.removeEventListener('touchmove', move); document.removeEventListener('touchend', up); };
  const down = (e) => { dragging = true; move(e); document.addEventListener('mousemove', move, { passive: false }); document.addEventListener('mouseup', up); document.addEventListener('touchmove', move, { passive: false }); document.addEventListener('touchend', up); };
  el.addEventListener('mousedown', down);
  el.addEventListener('touchstart', down, { passive: false });
}

function setSliderAndParam(id, paramIdx, normalized) {
  const slider = document.getElementById(id);
  if (slider) {
    const v = Math.round(Math.min(1, Math.max(0, normalized)) * 100);
    slider.value = String(v);
    setRangeProgress(slider);
    // Dispatch input to unify updates (labels/graphs/params)
    slider.dispatchEvent(new Event('input', { bubbles: true }));
  } else if (typeof paramIdx === 'number') {
    // Fallback if slider missing
    sendParam(paramIdx, Math.min(1, Math.max(0, normalized)));
  }
}

// Filter 1 drag: X=cutoff, Y=resonance
attachMiniGraphDrag('filter-1-graph', (x, y) => {
  setSliderAndParam('filter-cutoff', Params.FILTER_1_CUTOFF, x);
  setSliderAndParam('filter-reso', Params.FILTER_1_RESO, y);
  if (window.filter1Viz) { const hz = logScale(x, 20, 20000); window.filter1Viz.setCutoff(hz); window.filter1Viz.setResonance(y); }
});

// Filter 2 drag
attachMiniGraphDrag('filter2-graph', (x, y) => {  // Fixed: HTML uses filter2-graph not filter-2-graph
  setSliderAndParam('filter2-cutoff', Params.FILTER_2_CUTOFF, x);
  setSliderAndParam('filter2-reso', Params.FILTER_2_RESO, y);
  if (window.filter2Viz) { const hz = logScale(x, 20, 20000); window.filter2Viz.setCutoff(hz); window.filter2Viz.setResonance(y); }
});

const mapEnvDrag = (x, y) => {
  const attack = Math.max(0, Math.min(1, x));
  const decay = Math.max(0, Math.min(1, 1 - x));
  const sustain = Math.max(0, Math.min(1, y));
  const release = Math.max(0, Math.min(1, 1 - y));
  return { attack, decay, sustain, release };
};

attachMiniGraphDrag('env1-graph', (x, y) => {
  const v = mapEnvDrag(x, y);
  setSliderAndParam('env1-attack', Params.ENV1_ATTACK, v.attack);
  setSliderAndParam('env1-decay', Params.ENV1_DECAY, v.decay);
  setSliderAndParam('env1-sustain', Params.ENV1_SUSTAIN, v.sustain);
  setSliderAndParam('env1-release', Params.ENV1_RELEASE, v.release);
});

attachMiniGraphDrag('env2-graph', (x, y) => {
  const v = mapEnvDrag(x, y);
  setSliderAndParam('env2-attack', Params.ENV2_ATTACK, v.attack);
  setSliderAndParam('env2-decay', Params.ENV2_DECAY, v.decay);
  setSliderAndParam('env2-sustain', Params.ENV2_SUSTAIN, v.sustain);
  setSliderAndParam('env2-release', Params.ENV2_RELEASE, v.release);
});

// Filter 1 Mix (dry/wet)
(function () {
  const filter1Mix = document.getElementById('filter-mix');
  const filter1MixVal = document.getElementById('filter-mix-val');
  if (filter1Mix) {
    filter1Mix.addEventListener('input', (e) => {
      const value = parseInt(e.target.value);
      const norm = value / 100;
      if (filter1MixVal) filter1MixVal.innerHTML = `${value}<span class="unit">%</span>`;
      sendParam(Params.FILTER_1_MIX, norm);
      if (window.filter1Viz) window.filter1Viz.setMix(norm);
    });
    // initialize visualizer with current slider value
    const initialNorm = parseInt(filter1Mix.value || '50', 10) / 100;
    if (window.filter1Viz) window.filter1Viz.setMix(initialNorm);
  }
})();

// Filter 2 Mix (dry/wet)
(function () {
  const filter2Mix = document.getElementById('filter2-mix');
  const filter2MixVal = document.getElementById('filter2-mix-val');
  if (filter2Mix) {
    filter2Mix.addEventListener('input', (e) => {
      const value = parseInt(e.target.value);
      const norm = value / 100;
      if (filter2MixVal) filter2MixVal.innerHTML = `${value}<span class="unit">%</span>`;
      sendParam(Params.FILTER_2_MIX, norm);
      if (window.filter2Viz) window.filter2Viz.setMix(norm);
    });
    const initialNorm = parseInt(filter2Mix.value || '50', 10) / 100;
    if (window.filter2Viz) window.filter2Viz.setMix(initialNorm);
  }
})();

// Patch editor connections
(function () {
  const editor = document.getElementById('patch-editor');
  const svg = document.getElementById('patch-connections');
  const SVG_NS = 'http://www.w3.org/2000/svg';
  if (!editor || !svg) return;
  let defs = svg.querySelector('defs');
  const ensureDefs = () => {
    if (!defs) {
      defs = document.createElementNS(SVG_NS, 'defs');
      svg.appendChild(defs);
    } else if (!defs.parentNode) {
      svg.appendChild(defs);
    }
    return defs;
  };
  ensureDefs();
  const gradientSources = new Set(['osc1', 'osc2', 'noise', 'transient']);
  const laneAssignments = {
    osc1: 3,
    osc2: 1,
    noise: 1,
    transient: 3,
    filter1: 3,
    filter2: 0,
    modal: 0,
    output: 0
  };
  const LANE_EXIT_SPACING = 11;
  const LANE_APPROACH_SPACING = 9;
  const BASE_EXIT = 20;
  const BASE_APPROACH = 18;
  const NODE_CLEARANCE = 10;
  const MIN_SEGMENT_GAP = 18;
  const VERTICAL_GAP = 10;
  const HORIZONTAL_GAP = 8;
  const SKIP_FIRST_BEND = new Set(['osc1', 'noise']);
  const SINGLE_BEND_SOURCES = new Set(['osc1', 'osc2', 'transient', 'noise']);
  const DETOUR_EXEMPT_SOURCES = new Set(['osc1', 'osc2', 'transient', 'noise']);
  // Node-specific bend positions (either 0-1 ratio or 0-10 step which is /10)
  const nodeBendProfiles = {
    osc1: { corner1: 2, corner2: 5 },
    transient: { corner1: 0, corner2: 7 }
  };
  const nodeMidlaneOffsets = {
    noise: 24,
    transient: 30
  };
  const horizontalOffsetNodes = new Set(['osc1', 'osc2']);

  const hashString = (str) => {
    if (!str) return 0;
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      hash = (hash * 31 + str.charCodeAt(i)) & 0xffff;
    }
    return hash;
  };
  const computeLaneBand = (fromNode, toNode) => {
    const key = `${fromNode || ''}->${toNode || ''}`;
    const hash = hashString(key);
    return (hash % 3) - 1;
  };
  const getBendRatio = (nodeId, key) => {
    const profile = nodeBendProfiles[nodeId];
    if (!profile || typeof profile[key] !== 'number') return null;
    const raw = profile[key];
    const ratio = raw > 1 ? raw / 10 : raw;
    return Math.max(0, Math.min(1, ratio));
  };
  const getMidOffset = (nodeId, startY, endY) => {
    const offset = nodeMidlaneOffsets[nodeId];
    if (typeof offset !== 'number') return null;
    const base = Math.max(startY, endY);
    return base + Math.abs(offset);
  };

  const defaultConnections = []; // Start with disconnected state - connections will be loaded from Init.json

  let connections = [...defaultConnections];
  const PATCH_CTRL_TAG = 'PATCH_ROUTES';
  let lastPatchSignature = '';
  let dragging = null;
  let armedNode = null;
  let previewPath = null;
  let drawRetryScheduled = false;
  let nodeBoundsCache = [];
  const clampY = (val) => {
    if (!editor) return val;
    return Math.max(0, Math.min(editor.clientHeight, val));
  };

  const updateSvgSize = () => {
    svg.setAttribute('width', editor.clientWidth);
    svg.setAttribute('height', editor.clientHeight);
  };

  const getHandleCenter = (handle) => {
    const rect = handle.getBoundingClientRect();
    const hostRect = editor.getBoundingClientRect();
    const nodeId = handle?.dataset?.node;
    return {
      x: rect.left - hostRect.left + rect.width / 2,
      y: rect.top - hostRect.top + rect.height / 2,
      lane: nodeId && Object.prototype.hasOwnProperty.call(laneAssignments, nodeId) ? laneAssignments[nodeId] : 0
    };
  };

  const getNodeBounds = (handle) => {
    const nodeEl = handle.closest('.patch-node');
    if (!nodeEl) return null;
    const rect = nodeEl.getBoundingClientRect();
    const hostRect = editor.getBoundingClientRect();
    return {
      left: rect.left - hostRect.left,
      right: rect.right - hostRect.left,
      top: rect.top - hostRect.top,
      bottom: rect.bottom - hostRect.top
    };
  };

  const getNodeTint = (nodeId) => {
    const nodeEl = editor.querySelector(`.patch-node[data-node="${nodeId}"]`);
    if (!nodeEl) return null;
    const theme = nodeEl.dataset.theme;
    if (theme && THEME_COLOR_VARS[theme]) {
      const themeColor = resolveCssColor(readThemeColor(THEME_COLOR_VARS[theme], ''));
      if (themeColor) return themeColor;
    }
    const styles = window.getComputedStyle(nodeEl);
    const tint = resolveCssColor(styles.getPropertyValue('--patch-tint'));
    return tint && tint.length ? tint : null;
  };

  const createGradient = (id, fromNode, toNode) => {
    const gradient = document.createElementNS(SVG_NS, 'linearGradient');
    gradient.setAttribute('id', id);
    gradient.setAttribute('gradientUnits', 'objectBoundingBox');
    gradient.setAttribute('x1', '0%');
    gradient.setAttribute('y1', '0%');
    gradient.setAttribute('x2', '100%');
    gradient.setAttribute('y2', '0%');
    const fromTint = getNodeTint(fromNode) || '255,255,255';
    const toTint = getNodeTint(toNode) || fromTint;
    const stopStart = document.createElementNS(SVG_NS, 'stop');
    stopStart.setAttribute('offset', '0%');
    stopStart.setAttribute('stop-color', `rgba(${fromTint}, 0.95)`);
    const stopEnd = document.createElementNS(SVG_NS, 'stop');
    stopEnd.setAttribute('offset', '100%');
    stopEnd.setAttribute('stop-color', `rgba(${toTint}, 0.85)`);
    gradient.appendChild(stopStart);
    gradient.appendChild(stopEnd);
    return { gradient, fallbackStroke: `rgba(${fromTint}, 0.9)` };
  };

  const clampCorner = (dir, value, limit) => {
    if (dir > 0) return Math.max(value, limit);
    return Math.min(value, limit);
  };

  const refreshNodeBounds = () => {
    const hostRect = editor.getBoundingClientRect();
    nodeBoundsCache = Array.from(editor.querySelectorAll('.patch-node')).map(node => {
      const rect = node.getBoundingClientRect();
      return {
        id: node.dataset.node,
        left: rect.left - hostRect.left,
        right: rect.right - hostRect.left,
        top: rect.top - hostRect.top,
        bottom: rect.bottom - hostRect.top
      };
    });
  };

  const adjustVerticalSegment = (x, yStart, yEnd, dir, skipIds, boundsList) => {
    if (!boundsList || !boundsList.length) return x;
    let newX = x;
    const minY = Math.min(yStart, yEnd);
    const maxY = Math.max(yStart, yEnd);
    let moved = true;
    let guard = 0;
    while (moved && guard < 6) {
      moved = false;
      for (const info of boundsList) {
        if (skipIds.has(info.id)) continue;
        if (maxY <= info.top || minY >= info.bottom) continue;
        if (newX >= info.left - NODE_CLEARANCE && newX <= info.right + NODE_CLEARANCE) {
          newX = dir > 0 ? info.right + NODE_CLEARANCE : info.left - NODE_CLEARANCE;
          moved = true;
        }
      }
      guard++;
    }
    return newX;
  };

  const nodeColumnIndex = {
    osc1: 0,
    osc2: 0,
    noise: 0,
    transient: 0,
    filter1: 1,
    filter2: 2,
    modal: 3,
    output: 4
  };
  const nodesRequiringInput = new Set(['filter1', 'filter2', 'modal', 'output']);
  const nodeInputActive = new Map();

  const buildCablePath = (start, end, sourceNode = null, targetNode = null) => {
    const dx = end.x - start.x;
    const baseDir = dx === 0 ? 0 : dx > 0 ? 1 : -1;
    const points = [{ x: start.x, y: start.y }];
    const roundRadius = 5;
    let currentX = start.x;
    let currentY = start.y;
    const pushPoint = (x, y) => {
      if (Math.abs(x - currentX) < 0.5 && Math.abs(y - currentY) < 0.5) return;
      points.push({ x, y });
      currentX = x;
      currentY = y;
    };

    if (baseDir === 0) {
      pushPoint(start.x, end.y);
      pushPoint(end.x, end.y);
      return buildRoundedPath(points, roundRadius);
    }

    const fromCol = nodeColumnIndex[sourceNode];
    const toCol = nodeColumnIndex[targetNode];
    const hasColumns = typeof fromCol === 'number' && typeof toCol === 'number';
    const colGap = hasColumns ? Math.abs(toCol - fromCol) : 0;
    let needsDetour = hasColumns && colGap >= 2;
    if (needsDetour && DETOUR_EXEMPT_SOURCES.has(sourceNode) && typeof toCol === 'number' && toCol > 1) {
      needsDetour = false;
    }
    const singleBendCandidate = SINGLE_BEND_SOURCES.has(sourceNode) && !needsDetour;
    const skipLower = needsDetour && sourceNode === 'filter2';
    if (needsDetour) {
      if (skipLower) {
        const bottom = clampY((editor?.clientHeight ?? 0) - 30);
        const dropX = start.x + baseDir * 5;
        pushPoint(dropX, currentY);
        pushPoint(dropX, bottom);
        pushPoint(end.x - baseDir * 5, bottom);
        currentX = end.x - baseDir * 5;
        currentY = bottom;
      } else {
        const detourY = currentY - 30;
        if (SKIP_FIRST_BEND.has(sourceNode)) {
          const straightRun = Math.min(40, Math.abs(end.x - currentX) * 0.25);
          if (straightRun > 0) {
            const runX = currentX + baseDir * straightRun;
            pushPoint(runX, currentY);
            currentX = runX;
          }
        }
        pushPoint(currentX, detourY);
        currentY = detourY;
      }
    } else if (singleBendCandidate) {
      const span = Math.abs(end.x - currentX);
      const bend = Math.max(8, Math.min(10, span * 0.35)) + 5;
      const runX = end.x - baseDir * bend;
      pushPoint(runX, currentY);
      if (end.y !== currentY) {
        pushPoint(runX, end.y);
      }
      pushPoint(end.x, end.y);
      return buildRoundedPath(points, roundRadius);
    }

    let dir = end.x >= currentX ? 1 : -1;
    const remainingDx = end.x - currentX;
    const minApproach = (end.y !== currentY && (sourceNode === 'filter1' || sourceNode === 'filter2')) ? 5 : 0;
    const approach = Math.max(minApproach, Math.min(20, Math.abs(remainingDx)));
    const straightX = end.x - dir * approach;
    pushPoint(straightX, currentY);
    if (approach > 0) {
      pushPoint(straightX, end.y);
    }
    pushPoint(end.x, end.y);
    return buildRoundedPath(points, roundRadius);
  };

  const buildRoundedPath = (pts, radius = roundRadius) => {
    if (!pts.length) return '';
    let d = `M${pts[0].x},${pts[0].y}`;
    let prev = { ...pts[0] };
    for (let i = 1; i < pts.length; i++) {
      const curr = pts[i];
      const next = i + 1 < pts.length ? pts[i + 1] : null;
      if (!next) {
        d += ` L${curr.x},${curr.y}`;
        prev = { ...curr };
        continue;
      }
      const dx1 = curr.x - prev.x;
      const dy1 = curr.y - prev.y;
      const dx2 = next.x - curr.x;
      const dy2 = next.y - curr.y;
      const straight = (dx1 === 0 && dx2 === 0) || (dy1 === 0 && dy2 === 0);
      if (straight) {
        d += ` L${curr.x},${curr.y}`;
        prev = { ...curr };
        continue;
      }
      const len1 = Math.abs(dx1 !== 0 ? dx1 : dy1);
      const len2 = Math.abs(dx2 !== 0 ? dx2 : dy2);
      const cut = Math.min(radius, len1 / 2, len2 / 2);
      const before = { x: curr.x, y: curr.y };
      const after = { x: curr.x, y: curr.y };
      if (dx1 !== 0) before.x -= Math.sign(dx1) * cut;
      else before.y -= Math.sign(dy1) * cut;
      if (dx2 !== 0) after.x += Math.sign(dx2) * cut;
      else after.y += Math.sign(dy2) * cut;
      d += ` L${before.x},${before.y}`;
      d += ` Q${curr.x},${curr.y} ${after.x},${after.y}`;
      prev = after;
      pts[i] = after;
    }
    return d;
  };

  const getPatchPayload = () => ({
    version: 1,
    routes: connections.map((conn, index) => ({
      index,
      from: conn.from,
      to: conn.to
    }))
  });

  const sendPatchPayload = (jsonStr) => {
    try {
      if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.callback) {
        window.webkit.messageHandlers.callback.postMessage({
          msg: 'SCMFUI',
          ctrlTag: PATCH_CTRL_TAG,
          data: jsonStr
        });
      } else {
        console.warn('[PatchBridge] iPlug2 bridge not available');
      }
    } catch (e) {
      console.error('[PatchBridge] Failed to send patch payload:', e);
    }
  };

  const maybeSendPatchPayload = () => {
    const payload = getPatchPayload();
    const signature = JSON.stringify(payload);
    if (signature === lastPatchSignature) return;
    lastPatchSignature = signature;
    sendPatchPayload(signature);
  };

  const updateNodeInputState = () => {
    let activeTargets;
    let changed = false;
    do {
      activeTargets = new Set(connections.map(c => c.to));
      const inactiveSources = new Set();
      nodesRequiringInput.forEach(id => {
        if (!activeTargets.has(id)) inactiveSources.add(id);
      });
      if (!inactiveSources.size) break;
      const filtered = connections.filter(conn => !inactiveSources.has(conn.from));
      if (filtered.length === connections.length) break;
      connections = filtered;
      changed = true;
    } while (true);
    nodesRequiringInput.forEach(id => {
      const nodeEl = editor.querySelector(`.patch-node[data-node="${id}"]`);
      const active = activeTargets.has(id);
      nodeInputActive.set(id, active);
      if (nodeEl) nodeEl.classList.toggle('patch-node--inactive', !active);
    });
    return changed;
  };

  const drawConnections = () => {
    updateSvgSize();
    refreshNodeBounds();
    updateNodeInputState();
    Array.from(svg.children).forEach(child => {
      if (child !== defs) svg.removeChild(child);
    });
    const defsNode = ensureDefs();
    while (defsNode.firstChild) defsNode.removeChild(defsNode.firstChild);
    let missingHandle = false;
    connections.forEach(conn => {
      const fromHandle = editor.querySelector(`.patch-handle--out[data-node="${conn.from}"]`);
      const toHandle = editor.querySelector(`.patch-handle--in[data-node="${conn.to}"]`);
      if (!fromHandle || !toHandle) {
        missingHandle = true;
        return;
      }
      const start = getHandleCenter(fromHandle);
      start.lane = laneAssignments[conn.from] ?? start.lane ?? 0;
      const end = getHandleCenter(toHandle);
      const fromBounds = getNodeBounds(fromHandle);
      const toBounds = getNodeBounds(toHandle);
      const useGradient = gradientSources.has(conn.from);
      const path = document.createElementNS(SVG_NS, 'path');
      path.setAttribute('class', 'patch-connection-line');
      path.setAttribute('d', buildCablePath(start, end, conn.from, conn.to));
      const length = Math.hypot(end.x - start.x, end.y - start.y);
      // console.log(`[PatchLength] ${conn.from} -> ${conn.to}: ${length.toFixed(2)}px`);
      if (useGradient) {
        const gradId = `patch-conn-${conn.from}-${conn.to}`;
        const { gradient, fallbackStroke } = createGradient(gradId, conn.from, conn.to);
        defsNode.appendChild(gradient);
        if (fallbackStroke) {
          path.setAttribute('stroke', fallbackStroke);
        }
        path.style.stroke = `url(#${gradId})`;
      } else {
        const tint = getNodeTint(conn.from) || getNodeTint(conn.to) || '255,255,255';
        path.setAttribute('stroke', `rgba(${tint}, 0.9)`);
      }
      svg.appendChild(path);
    });
    if (dragging && previewPath) {
      svg.appendChild(previewPath);
    }
    maybeSendPatchPayload();
    if (missingHandle && !drawRetryScheduled) {
      drawRetryScheduled = true;
      requestAnimationFrame(() => {
        drawRetryScheduled = false;
        drawConnections();
      });
    }
  };

  const pickInputHandleAtPoint = (clientX, clientY) => {
    const previousVisibility = svg.style.visibility;
    svg.style.visibility = 'hidden';
    const target = document.elementFromPoint(clientX, clientY);
    svg.style.visibility = previousVisibility || '';
    return target ? target.closest('.patch-handle--in') : null;
  };

  const ensurePreviewPath = () => {
    if (!previewPath) {
      previewPath = document.createElementNS(SVG_NS, 'path');
      previewPath.setAttribute('class', 'patch-connection-line patch-connection-line--preview');
    }
    if (dragging) previewPath.style.stroke = `rgba(${getNodeTint(dragging.from) || '255,255,255'}, 0.55)`;
    return previewPath;
  };

  const updatePreview = (point) => {
    if (!dragging) return;
    const start = dragging.start;
    const path = ensurePreviewPath();
    path.setAttribute('d', buildCablePath(start, point, dragging.from, dragging.previewTarget || null));
    if (!path.parentNode) svg.appendChild(path);
  };

  const cancelPreview = () => {
    if (previewPath && previewPath.parentNode) {
      previewPath.parentNode.removeChild(previewPath);
    }
  };

  const pointerMove = (event) => {
    if (!dragging) return;
    const dx = Math.abs(event.clientX - dragging.pointerStart.x);
    const dy = Math.abs(event.clientY - dragging.pointerStart.y);
    if (!dragging.moved && (dx > 2 || dy > 2)) {
      dragging.moved = true;
      ensurePreviewPath();
    }
    if (!dragging.moved) return;
    const rect = editor.getBoundingClientRect();
    const point = {
      x: event.clientX - rect.left,
      y: event.clientY - rect.top
    };
    const hoverHandle = pickInputHandleAtPoint(event.clientX, event.clientY);
    dragging.previewTarget = hoverHandle ? hoverHandle.dataset.node : null;
    updatePreview(point);
  };

  const pointerUp = (event) => {
    if (!dragging) return;
    document.removeEventListener('pointermove', pointerMove);
    document.removeEventListener('pointerup', pointerUp);
    if (dragging.moved) {
      const handle = pickInputHandleAtPoint(event.clientX, event.clientY);
      if (handle) {
        const to = handle.dataset.node;
        if (to && to !== dragging.from) {
          connections = connections.filter(c => c.from !== dragging.from);
          connections.push({ from: dragging.from, to });
          drawConnections();
        }
      }
    }
    dragging = null;
    cancelPreview();
  };

  const canEmitFromNode = (nodeId) => {
    if (!nodeId) return false;
    if (!nodesRequiringInput.has(nodeId)) return true;
    if (!nodeInputActive.has(nodeId)) return true;
    return !!nodeInputActive.get(nodeId);
  };

  editor.addEventListener('pointerdown', (event) => {
    const handle = event.target.closest('.patch-handle--out');
    if (!handle) return;
    const nodeId = handle.dataset.node;
    if (!canEmitFromNode(nodeId)) return;
    event.preventDefault();
    if (!nodeBoundsCache.length) refreshNodeBounds();
    const start = getHandleCenter(handle);
    start.lane = laneAssignments[handle.dataset.node] ?? start.lane ?? 0;
    dragging = {
      from: nodeId,
      start,
      pointerStart: { x: event.clientX, y: event.clientY },
      fromBounds: getNodeBounds(handle),
      previewTarget: null,
      moved: false
    };
    document.addEventListener('pointermove', pointerMove);
    document.addEventListener('pointerup', pointerUp);
  });

  editor.addEventListener('click', (event) => {
    const outHandle = event.target.closest('.patch-handle--out');
    if (outHandle) {
      const node = outHandle.dataset.node;
      if (!node) return;
      if (!canEmitFromNode(node)) return;
      connections = connections.filter(c => c.from !== node);
      armedNode = node;
      drawConnections();
      return;
    }
    const inHandle = event.target.closest('.patch-handle--in');
    if (inHandle && armedNode) {
      const to = inHandle.dataset.node;
      if (to && to !== armedNode) {
        connections = connections.filter(c => c.from !== armedNode);
        connections.push({ from: armedNode, to });
        armedNode = null;
        drawConnections();
        return;
      }
    }
    armedNode = null;
  });

  window.addEventListener('resize', drawConnections);
  if (window.ResizeObserver) {
    const resizeObserver = new ResizeObserver(() => drawConnections());
    resizeObserver.observe(editor);
    const grid = editor.querySelector('.patch-editor-grid');
    if (grid) resizeObserver.observe(grid);
  }
  if (window.MutationObserver) {
    const mutationObserver = new MutationObserver(() => drawConnections());
    const grid = editor.querySelector('.patch-editor-grid');
    if (grid) {
      mutationObserver.observe(grid, { childList: true, subtree: true });
    } else {
      mutationObserver.observe(editor, { childList: true });
    }
  }
  drawConnections();

  // Expose patch editor API to window scope for PresetManager
  window.__patchEditor = {
    getConnections: () => connections,
    setConnections: (newConnections) => {
      connections = newConnections;
      drawConnections();
    },
    drawConnections: drawConnections,
    sendPatchConfig: maybeSendPatchPayload
  };
})();

// LFO1 drag: X rate, Y depth (disable sync for free control)
attachMiniGraphDrag('lfo1-graph', (x, y) => {
  const syncCb = document.getElementById('lfo1-sync'); if (syncCb) { syncCb.checked = false; sendParam(Params.LFO1_SYNC, 0); }
  setSliderAndParam('lfo1-rate', Params.LFO1_RATE, x);
  setSliderAndParam('lfo1-depth', Params.LFO1_DEPTH, y);
  if (window.lfo1Viz) { window.lfo1Viz.setDepth(y); window.lfo1Viz.setRate(x); }
});

// LFO2 drag
attachMiniGraphDrag('lfo2-graph', (x, y) => {
  const syncCb = document.getElementById('lfo2-sync'); if (syncCb) { syncCb.checked = false; sendParam(Params.LFO2_SYNC, 0); }
  setSliderAndParam('lfo2-rate', Params.LFO2_RATE, x);
  setSliderAndParam('lfo2-depth', Params.LFO2_DEPTH, y);
  if (window.lfo2Viz) { window.lfo2Viz.setDepth(y); window.lfo2Viz.setRate(x); }
});

// Effects drags
attachMiniGraphDrag('delay-graph', (x, y) => {
  setSliderAndParam('delay-time', Params.DELAY_TIME, x);
  setSliderAndParam('delay-feedback', Params.DELAY_FEEDBACK, y);
  const mixEl = document.getElementById('delay-mix');
  const mix = mixEl ? parseInt(mixEl.value) / 100 : 0.2;
  const canvas = document.getElementById('delay-graph'); if (canvas) drawDelayGraph(canvas, x, y, mix, THEME_COLORS.effects);
});
attachMiniGraphDrag('chorus-graph', (x, y) => {
  setSliderAndParam('chorus-rate', Params.CHORUS_RATE, x);
  setSliderAndParam('chorus-depth', Params.CHORUS_DEPTH, y);
  const canvas = document.getElementById('chorus-graph');
  const mixEl = document.getElementById('chorus-mix');
  const mix = mixEl ? parseInt(mixEl.value) / 100 : 0.5;
  if (canvas) drawChorusGraph(canvas, x, y, mix, THEME_COLORS.effects);
});
// Reverb drag (map to faders): X=size, Y=damping
attachMiniGraphDrag('reverb-graph', (x, y) => {
  setSliderAndParam('reverb-size', Params.REVERB_SIZE, x);
  setSliderAndParam('reverb-damp', Params.REVERB_DAMP, y);
  // Redraw graph after change
  const mix = (reverbMixSlider ? parseInt(reverbMixSlider.value) / 100 : 0.25);
  const canvas = document.getElementById('reverb-graph'); if (canvas) drawReverbGraph(canvas, x, y, mix, THEME_COLORS.effects);
});

// Noise drag (X only): controls variant (Color/Resolution/Length)
attachMiniGraphDrag('noise-graph', (x, _y) => {
  setSliderAndParam('noise-variant', Params.NOISE_VARIANT, x);
  if (window.noiseViz) window.noiseViz.setVariant(x);
});

// ============================================================================
// Preset Management
// ============================================================================

// Built-in preset library (deprecated - now uses file-based presets from disk)
const presets = [
  {
    "version": APP_VERSION,  // Use current app version
    "id": 0,
    "name": "Init",
    "category": "Lead",
    "author": "Factory",
    "description": "Default initialization preset",
    "parameters": {
      "osc1_wave": 0.333333,
      "osc1_semi": 0.5,
      "osc1_fine": 0.5,
      "osc1_level": 1,
      "osc1_sync": 0,
      "osc2_wave": 0.333333,
      "osc2_semi": 0.5,
      "osc2_fine": 0.5,
      "osc2_level": 1,
      "osc2_detune": 0,
      "osc_mix": 0.5,
      "sub_enable": 0,
      "sub_level": 0.5,
      "noise_level": 0,
      "flt1_type": 0,
      "flt1_cutoff": 1,
      "flt1_reso": 0,
      "flt1_env_amt": 0,
      "flt1_kbd_trk": 0,
      "flt2_type": 0,
      "flt2_cutoff": 1,
      "flt2_reso": 0,
      "flt2_env_amt": 0,
      "flt2_kbd_trk": 0,
      "flt_route": 0,
      "env1_attack": 0,
      "env1_decay": 0.3,
      "env1_sustain": 0.5,
      "env1_release": 0.3,
      "env2_attack": 0,
      "env2_decay": 0.3,
      "env2_sustain": 0.5,
      "env2_release": 0.3,
      "lfo1_shape": 0.333333,
      "lfo1_rate": 0.25,
      "lfo1_fade": 0.5,
      "lfo1_sync": 0,
      "lfo2_shape": 0.333333,
      "lfo2_rate": 0.25,
      "lfo2_fade": 0.5,
      "lfo2_sync": 0,
      "vca_level": 1,
      "vca_vel_amt": 1,
      "vca_pan": 0.5,
      "master_level": 0.8,
      "master_glide": 0,
      "master_bend_range": 0.16666666666666666,
      "master_unison": 1,
      "master_detune": 0.1,
      "master_legato": 0,
      "fx_delay_time": 0.375,
      "fx_delay_fb": 0.3,
      "fx_delay_mix": 0.3,
      "fx_chorus_rate": 0.3,
      "fx_chorus_depth": 0.4,
      "fx_chorus_mix": 0.5,
      "fx_reverb_size": 0.5,
      "fx_reverb_damp": 0.5,
      "fx_reverb_mix": 0.25,
      "mod_matrix_src1": 0,
      "mod_matrix_dst1": 0,
      "mod_matrix_amt1": 0,
      "mod_matrix_src2": 0,
      "mod_matrix_dst2": 0,
      "mod_matrix_amt2": 0,
      "mod_matrix_src3": 0,
      "mod_matrix_dst3": 0,
      "mod_matrix_amt3": 0,
      "mod_matrix_src4": 0,
      "mod_matrix_dst4": 0,
      "mod_matrix_amt4": 0,
      "mod_matrix_src5": 0,
      "mod_matrix_dst5": 0,
      "mod_matrix_amt5": 0,
      "mod_matrix_src6": 0,
      "mod_matrix_dst6": 0,
      "mod_matrix_amt6": 0,
      "mod_matrix_src7": 0,
      "mod_matrix_dst7": 0,
      "mod_matrix_amt7": 0,
      "mod_matrix_src8": 0,
      "mod_matrix_dst8": 0,
      "mod_matrix_amt8": 0,
      "mod_matrix_src9": 0,
      "mod_matrix_dst9": 0,
      "mod_matrix_amt9": 0,
      "vel_to_env1_decay": 0,
      "vel_to_flt1_cutoff": 0,
      "arp_enable": 0,
      "arp_mode": 0,
      "arp_rate": 0.5,
      "arp_gate": 0.5,
      "arp_swing": 0.5,
      "sig_clip": 0,
      "sig_drive": 0,
      "sig_tone": 0.5
    },
    "wavetables": {
      "osc1A": "Sine",
      "osc1B": "Sine",
      "osc2A": "Sine",
      "osc2B": "Sine"
    },
    "matrix": [
      {
        "source": 1,
        "destination": 19,
        "amount": 1
      }
    ]
  }
];

// Allowed preset categories (alphabetical)
// Note: Strings merged into Pad, Brass added
const PRESET_CATEGORIES = ['Bass', 'Bell', 'Brass', 'Effect', 'Keys', 'Lead', 'Pad', 'Percussion', 'Pluck'];

// Preset Manager (header viewer uses this)
class PresetManager {
  constructor() {
    this.currentIndex = 0;
    this.presets = presets;
    this.nameEl = document.getElementById('preset-name');
    this.categoryEl = document.getElementById('preset-category');
    this.prevBtn = document.getElementById('preset-prev');
    this.nextBtn = document.getElementById('preset-next');
    this.saveBtn = document.getElementById('pv-save');
    this.saveAsBtn = document.getElementById('pv-save-as');
    this.setupEventListeners();
    this.updateDisplay();
  }
  setupEventListeners() {
    if (this.prevBtn) this.prevBtn.addEventListener('click', () => this.previousPreset());
    if (this.nextBtn) this.nextBtn.addEventListener('click', () => this.nextPreset());
    if (this.saveBtn) this.saveBtn.addEventListener('click', () => this.savePreset());
    if (this.saveAsBtn) this.saveAsBtn.addEventListener('click', () => this.savePresetAs());

    // Preset viewer filter/search/sort controls
    const searchInput = document.getElementById('pv-search');
    const sortSelect = document.getElementById('pv-sort');
    const favFilter = document.getElementById('pv-fav-filter');
    const categoryGroup = document.getElementById('pv-category-group');
    const cancelBtn = document.querySelector('.sort-btn[data-category="Cancel"]');

    // Initialize active category set
    this.activeCategories = new Set();
    this.favFilterActive = false;

    // Category filter buttons (AND logic, multi-select)
    const updateCancelVisibility = () => {
      if (!cancelBtn) return;
      const hasSearch = searchInput && searchInput.value.trim().length > 0;
      const hasFilters = this.activeCategories.size > 0 || this.favFilterActive || hasSearch;
      cancelBtn.disabled = !hasFilters;
    };

    if (categoryGroup) {
      categoryGroup.querySelectorAll('.sort-btn[data-category]').forEach(btn => {
        btn.addEventListener('click', () => {
          const category = btn.dataset.category;
          // Toggle category
          if (this.activeCategories.has(category)) {
            this.activeCategories.delete(category);
            btn.classList.remove('active');
          } else {
            this.activeCategories.add(category);
            btn.classList.add('active');
          }

          updateCancelVisibility();
          this.renderPresetTable();
        });
      });
    }
    updateCancelVisibility();

    if (cancelBtn) {
      cancelBtn.addEventListener('click', () => {
        if (cancelBtn.disabled) return;
        // Clear all filters
        this.activeCategories.clear();
        if (categoryGroup) {
          categoryGroup.querySelectorAll('.sort-btn').forEach(b => b.classList.remove('active'));
        }
        this.favFilterActive = false;
        if (favFilter) {
          favFilter.classList.remove('active');
          favFilter.querySelector('.fukiai').innerHTML = '&#xEA65;';
        }
        if (searchInput) {
          searchInput.value = '';
        }
        updateCancelVisibility();
        this.renderPresetTable();
      });
    }

    // Favorite filter toggle
    if (favFilter) {
      favFilter.addEventListener('click', () => {
        this.favFilterActive = !this.favFilterActive;
        favFilter.classList.toggle('active', this.favFilterActive);
        // Update icon
        favFilter.querySelector('.fukiai').innerHTML = this.favFilterActive ? '&#xEA64;' : '&#xEA65;';
        updateCancelVisibility();
        this.renderPresetTable();
      });
    }

    if (searchInput) {
      searchInput.addEventListener('input', () => {
        updateCancelVisibility();
        this.renderPresetTable();
      });
    }

    if (sortSelect) {
      sortSelect.addEventListener('change', () => this.renderPresetTable());
    }

    console.log('✓ Preset viewer UI event listeners attached');
  }
  previousPreset() {
    this.currentIndex = (this.currentIndex - 1 + this.presets.length) % this.presets.length;
    this.updateDisplay();
    this.renderPresetTable();  // Update .current class in table

    // Load preset from file instead of hardcoded array
    const preset = this.presets[this.currentIndex];
    if (preset && preset.filename) {
      console.log(`⬅️ Loading previous preset from file: ${preset.filename}`);
      if (typeof window.presetLoadFromFile === 'function') {
        window.presetLoadFromFile(preset.filename);
      }
    }
  }

  nextPreset() {
    this.currentIndex = (this.currentIndex + 1) % this.presets.length;
    this.updateDisplay();
    this.renderPresetTable();  // Update .current class in table

    // Load preset from file instead of hardcoded array
    const preset = this.presets[this.currentIndex];
    if (preset && preset.filename) {
      console.log(`➡️ Loading next preset from file: ${preset.filename}`);
      if (typeof window.presetLoadFromFile === 'function') {
        window.presetLoadFromFile(preset.filename);
      }
    }
  }

  savePreset() {
    const currentPreset = this.presets[this.currentIndex];

    // Overwrite current preset
    // First, sync matrix configuration from DOM to __matrixRoutes
    sendMatrixConfig();
    this._doSavePreset(currentPreset.name, currentPreset.category, currentPreset.description, currentPreset.author || 'User', true, currentPreset.version);
  }

  savePresetAs() {
    // Show modal instead of using prompt()
    const overlay = document.getElementById('saveas-overlay');
    const modal = document.getElementById('saveas-modal');
    const nameInput = document.getElementById('saveas-name');
    const categorySelect = document.getElementById('saveas-category');
    const descriptionInput = document.getElementById('saveas-description');

    // Pre-fill with current preset data
    const currentPreset = this.presets[this.currentIndex] || {};
    nameInput.value = currentPreset.name || 'New Preset';
    categorySelect.value = currentPreset.category || 'User';
    descriptionInput.value = currentPreset.description || '';

    // Add active class to show modal (relies on CSS .active class)
    overlay.classList.add('active');
    modal.classList.add('active');
    nameInput.focus();
    nameInput.select();
  }

  // Helper: Get wavetable name for a given oscillator and slot
  // Returns the current Factory wavetable name (Sine, Sawtooth, Square, etc.)
  _getWavetableName(oscNum, slot) {
    // Get the showcase for this oscillator (osc1 or osc2)
    const showcase = (oscNum === 'osc1' ? window.osc1Showcase : window.osc2Showcase);
    if (!showcase) {
      console.warn(`Showcase not found for ${oscNum}, defaulting to Sine`);
      return 'Sine';
    }

    // Map slot letter to bank key ('a' -> 'A', 'b' -> 'B')
    const bankKey = String(slot).toUpperCase();
    const currentIndex = showcase.banks[bankKey] !== undefined ? showcase.banks[bankKey] : 0;

    // Factory wavetable names array (must match order in factoryWavetableTemplate)
    const factoryNames = ['Sine', 'Sawtooth', 'Square', 'Triangle', 'Ramp', 'Parabola'];

    // Return the factory name at this index, or default to Sine
    if (currentIndex >= 0 && currentIndex < factoryNames.length) {
      return factoryNames[currentIndex];
    } else {
      console.warn(`Invalid wavetable index ${currentIndex} for ${oscNum}${bankKey}, defaulting to Sine`);
      return 'Sine';
    }
  }

  _doSavePreset(name, category, description, author, isOverwrite) {
    if (name) {
      // Build wavetable references from current oscillator state
      // Factory wavetables: Embedded in plugin code (Sine, Sawtooth, Square, Ramp, etc.)
      // Custom wavetables: Saved separately in ~/Wavetables/ directory
      const wavetables = {
        osc1_a: {
          bank: 'Factory',  // Factory wavetables are built into plugin
          name: this._getWavetableName('osc1', 'a')  // e.g., "Sawtooth", "Sine"
        },
        osc1_b: {
          bank: 'Factory',
          name: this._getWavetableName('osc1', 'b')
        },
        osc2_a: {
          bank: 'Factory',
          name: this._getWavetableName('osc2', 'a')
        },
        osc2_b: {
          bank: 'Factory',
          name: this._getWavetableName('osc2', 'b')
        }
      };

      // Create preset data with current plugin version
      const presetData = {
        version: APP_VERSION,  // Match plugin version (0.0.1)
        id: `preset-${Date.now()}`,  // Unique preset ID
        name: name,
        category: category || 'User',
        author: author || 'User',
        description: description || '',
        wavetables: wavetables,  // Include wavetable references
        parameters: indexedParamsToNamed(window.__parameterValues),
        matrix: __matrixRoutes.map(route => {
          console.log(`💾 Saving matrix route: source=${route.source}, slot=${route.slot}, dest=${route.destination}, amount=${route.amount}, sleep=${route.isSleep || false}`);
          return {
            source: route.source,
            slot: route.slot || 0,  // Matrix slot index (0-15)
            destination: route.destination,
            amount: route.amount / 100,  // Convert 0-100 to 0-1
            isSleep: route.isSleep || false  // Save sleep state
          };
        }),
        patch: (window.__patchEditor ? window.__patchEditor.getConnections() : []).map(conn => ({
          from: conn.from,
          to: conn.to
        }))
      };

      // Save to file system via C++ bridge
      try {
        if (typeof window.presetSaveToFile === 'function') {
          // Show progress bar during save
          const progressBar = document.getElementById('loading-progress-bar');
          if (progressBar) {
            progressBar.style.display = 'block';
            progressBar.style.opacity = '1';
          }
          updateLoadingProgress(0);

          // Simulate progress during save operation
          let saveProgress = 0;
          const saveProgressInterval = setInterval(() => {
            saveProgress += Math.random() * 40;
            if (saveProgress < 90) {
              updateLoadingProgress(saveProgress);
            }
          }, 100);

          window.presetSaveToFile(name, presetData);
          console.log(`Sent preset save request: ${name}`, presetData);

          // Finish progress after brief delay
          setTimeout(() => {
            clearInterval(saveProgressInterval);
            updateLoadingProgress(100);

            // Refresh preset list after saving
            if (typeof window.presetListRequest === 'function') {
              window.presetListRequest();
            }

            // Fade out progress bar
            setTimeout(() => {
              if (progressBar) {
                progressBar.style.opacity = '0';
                progressBar.style.transition = 'opacity 0.5s ease';
                setTimeout(() => {
                  progressBar.style.display = 'none';
                }, 500);
              }
            }, 200);

            alert(`Preset "${name}" saved!`);
          }, 300);
        } else {
          console.error('presetSaveToFile bridge function not available');
          alert('Failed to save preset: File bridge not available.');
        }
      } catch (e) {
        console.error('Failed to save preset:', e);
        alert('Failed to save preset. Check console for details.');
      }
    }
  }

  updateDisplay() {
    const p = this.presets[this.currentIndex];
    if (this.nameEl) this.nameEl.textContent = p.name;
    if (this.categoryEl) this.categoryEl.textContent = p.category || 'General';
    // Update data-category attribute on .preset-controls element
    const presetControls = document.querySelector('.preset-controls');
    if (presetControls && p) {
      presetControls.setAttribute('data-category', p.category || 'General');
    }
    setupPresetNameMarquee();
  }

  // DEPRECATED: Old loadPreset() - use applyPreset() instead
  // This method is kept for backward compatibility but should not be used
  loadPreset() {
    const preset = this.presets[this.currentIndex];
    console.warn(`⚠️  loadPreset() called (deprecated) - use applyPreset() instead`);
    // Delegate to new applyPreset method
    window.presetManager.applyPreset(preset);
  }

  // NEW METHOD: Update preset list from C++ file system
  updatePresetList(presetListArray) {
    console.log('📋 Updating preset list from file system:', presetListArray);

    if (!Array.isArray(presetListArray)) {
      console.error('updatePresetList: expected array, got:', typeof presetListArray);
      console.error('  Input value:', presetListArray);
      return;
    }

    // Replace the hardcoded presets array with file-based presets
    this.presets = presetListArray.map((p, idx) => {
      console.log(`  Processing preset[${idx}]:`, p);
      if (!p || typeof p !== 'object') {
        console.error(`    ERROR: preset[${idx}] is not an object:`, p);
      }
      return {
        name: p?.name || 'Unnamed',
        category: p?.category || 'User',
        author: p?.author || 'User',
        description: p?.description || '',
        version: p?.version || '0.0.1',  // Preset version from C++
        favorite: p?.favorite || false,
        filename: p?.filename || `${p?.name || 'Unknown'}.awaon`  // Filename for loading
      };
    });

    console.log(`✓ Loaded ${this.presets.length} presets from file system`);
    console.log('  Processed presets:', this.presets);

    // Update display with first preset (or keep current if valid)
    if (this.currentIndex >= this.presets.length) {
      this.currentIndex = 0;
    }
    this.updateDisplay();

    // Populate the preset viewer table
    this.renderPresetTable();
  }

  // NEW METHOD: Apply loaded preset data from C++
  applyPreset(presetData) {
    // Validate preset data
    if (!presetData || typeof presetData !== 'object') {
      showErrorBalloon('Invalid Preset Format', 'Preset data is not valid JSON object');
      return;
    }

    console.log('📥 Applying preset from file:', presetData);

    // Check preset version compatibility
    const presetVersion = presetData.version || '1.0';  // Default to old format if not specified
    if (presetVersion !== APP_VERSION) {
      console.warn(`⚠️  Preset version mismatch: preset is v${presetVersion}, app is v${APP_VERSION}`);
    }

    // Detect missing parameters by comparing preset params with current PARAM_NAMES
    const presetParams = presetData.parameters || {};
    const expectedParamCount = PARAM_NAMES.length;
    const missingParams = [];

    for (let idx = 0; idx < expectedParamCount; idx++) {
      const paramName = PARAM_NAMES[idx];
      if (!(paramName in presetParams)) {
        missingParams.push(paramName);
      }
    }

    // Show warning balloon if parameters are missing
    if (missingParams.length > 0) {
      const missingCount = missingParams.length;
      const maxDisplay = 5;
      const displayParams = missingParams.slice(0, maxDisplay).join(', ');
      const moreText = missingCount > maxDisplay ? ` +${missingCount - maxDisplay} more` : '';
      const message = `${missingCount} parameter(s) missing: ${displayParams}${moreText}`;
      console.warn(`⚠️  ${message}`);
      console.warn('Missing parameters:', missingParams);

      // Show warning balloon
      showBalloonWarning('Preset Compatibility', message);
    }

    // Load parameters
    if (presetData.parameters && Object.keys(presetData.parameters).length > 0) {
      try {
        // Debug: log transient and other missing parameters
        console.log('🔍 Checking preset parameters:');
        console.log('  trans_decay:', presetData.parameters.trans_decay);
        console.log('  trans_timbre:', presetData.parameters.trans_timbre);
        console.log('  trans_level:', presetData.parameters.trans_level);
        console.log('  osc1_compound:', presetData.parameters.osc1_compound);
        console.log('  osc2_compound:', presetData.parameters.osc2_compound);
        console.log('  lfo1_tempo_div:', presetData.parameters.lfo1_tempo_div);
        console.log('  lfo2_tempo_div:', presetData.parameters.lfo2_tempo_div);
        console.log('  lfo1_sync:', presetData.parameters.lfo1_sync);
        console.log('  lfo2_sync:', presetData.parameters.lfo2_sync);
        console.log('  delay_sync:', presetData.parameters.delay_sync);
        console.log('  filter_slope:', presetData.parameters.filter_slope);
        console.log('  filter2_slope:', presetData.parameters.filter2_slope);

        const indexedParams = namedParamsToIndexed(presetData.parameters);
        const paramCount = Object.keys(indexedParams).length;

        // Debug: Log parameter indices to check for out-of-bounds
        const paramIndices = Object.keys(indexedParams).map(Number).sort((a, b) => a - b);
        const maxIdx = Math.max(...paramIndices);
        console.log(`📊 Parameter conversion: ${paramCount} params, indices: [${paramIndices[0]}...${maxIdx}], valid range: [0...95]`);
        if (maxIdx >= 96) {
          console.error(`❌ WARNING: Max index ${maxIdx} >= 96, bounds check will filter these`);
        }

        // Validate that conversion succeeded
        if (paramCount === 0) {
          console.error('❌ Parameter conversion failed: namedParamsToIndexed returned empty object');
          console.error('Input parameters:', presetData.parameters);
          // Retry if bridge might not be ready
          if (typeof window.SPVFUI !== 'function') {
            console.warn('⚠️  Retrying in 100ms (bridge not ready)...');
            setTimeout(() => this.applyPreset(presetData), 100);
          }
          return;
        }

        console.log(`✅ Loading ${paramCount} parameters from preset`);

        // Check if SPVFUI is available - retry with exponential backoff if not ready
        if (typeof window.SPVFUI !== 'function') {
          console.warn('⚠️  window.SPVFUI not yet available, retrying in 100ms...');
          setTimeout(() => this.applyPreset(presetData), 100);
          return;
        }

        // Send each parameter to C++ and update DOM simultaneously
        // console.log(`[PRESET-LOAD] Processing ${Object.keys(indexedParams).length} parameters...`);

        // Special ID mappings for parameters that don't follow naming convention
        const idMappings = {
          'master': 'master-vol',      // HTML has master-vol, not master
          'master_pan': 'master-pan',
          'tune': 'global-semi',       // Global Semitone
          'octave': 'global-octave',   // Global Octave
          'bend': 'bend-range',        // Bend Range
          'voices': 'voice-num',       // Voice Number
          'voicing': 'voice-mode-group',  // Voice Mode (toggle group)
          'portamento': 'master-porta',  // Portamento (master-porta in HTML)
          'filter_slope': 'filter-slope-group',  // Filter Slope (toggle group)
          'filter2_slope': 'filter2-slope-group',  // Filter 2 Slope (toggle group)
          // Filter 1 parameters: flt1_X → filter-X
          'flt1_cutoff': 'filter-cutoff',
          'flt1_reso': 'filter-reso',
          'flt1_mix': 'filter-mix',
          // Filter 2 parameters: flt2_X → filter2-X
          'flt2_cutoff': 'filter2-cutoff',
          'flt2_reso': 'filter2-reso',
          'flt2_mix': 'filter2-mix',
          // Oscillator Compound Modes (toggle groups)
          'osc1_compound': 'osc1-comp-group',
          'osc2_compound': 'osc2-comp-group',
          // Modal Filter Type (toggle group)
          'modal_type': 'modal-type-group',
          // Transient parameters
          'trans_mode': 'transient-mode-group',  // Transient Mode (toggle group)
          'trans_decay': 'transient-decay',      // Transient Decay (range slider)
          'trans_timbre': 'transient-timbre',    // Transient Timbre (range slider)
          'trans_level': 'transient-level',      // Transient Level (range slider)
          // Signals Section Clip (toggle group)
          'sig_clip': 'signals-clip-toggle',
          // Signals Section Drive (range slider)
          'sig_drive': 'signals-drive',
          // Signals Section Tone (range slider)
          'sig_tone': 'signals-tone',
          // Delay Sync (checkbox)
          'delay_sync': 'delay-sync',
          // LFO Sync (checkboxes)
          'lfo1_sync': 'lfo1-sync',
          'lfo2_sync': 'lfo2-sync',
          // LFO Tempo Divisions (tempo mode checkboxes)
          'lfo1_tempo_div': 'lfo1-tempo-div',
          'lfo2_tempo_div': 'lfo2-tempo-div'
          // flt1_type, flt1_drive, flt2_type, flt2_drive, flt_routing don't have range inputs in UI
        };

        for (const [paramIdx, value] of Object.entries(indexedParams)) {
          const idx = parseInt(paramIdx);
          if (!isNaN(idx) && typeof value === 'number') {
            // Validate parameter index is within valid range (0-95 for 96 parameters)
            if (idx < 0 || idx >= PARAM_NAMES.length) {
              console.warn(`[PRESET-LOAD] Skipping invalid parameter index ${idx} (valid range: 0-${PARAM_NAMES.length - 1})`);
              continue;
            }

            // Also update the corresponding HTML input element if it exists
            const paramName = PARAM_NAMES[idx];
            if (paramName) {
              // Try special mappings first
              let element = null;
              if (idMappings[paramName]) {
                element = document.getElementById(idMappings[paramName]);
              }
              // Try direct name match
              if (!element) {
                element = document.getElementById(paramName);
              }
              // Try underscore to dash conversion
              if (!element && paramName.includes('_')) {
                const altId = paramName.replace(/_/g, '-');
                element = document.getElementById(altId);
              }

              // Log if element not found
              if (!element && ['lfo1_sync', 'lfo2_sync', 'delay_sync', 'osc1_compound', 'osc2_compound'].includes(paramName)) {
                console.warn(`⚠️ [ELEMENT NOT FOUND] ${paramName} - tried mappings: ${idMappings[paramName] || 'N/A'}, direct: ${paramName}, dash: ${paramName.replace(/_/g, '-')}`);
              }

              // Debug for master parameter
              if (paramName === 'master') {
                // console.log(`[PRESET-LOAD] Found master param (idx=${idx}, value=${value})`);
                // console.log(`[PRESET-LOAD] Trying mappings: '${idMappings['master']}' = ${document.getElementById(idMappings['master'])}`);
                // console.log(`[PRESET-LOAD] Final element=${element}, tagName=${element?.tagName}, type=${element?.type}`);
              }

              // Handle toggle groups (filter_slope, filter2_slope, voicing, etc.)
              if (element && element.getAttribute('data-toggle-group') !== null) {
                // Convert normalized value to button data-value
                let buttonValue;
                if (paramName === 'filter_slope' || paramName === 'filter2_slope') {
                  // Filter slope: 0=12dB, 1=24dB
                  buttonValue = value < 0.5 ? '12' : '24';
                  console.log(`🔧 [FILTER SLOPE] ${paramName}: value=${value}, buttonValue=${buttonValue}`);
                } else if (paramName === 'voicing') {
                  // Voice Mode: 0=Mono, 1=Poly, 2=Unison (0-1 normalized, 3 states)
                  const modeIdx = Math.round(value * 2);  // 0-1 → 0,1,2
                  const modeValues = ['0', '1', '2'];
                  buttonValue = modeValues[modeIdx] || '0';
                } else if (paramName === 'osc1_compound' || paramName === 'osc2_compound') {
                  // Compound Mode: fade/phase/multiply/mask (4 states)
                  const compIdx = Math.round(value * 3);  // 0-1 → 0,1,2,3
                  const compValues = ['fade', 'phase', 'multiply', 'mask'];
                  buttonValue = compValues[compIdx] || 'fade';
                } else if (paramName === 'modal_type') {
                  // Modal Type: multiple modes (need to get from HTML button count)
                  const buttons = element.querySelectorAll('.toggle-btn');
                  const modeCount = buttons.length;
                  const modalIdx = Math.round(value * (modeCount - 1));  // 0-1 → 0..N
                  buttonValue = buttons[modalIdx]?.getAttribute('data-value') || buttons[0]?.getAttribute('data-value');
                } else if (paramName === 'trans_mode') {
                  // Transient Mode: multiple modes
                  const buttons = element.querySelectorAll('.toggle-btn');
                  const modeCount = buttons.length;
                  const transIdx = Math.round(value * (modeCount - 1));  // 0-1 → 0..N
                  buttonValue = buttons[transIdx]?.getAttribute('data-value') || buttons[0]?.getAttribute('data-value');
                } else if (paramName === 'sig_clip') {
                  // Signals Clip: limit/fold/loop (3 states)
                  const clipIdx = Math.round(value * 2);  // 0-1 → 0,1,2
                  const clipValues = ['limit', 'fold', 'loop'];
                  buttonValue = clipValues[clipIdx] || 'limit';
                } else {
                  // Default: map 0-1 to button value (0 or 1)
                  buttonValue = value < 0.5 ? '0' : '1';
                }

                // Find and activate the button with matching data-value
                const buttons = element.querySelectorAll('.toggle-btn');
                buttons.forEach(btn => btn.classList.remove('active'));
                const targetBtn = element.querySelector(`[data-value="${buttonValue}"]`);
                if (targetBtn) {
                  targetBtn.classList.add('active');
                  // Trigger click event so C++ gets notified
                  targetBtn.dispatchEvent(new Event('click', { bubbles: true }));
                  console.log(`✅ [TOGGLE GROUP] ${paramName}: activated [data-value="${buttonValue}"], click event dispatched`);
                } else {
                  console.warn(`⚠️ [TOGGLE GROUP] ${paramName}: could not find button [data-value="${buttonValue}"]`);
                }
              } else if (element && element.tagName === 'INPUT' && element.type === 'checkbox') {
                // Handle checkboxes (delay_sync, lfo1_sync, lfo2_sync)
                const checked = value > 0.5;  // Normalize 0-1 to boolean
                element.checked = checked;
                // Trigger change event so C++ gets notified
                element.dispatchEvent(new Event('change', { bubbles: true }));
                console.log(`✅ [CHECKBOX] ${paramName}: value=${value} → checked=${checked}, element=${element.id}, event dispatched`);
              } else if (element && element.tagName === 'INPUT' && element.type === 'range') {
                // Denormalize value from 0-1 to actual parameter range
                const min = Number(element.min || 0);
                const max = Number(element.max || 100);

                // Check if this is a bipolar slider (-100 to +100)
                let denorm;
                if (element.classList.contains('bipolar') && min === -100 && max === 100) {
                  // Bipolar: 0-1 (normal) → -1 to +1 (bipolar) → -100 to +100 (slider value)
                  const bipolar = (value * 2.0) - 1.0;  // 0-1 → -1 to +1
                  denorm = Math.round(bipolar * 100);    // -1 to +1 → -100 to +100
                } else {
                  // Unipolar: linear mapping
                  denorm = min + value * (max - min);
                }

                // Set value BEFORE sending to C++
                element.value = denorm;
                const afterValue = element.value;

                // Update progress indicators for range sliders
                let pct;
                if (element.classList.contains('bipolar') && min === -100 && max === 100) {
                  // For bipolar sliders: center (0) should be 50%, -100 should be 0%, +100 should be 100%
                  pct = ((Number(afterValue) - min) / (max - min)) * 100;
                } else {
                  pct = ((Number(afterValue) - min) / (max - min)) * 100;
                }
                const clamped = Math.max(0, Math.min(100, pct));
                element.style.setProperty('--progress', `${clamped}%`);

                // Set progress start/end for bipolar or unipolar sliders
                if (element.classList.contains('bipolar')) {
                  if (clamped >= 50) {
                    element.style.setProperty('--progress-start', '50%');
                    element.style.setProperty('--progress-end', `${clamped}%`);
                  } else {
                    element.style.setProperty('--progress-start', `${clamped}%`);
                    element.style.setProperty('--progress-end', '50%');
                  }
                } else {
                  element.style.setProperty('--progress-start', '0%');
                  element.style.setProperty('--progress-end', `${clamped}%`);
                }

                // Debug: Log master volume specifically
                if (paramName === 'master') {
                  // const progressEnd = element.style.getPropertyValue('--progress-end');
                  // const computedStyle = window.getComputedStyle(element);
                  // const computedProgressEnd = computedStyle.getPropertyValue('--progress-end');
                  // console.log(`[PRESET-LOAD] idx=${idx} (${paramName}): norm=${value} → denorm=${denorm}`);
                  // console.log(`[PRESET-LOAD] Set element.value=${denorm}, got back element.value=${afterValue}`);
                  // console.log(`[PRESET-LOAD] pct=${pct} → clamped=${clamped}%`);
                  // console.log(`[PRESET-LOAD] After setProperty: inline --progress-end="${progressEnd}", computed --progress-end="${computedProgressEnd}"`);
                  // console.log(`[PRESET-LOAD] HTML: ${element.outerHTML.substring(0, 150)}`);
                }
              }
            }

            // Send to C++ AFTER DOM update (with bounds check)
            if (idx >= 0 && idx < 96) {
              window.SPVFUI(idx, value);
            } else {
              console.error(`❌ BOUNDS CHECK: Parameter index ${idx} out of range [0, 95], not sending to C++`);
            }
          }
        }
        // console.log(`✓ Sent ${paramCount} parameters to C++`);
        hideErrorBalloon();  // Success - hide any previous errors
      } catch (err) {
        console.error('❌ Failed to load parameters:', err);
        showErrorBalloon('Parameter Load Error', `Failed to apply preset parameters: ${err.message}`);
        return;
      }
    } else {
      // No parameters found in preset
      console.warn('⚠️  No parameters found in preset');
      showErrorBalloon('Invalid Init Preset', 'Init.json has no parameters - check preset file');
      return;
    }

    // Load wavetables from preset (v2 format with bank/name)
    if (presetData.wavetables && typeof presetData.wavetables === 'object') {
      try {
        console.log(`🎵 Loading wavetables from preset:`, presetData.wavetables);

        // Map of preset wavetable section keys to showcase prefixes
        const wavetableKeyMap = {
          'osc1_a': { showcase: 'osc1', bank: 'A' },
          'osc1_b': { showcase: 'osc1', bank: 'B' },
          'osc2_a': { showcase: 'osc2', bank: 'A' },
          'osc2_b': { showcase: 'osc2', bank: 'B' }
        };

        for (const [key, wtData] of Object.entries(presetData.wavetables)) {
          // Validate wavetable data
          if (!wtData || typeof wtData !== 'object' || !wtData.bank || !wtData.name) {
            console.warn(`⚠️  Invalid wavetable data for key "${key}": missing bank or name`);
            continue;
          }

          const mapping = wavetableKeyMap[key];
          if (!mapping) {
            console.warn(`⚠️  Unknown wavetable key: "${key}"`);
            continue;
          }

          const { showcase, bank } = mapping;
          const { bank: wtBank, name: wtName } = wtData;

          // Find wavetable index by bank/name
          const wtIndex = findWavetableIndexByBankName(wtBank, wtName, showcase);

          if (wtIndex !== -1) {
            // Find the showcase and select this wavetable
            const showcaseInstance = window[`${showcase}Showcase`];
            if (showcaseInstance && typeof showcaseInstance.selectWavetable === 'function') {
              showcaseInstance.selectWavetable(bank, wtIndex);
              console.log(`✓ Loaded wavetable for ${showcase}_${bank}: ${wtBank}/${wtName} (index ${wtIndex})`);
            } else {
              console.warn(`⚠️  Showcase not found for ${showcase}`);
            }
          } else {
            console.warn(`⚠️  Could not find wavetable: ${wtBank}/${wtName}`);
          }
        }

        console.log(`✓ Wavetables loaded from preset`);
      } catch (err) {
        console.error('❌ Failed to load wavetables:', err);
        showErrorBalloon('Wavetable Load Error', `Failed to load wavetables: ${err.message}`);
      }
    } else {
      console.log(`⚠️  No wavetables in preset (expected for old v1 presets)`);
    }

    // Load matrix
    if (presetData.matrix && Array.isArray(presetData.matrix)) {
      try {
        console.log(`🔵 Loading matrix from preset:`, presetData.matrix);
        __matrixRoutes = presetData.matrix.map((route, idx) => {
          if (!route || typeof route !== 'object') {
            throw new Error(`Invalid matrix route at index ${idx}`);
          }
          console.log(`  📥 Route ${idx}: source=${route.source}, dest=${route.destination}, amount=${route.amount}, slot=${route.slot || 0}, sleep=${route.isSleep || false}`);
          return {
            source: route.source,
            slot: route.slot !== undefined ? route.slot : idx,  // Use index as fallback for slot
            destination: route.destination,
            amount: route.amount !== undefined ? Math.round(route.amount * 100) : 50,  // Convert 0-1 to 0-100
            isSleep: route.isSleep || false  // Restore sleep state
          };
        });
        console.log(`🔵 __matrixRoutes after loading (${__matrixRoutes.length} routes):`, __matrixRoutes);

        // Render matrix in UI
        if (typeof renderModMatrix === 'function') {
          renderModMatrix();
          console.log(`✓ Matrix UI rendered with ${__matrixRoutes.length} route(s)`);
        } else {
          console.warn('⚠️  renderModMatrix() not available');
        }

        // Restore sleep states after rendering
        __matrixRoutes.forEach((route, idx) => {
          if (route.isSleep) {
            const row = document.getElementById(`matrix-row-${idx}`);
            const labelBtn = row?.querySelector('.matrix-slot-label-btn');
            if (row && labelBtn) {
              row.classList.add('is-sleep');
              labelBtn.setAttribute('aria-pressed', 'true');
            }
          }
        });

        // Send matrix config to C++
        if (typeof sendMatrixConfig === 'function') {
          sendMatrixConfig();
          console.log(`✓ Loaded and sent ${__matrixRoutes.length} matrix route(s) to C++`);
        } else {
          console.warn('⚠️  sendMatrixConfig() not available');
        }
      } catch (err) {
        console.error('❌ Failed to load matrix:', err);
        showErrorBalloon('Matrix Load Error', `Failed to load matrix routes: ${err.message}`);
      }
    } else {
      console.warn(`⚠️  No matrix data in preset (matrix is ${presetData.matrix ? 'not an array' : 'missing'})`);
    }

    // Load patch routing
    if (presetData.patch && Array.isArray(presetData.patch)) {
      console.log(`🔵 Loading patch routing from preset:`, presetData.patch);
      const newConnections = presetData.patch.map(conn => ({
        from: conn.from,
        to: conn.to
      }));
      if (window.__patchEditor) {
        window.__patchEditor.setConnections(newConnections);  // Updates connections and redraws
        window.__patchEditor.sendPatchConfig();  // Send to C++
        console.log(`✓ Loaded ${newConnections.length} patch connection(s) from preset`);
      } else {
        console.warn('⚠️  Patch editor API not available');
      }
    } else {
      console.log(`⚠️  No patch data in preset, using default routing`);
      // Keep existing connections (don't reset to default)
    }

    // Update current preset name
    if (presetData.name) {
      this.updateDisplay();
    }

    // Range sliders have already been updated in the parameter loading loop above
    // No need to call setRangeProgress() separately

    console.log(`✓ Applied preset: ${presetData.name || 'Unknown'}`);
  }

  // NEW METHOD: Render preset table in the viewer
  renderPresetTable() {
    const tbody = document.getElementById('pv-tbody');
    if (!tbody) {
      console.warn('Preset table body not found');
      return;
    }

    // Clear existing rows
    tbody.innerHTML = '';

    // Get filter values
    const searchText = (document.getElementById('pv-search')?.value || '').toLowerCase();
    const sortBy = document.getElementById('pv-sort')?.value || 'category';

    // Filter presets with AND logic for categories
    let filteredPresets = this.presets.filter(p => {
      // Category filter (AND logic - preset must match ALL selected categories)
      // If no categories selected, show all
      const matchCategory = this.activeCategories.size === 0 || this.activeCategories.has(p.category);

      // Favorite filter
      const matchFavorite = !this.favFilterActive || p.favorite === true;

      // Search filter
      const matchSearch = !searchText ||
        p.name.toLowerCase().includes(searchText) ||
        (p.description && p.description.toLowerCase().includes(searchText));

      return matchCategory && matchFavorite && matchSearch;
    });

    // Sort presets
    filteredPresets.sort((a, b) => {
      if (sortBy === 'favFirst') {
        if (a.favorite !== b.favorite) return b.favorite ? 1 : -1;
      }
      if (sortBy === 'author') {
        return (a.author || '').localeCompare(b.author || '');
      }
      if (sortBy === 'category') {
        const catCmp = (a.category || '').localeCompare(b.category || '');
        if (catCmp !== 0) return catCmp;
      }
      return a.name.localeCompare(b.name);
    });

    // Create table rows
    filteredPresets.forEach((preset, idx) => {
      const tr = document.createElement('tr');
      const presetIndex = this.presets.indexOf(preset);
      tr.dataset.presetIndex = presetIndex;
      tr.style.cursor = 'pointer';

      // Highlight current preset with .current class
      if (presetIndex === this.currentIndex) {
        tr.classList.add('current');
      }

      // Favorite column (leftmost)
      const tdFavorite = document.createElement('td');
      tdFavorite.style.textAlign = 'center';
      const favBtn = document.createElement('button');
      favBtn.type = 'button';
      favBtn.className = 'pv-favorite-btn';
      favBtn.setAttribute('aria-label', preset.favorite ? 'Remove from favorites' : 'Add to favorites');
      favBtn.innerHTML = preset.favorite ? '<span class="fukiai">&#xEA64;</span>' : '<span class="fukiai">&#xEA65;</span>';
      favBtn.onclick = (e) => {
        e.stopPropagation();
        // Toggle favorite status
        preset.favorite = !preset.favorite;
        favBtn.innerHTML = preset.favorite ? '<span class="fukiai">&#xEA64;</span>' : '<span class="fukiai">&#xEA65;</span>';
        favBtn.setAttribute('aria-label', preset.favorite ? 'Remove from favorites' : 'Add to favorites');
        // Send update to C++ if needed (optional)
        console.log(`⭐ Preset favorite toggled: ${preset.name} = ${preset.favorite}`);
      };
      tdFavorite.appendChild(favBtn);
      tr.appendChild(tdFavorite);

      // Name column
      const tdName = document.createElement('td');
      tdName.textContent = preset.name;
      tr.appendChild(tdName);

      // Category column with colored bullet
      const tdCategory = document.createElement('td');
      const category = preset.category || 'General';
      const categoryClass = category.toLowerCase();
      tdCategory.innerHTML = `<span class="category-bullet ${categoryClass}">${category}</span>`;
      tr.appendChild(tdCategory);

      // Author column
      const tdAuthor = document.createElement('td');
      tdAuthor.textContent = preset.author || 'User';
      tr.appendChild(tdAuthor);

      // Version column
      const tdVersion = document.createElement('td');
      tdVersion.textContent = preset.version || '0.0.1';
      tdVersion.style.color = 'rgba(255, 255, 255, 0.6)';
      tr.appendChild(tdVersion);

      // Menu column with dropdown
      const tdMenu = document.createElement('td');
      tdMenu.style.textAlign = 'center';
      tdMenu.innerHTML = `<button class="pv-menu-btn" title="Preset menu"><span class="fukiai">&#xEA4D;</span></button>`;
      const menuBtn = tdMenu.querySelector('.pv-menu-btn');
      menuBtn.onclick = (e) => {
        e.stopPropagation();
        this.showPresetMenu(e, preset, presetIndex);
      };
      tr.appendChild(tdMenu);

      // Click to load preset
      tr.onclick = () => {
        console.log(`🖱️ Table row clicked! Preset: ${preset.name}, Index: ${presetIndex}`);
        this.currentIndex = presetIndex;
        this.updateDisplay();
        this.renderPresetTable();  // Re-render to update .current class

        // Load preset from file
        const filename = preset.filename;
        console.log(`📂 Loading preset from file: ${filename}`);
        if (typeof window.presetLoadFromFile === 'function') {
          window.presetLoadFromFile(filename);
        } else {
          console.error('❌ presetLoadFromFile function not available!');
        }
      };

      tbody.appendChild(tr);
    });

    console.log(`✓ Rendered ${filteredPresets.length} preset(s) in table`);
  }

  // Show preset menu dropdown with Edit, Delete, Duplicate options
  showPresetMenu(event, preset, presetIndex) {
    const btn = event.target.closest('.pv-menu-btn');
    if (!btn) return;

    // Get or create preset menu portal
    let portal = document.getElementById('pv-menu-portal');
    if (!portal) {
      portal = document.createElement('div');
      portal.id = 'pv-menu-portal';
      portal.className = 'dropdown-portal pv-menu-portal';
      portal.setAttribute('aria-hidden', 'true');
      portal.innerHTML = '<div class="dropdown-menu" role="menu"></div>';
      document.body.appendChild(portal);
    }

    const menu = portal.querySelector('.dropdown-menu');
    menu.innerHTML = '';

    // Edit option
    const editBtn = document.createElement('button');
    editBtn.type = 'button';
    editBtn.className = 'dropdown-item';

    const editIcon = document.createElement('span');
    editIcon.className = 'fukiai dropdown-item-icon';
    editIcon.textContent = '\uEACB';
    editBtn.appendChild(editIcon);

    const editLabel = document.createElement('span');
    editLabel.className = 'dropdown-item-label';
    editLabel.textContent = 'Edit';
    editBtn.appendChild(editLabel);

    editBtn.addEventListener('click', (e) => {
      e.preventDefault();
      this._closePresetMenu();
      this._showEditPresetModal(preset, presetIndex);
    });
    menu.appendChild(editBtn);

    // Duplicate option
    const duplicateBtn = document.createElement('button');
    duplicateBtn.type = 'button';
    duplicateBtn.className = 'dropdown-item';

    const duplicateIcon = document.createElement('span');
    duplicateIcon.className = 'fukiai dropdown-item-icon';
    duplicateIcon.textContent = '\uEA32';
    duplicateBtn.appendChild(duplicateIcon);

    const duplicateLabel = document.createElement('span');
    duplicateLabel.className = 'dropdown-item-label';
    duplicateLabel.textContent = 'Duplicate';
    duplicateBtn.appendChild(duplicateLabel);

    duplicateBtn.addEventListener('click', (e) => {
      e.preventDefault();
      this._closePresetMenu();
      this._showDuplicatePresetModal(preset, presetIndex);
    });
    menu.appendChild(duplicateBtn);

    // Separator
    const separator = document.createElement('hr');
    separator.className = 'dropdown-divider';
    menu.appendChild(separator);

    // Delete option
    const deleteBtn = document.createElement('button');
    deleteBtn.type = 'button';
    deleteBtn.className = 'dropdown-item pv-menu-item-danger';

    const deleteIcon = document.createElement('span');
    deleteIcon.className = 'fukiai dropdown-item-icon';
    deleteIcon.textContent = '\uEAC1';
    deleteBtn.appendChild(deleteIcon);

    const deleteLabel = document.createElement('span');
    deleteLabel.className = 'dropdown-item-label';
    deleteLabel.textContent = 'Delete';
    deleteBtn.appendChild(deleteLabel);

    deleteBtn.addEventListener('click', (e) => {
      e.preventDefault();
      this._closePresetMenu();
      this._confirmDeletePreset(preset, presetIndex);
    });
    menu.appendChild(deleteBtn);

    // Position and open menu using requestAnimationFrame for proper measurements
    const rect = btn.getBoundingClientRect();
    const viewportPadding = 8;

    // Reset position before measuring
    menu.style.left = '0px';
    menu.style.top = '0px';

    portal.setAttribute('data-open', 'true');
    portal.setAttribute('aria-hidden', 'false');

    requestAnimationFrame(() => {
      const menuRect = menu.getBoundingClientRect();

      // Position to the left of button or right-aligned with button
      let left = rect.left;
      if (left + menuRect.width > window.innerWidth - viewportPadding) {
        left = window.innerWidth - menuRect.width - viewportPadding;
      }
      if (left < viewportPadding) left = viewportPadding;

      // Position below button or above if not enough space
      let top = rect.bottom + 6;
      if (top + menuRect.height > window.innerHeight - viewportPadding) {
        top = rect.top - menuRect.height - 6;
      }
      if (top < viewportPadding) top = viewportPadding;

      menu.style.left = `${left}px`;
      menu.style.top = `${top}px`;
    });

    // Close menu when clicking outside
    const closeHandler = (e) => {
      if (!portal.contains(e.target) && !btn.contains(e.target)) {
        this._closePresetMenu();
        document.removeEventListener('click', closeHandler);
      }
    };
    setTimeout(() => {
      document.addEventListener('click', closeHandler);
    }, 10);
  }

  // Close preset menu portal
  _closePresetMenu() {
    const portal = document.getElementById('pv-menu-portal');
    if (portal) {
      portal.setAttribute('data-open', 'false');
      portal.setAttribute('aria-hidden', 'true');
    }
  }

  // Show edit preset modal
  _showEditPresetModal(preset, presetIndex) {
    const overlay = document.createElement('div');
    overlay.className = 'app-modal-overlay';
    overlay.style.zIndex = '9998';

    const modal = document.createElement('div');
    modal.className = 'app-modal';
    modal.style.zIndex = '9999';
    modal.style.maxWidth = '480px';

    const header = document.createElement('div');
    header.className = 'app-modal-header';

    const title = document.createElement('div');
    title.className = 'app-modal-title';
    title.textContent = 'Edit Preset';
    header.appendChild(title);

    const closeBtn = document.createElement('button');
    closeBtn.className = 'app-modal-close';
    closeBtn.textContent = '✕';
    closeBtn.type = 'button';
    closeBtn.onclick = () => {
      overlay.remove();
      modal.remove();
    };
    header.appendChild(closeBtn);

    const content = document.createElement('div');
    content.className = 'app-modal-content';
    content.style.display = 'flex';
    content.style.flexDirection = 'column';
    content.style.gap = '12px';

    // Helper function to create field
    const createField = (label, inputType = 'input') => {
      const field = document.createElement('div');
      field.style.display = 'flex';
      field.style.flexDirection = 'column';
      field.style.gap = '6px';

      const lbl = document.createElement('label');
      lbl.style.fontSize = '12px';
      lbl.style.color = 'rgba(255, 255, 255, 0.6)';
      lbl.style.textTransform = 'uppercase';
      lbl.style.letterSpacing = '0.05em';
      lbl.style.fontWeight = '600';
      lbl.textContent = label;
      field.appendChild(lbl);

      let input;
      if (inputType === 'select') {
        input = document.createElement('select');
        ['Lead', 'Bass', 'Pad', 'Pluck', 'Synth', 'FX', 'User'].forEach(cat => {
          const opt = document.createElement('option');
          opt.value = cat;
          opt.textContent = cat;
          input.appendChild(opt);
        });
      } else if (inputType === 'textarea') {
        input = document.createElement('textarea');
        input.style.minHeight = '80px';
        input.style.resize = 'vertical';
      } else {
        input = document.createElement('input');
        input.type = 'text';
      }

      input.style.padding = '8px 12px';
      input.style.border = '1px solid rgba(255, 255, 255, 0.15)';
      input.style.borderRadius = '6px';
      input.style.backgroundColor = 'rgba(0, 0, 0, 0.3)';
      input.style.color = 'rgba(255, 255, 255, 0.9)';
      input.style.fontSize = '13px';
      input.style.fontFamily = 'inherit';
      input.style.transition = 'border-color 0.2s ease, background-color 0.2s ease';

      input.addEventListener('focus', () => {
        input.style.borderColor = 'rgba(255, 193, 7, 0.5)';
        input.style.backgroundColor = 'rgba(0, 0, 0, 0.5)';
      });

      input.addEventListener('blur', () => {
        input.style.borderColor = 'rgba(255, 255, 255, 0.15)';
        input.style.backgroundColor = 'rgba(0, 0, 0, 0.3)';
      });

      field.appendChild(input);
      return { field, input };
    };

    const { field: nameField, input: nameInput } = createField('Name');
    nameInput.value = preset.name || '';
    content.appendChild(nameField);

    const { field: authorField, input: authorInput } = createField('Author');
    authorInput.value = preset.author || 'User';
    content.appendChild(authorField);

    const { field: categoryField, input: categorySelect } = createField('Category', 'select');
    categorySelect.value = preset.category || 'User';
    content.appendChild(categoryField);

    const { field: descField, input: descInput } = createField('Description', 'textarea');
    descInput.value = preset.description || '';
    content.appendChild(descField);

    const footer = document.createElement('div');
    footer.className = 'app-modal-footer';

    const cancelBtn = document.createElement('button');
    cancelBtn.textContent = 'Cancel';
    cancelBtn.type = 'button';
    cancelBtn.style.padding = '8px 16px';
    cancelBtn.style.border = '1px solid #555';
    cancelBtn.style.borderRadius = '4px';
    cancelBtn.style.backgroundColor = '#333';
    cancelBtn.style.color = '#fff';
    cancelBtn.style.cursor = 'pointer';
    cancelBtn.onclick = () => {
      overlay.remove();
      modal.remove();
    };
    footer.appendChild(cancelBtn);

    const saveBtn = document.createElement('button');
    saveBtn.textContent = 'Save';
    saveBtn.type = 'button';
    saveBtn.style.padding = '8px 16px';
    saveBtn.style.border = '1px solid #ffc107';
    saveBtn.style.borderRadius = '4px';
    saveBtn.style.backgroundColor = 'rgba(255, 193, 7, 0.3)';
    saveBtn.style.color = '#ffc107';
    saveBtn.style.cursor = 'pointer';
    saveBtn.style.fontWeight = 'bold';
    saveBtn.onclick = () => {
      const updatedPreset = {
        ...preset,
        name: nameInput.value || 'Untitled',
        author: authorInput.value || 'User',
        category: categorySelect.value,
        description: descInput.value
      };
      this._updatePresetMetadata(preset, updatedPreset, presetIndex);
      overlay.remove();
      modal.remove();
    };
    footer.appendChild(saveBtn);

    modal.appendChild(header);
    modal.appendChild(content);
    modal.appendChild(footer);

    document.body.appendChild(overlay);
    document.body.appendChild(modal);

    // Show with animation
    requestAnimationFrame(() => {
      overlay.classList.add('active');
      modal.classList.add('active');
    });

    nameInput.focus();
  }

  // Update preset metadata and save to file
  _updatePresetMetadata(oldPreset, newPreset, presetIndex) {
    // Update in memory
    Object.assign(this.presets[presetIndex], newPreset);

    // If name changed, need to handle file rename
    if (oldPreset.name !== newPreset.name) {
      console.log(`🔄 Renaming preset: ${oldPreset.name} → ${newPreset.name}`);
      // Send update request to C++
      window.webkit.messageHandlers.callback.postMessage({
        msg: 'SCMFUI',
        ctrlTag: 'PRESET_UPDATE',
        oldFilename: oldPreset.filename,
        newFilename: newPreset.name.replace(/[^a-zA-Z0-9_\-]/g, '_') + '.json',
        data: JSON.stringify(newPreset)
      });
    } else {
      // Only metadata changed, just update existing file
      window.webkit.messageHandlers.callback.postMessage({
        msg: 'SCMFUI',
        ctrlTag: 'PRESET_UPDATE',
        filename: oldPreset.filename,
        data: JSON.stringify(newPreset)
      });
    }

    this.renderPresetTable();
    console.log(`✓ Preset metadata updated`);
  }

  // Confirm and delete preset
  _confirmDeletePreset(preset, presetIndex) {
    const overlay = document.createElement('div');
    overlay.className = 'app-modal-overlay';
    overlay.style.zIndex = '9998';

    const modal = document.createElement('div');
    modal.className = 'app-modal';
    modal.style.zIndex = '9999';
    modal.style.setProperty('--tint-rgb', '240,240,240');
    modal.style.maxWidth = '400px';

    const header = document.createElement('div');
    header.className = 'app-modal-header';

    const title = document.createElement('div');
    title.className = 'app-modal-title';
    title.textContent = 'Delete Preset?';
    header.appendChild(title);

    const closeBtn = document.createElement('button');
    closeBtn.className = 'app-modal-close';
    closeBtn.textContent = '✕';
    closeBtn.type = 'button';
    closeBtn.onclick = () => {
      overlay.remove();
      modal.remove();
    };
    header.appendChild(closeBtn);

    const content = document.createElement('div');
    content.className = 'app-modal-content';
    content.style.color = '#ccc';
    content.innerHTML = `Are you sure you want to delete <strong>${preset.name}</strong>? This action cannot be undone.`;

    const footer = document.createElement('div');
    footer.className = 'app-modal-footer';
    footer.style.display = 'flex';
    footer.style.gap = '8px';
    footer.style.justifyContent = 'flex-end';

    const cancelBtn = document.createElement('button');
    cancelBtn.textContent = 'Cancel';
    cancelBtn.type = 'button';
    cancelBtn.style.padding = '8px 16px';
    cancelBtn.style.border = '1px solid #555';
    cancelBtn.style.borderRadius = '4px';
    cancelBtn.style.backgroundColor = '#333';
    cancelBtn.style.color = '#fff';
    cancelBtn.style.cursor = 'pointer';
    cancelBtn.onclick = () => {
      overlay.remove();
      modal.remove();
    };
    footer.appendChild(cancelBtn);

    const deleteBtn = document.createElement('button');
    deleteBtn.textContent = 'Delete';
    deleteBtn.type = 'button';
    deleteBtn.style.padding = '8px 16px';
    deleteBtn.style.border = 'none';
    deleteBtn.style.borderRadius = '4px';
    deleteBtn.style.backgroundColor = '#d32f2f';
    deleteBtn.style.color = '#fff';
    deleteBtn.style.cursor = 'pointer';
    deleteBtn.style.fontWeight = 'bold';
    deleteBtn.onclick = () => {
      this._deletePresetFile(preset, presetIndex);
      overlay.remove();
      modal.remove();
    };
    footer.appendChild(deleteBtn);

    modal.appendChild(header);
    modal.appendChild(content);
    modal.appendChild(footer);

    document.body.appendChild(overlay);
    document.body.appendChild(modal);

    // Show with animation
    requestAnimationFrame(() => {
      overlay.classList.add('active');
      modal.classList.add('active');
    });
  }

  // Delete preset file
  _deletePresetFile(preset, presetIndex) {
    console.log(`🗑 Deleting preset: ${preset.name}`);

    // Send delete request to C++
    window.webkit.messageHandlers.callback.postMessage({
      msg: 'SCMFUI',
      ctrlTag: 'PRESET_DELETE',
      filename: preset.filename
    });

    // Remove from memory
    this.presets.splice(presetIndex, 1);

    // Update current index if needed
    if (this.currentIndex >= this.presets.length) {
      this.currentIndex = Math.max(0, this.presets.length - 1);
    }

    this.updateDisplay();
    this.renderPresetTable();
    console.log(`✓ Preset deleted`);
  }

  // Show duplicate preset modal
  _showDuplicatePresetModal(preset, presetIndex) {
    const overlay = document.createElement('div');
    overlay.className = 'app-modal-overlay';
    overlay.style.zIndex = '9998';

    const modal = document.createElement('div');
    modal.className = 'app-modal';
    modal.style.zIndex = '9999';
    modal.style.setProperty('--tint-rgb', '240,240,240');
    modal.style.maxWidth = '440px';

    const header = document.createElement('div');
    header.className = 'app-modal-header';

    const title = document.createElement('div');
    title.className = 'app-modal-title';
    title.textContent = 'Duplicate Preset';
    header.appendChild(title);

    const closeBtn = document.createElement('button');
    closeBtn.className = 'app-modal-close';
    closeBtn.textContent = '✕';
    closeBtn.type = 'button';
    closeBtn.onclick = () => {
      overlay.remove();
      modal.remove();
    };
    header.appendChild(closeBtn);

    const content = document.createElement('div');
    content.className = 'app-modal-content';
    content.style.display = 'flex';
    content.style.flexDirection = 'column';
    content.style.gap = '12px';

    // New name field
    const nameLabel = document.createElement('label');
    nameLabel.style.display = 'flex';
    nameLabel.style.flexDirection = 'column';
    nameLabel.style.gap = '4px';
    nameLabel.style.fontSize = '0.9em';
    nameLabel.style.color = '#999';
    nameLabel.textContent = 'New Preset Name';
    const nameInput = document.createElement('input');
    nameInput.type = 'text';
    nameInput.value = preset.name + ' (Copy)';
    nameInput.style.padding = '8px';
    nameInput.style.border = '1px solid #555';
    nameInput.style.borderRadius = '4px';
    nameInput.style.backgroundColor = '#222';
    nameInput.style.color = '#fff';
    nameLabel.appendChild(nameInput);
    content.appendChild(nameLabel);

    const footer = document.createElement('div');
    footer.className = 'app-modal-footer';
    footer.style.display = 'flex';
    footer.style.gap = '8px';
    footer.style.justifyContent = 'flex-end';

    const cancelBtn = document.createElement('button');
    cancelBtn.textContent = 'Cancel';
    cancelBtn.type = 'button';
    cancelBtn.style.padding = '8px 16px';
    cancelBtn.style.border = '1px solid #555';
    cancelBtn.style.borderRadius = '4px';
    cancelBtn.style.backgroundColor = '#333';
    cancelBtn.style.color = '#fff';
    cancelBtn.style.cursor = 'pointer';
    cancelBtn.onclick = () => {
      overlay.remove();
      modal.remove();
    };
    footer.appendChild(cancelBtn);

    const duplicateBtn = document.createElement('button');
    duplicateBtn.textContent = 'Duplicate';
    duplicateBtn.type = 'button';
    duplicateBtn.style.padding = '8px 16px';
    duplicateBtn.style.border = 'none';
    duplicateBtn.style.borderRadius = '4px';
    duplicateBtn.style.backgroundColor = 'rgb(var(--tint-rgb))';
    duplicateBtn.style.color = '#000';
    duplicateBtn.style.cursor = 'pointer';
    duplicateBtn.style.fontWeight = 'bold';
    duplicateBtn.onclick = () => {
      const newName = nameInput.value || 'Untitled Copy';
      this._duplicatePreset(preset, newName);
      overlay.remove();
      modal.remove();
    };
    footer.appendChild(duplicateBtn);

    modal.appendChild(header);
    modal.appendChild(content);
    modal.appendChild(footer);

    document.body.appendChild(overlay);
    document.body.appendChild(modal);

    // Show with animation
    requestAnimationFrame(() => {
      overlay.classList.add('active');
      modal.classList.add('active');
    });

    nameInput.focus();
    nameInput.select();
  }

  // Duplicate preset by creating a copy with new name
  _duplicatePreset(sourcePreset, newName) {
    console.log(`⧨ Duplicating preset: ${sourcePreset.name} → ${newName}`);

    const newPreset = {
      ...sourcePreset,
      id: `preset-${Date.now()}`,
      name: newName,
      filename: newName.replace(/[^a-zA-Z0-9_\-]/g, '_') + '.json'
    };

    // Send to C++ to save new file
    window.webkit.messageHandlers.callback.postMessage({
      msg: 'SCMFUI',
      ctrlTag: 'PRESET_SAVE',
      filename: newPreset.filename,
      data: JSON.stringify(newPreset)
    });

    // Add to presets list
    this.presets.push(newPreset);
    this.currentIndex = this.presets.length - 1;

    this.updateDisplay();
    this.renderPresetTable();
    console.log(`✓ Preset duplicated as: ${newName}`);
  }

  // Request preset list from C++ on startup
  requestPresetList() {
    console.log('📋 requestPresetList() called - requesting preset list from C++');
    if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.callback) {
      window.webkit.messageHandlers.callback.postMessage({
        msg: 'SCMFUI',
        ctrlTag: 'PRESET_LIST'
      });
      console.log('📋 PRESET_LIST request sent via webkit');
    } else {
      console.error('❌ webkit bridge not available for preset list request');
    }
  }
}
window.presetManager = new PresetManager();

// Helper function to show error balloon
function showErrorBalloon(title, message) {
  const errorBalloon = document.getElementById('error-balloon');
  const errorTitle = document.getElementById('error-balloon-title');
  const errorMessage = document.getElementById('error-balloon-message');

  if (errorBalloon && errorTitle && errorMessage) {
    errorTitle.textContent = title;
    errorMessage.textContent = message;
    errorBalloon.classList.remove('hidden');
    console.error(`❌ ERROR: ${title} - ${message}`);
  }
}

// Show warning balloon for preset compatibility issues
function showBalloonWarning(title, message) {
  const warningBalloon = document.getElementById('warning-balloon');
  const warningTitle = document.getElementById('warning-balloon-title');
  const warningMessage = document.getElementById('warning-balloon-message');

  if (warningBalloon && warningTitle && warningMessage) {
    warningTitle.textContent = title;
    warningMessage.textContent = message;
    warningBalloon.classList.remove('hidden');
    console.warn(`⚠️  WARNING: ${title} - ${message}`);
  }
}

// Reset all parameters to 0 when Init.json fails to load
function resetAllParametersToZero() {
  // Reset all input range elements to 0
  document.querySelectorAll('input[type="range"]').forEach(input => {
    input.value = '0';
    // Trigger change event to update display values
    input.dispatchEvent(new Event('input', { bubbles: true }));
    // Update range progress indicators
    setRangeProgress(input);
  });

  // Reset all select elements to 0
  document.querySelectorAll('select').forEach(select => {
    select.value = '0';
    select.dispatchEvent(new Event('change', { bubbles: true }));
  });

  console.log('🔄 All parameters reset to 0');
}

// Helper function to hide error balloon
function hideErrorBalloon() {
  const errorBalloon = document.getElementById('error-balloon');
  if (errorBalloon) {
    errorBalloon.classList.add('hidden');
  }
}

// Auto-load Init preset on startup (wait for C++ bridge to be ready)
function waitForBridgeAndLoadInit() {
  const spvfuiReady = typeof window.SPVFUI === 'function';
  const presetMgrReady = !!window.presetManager;

  if (spvfuiReady && presetMgrReady) {
    // Request wavetable list FIRST (before loading Init.json)
    // This ensures user wavetables are available when applyPreset() runs
    if (typeof window.wavetableListRequest === 'function') {
      window.wavetableListRequest();
    }

    // Load Init.json after a short delay to allow wavetable list to be processed
    if (typeof window.presetLoadFromFile === 'function') {
      setTimeout(() => {
        // Mark that we're loading Init so error handler knows if this is the startup load
        window.__loadingInitOnStartup = true;
        window.presetLoadFromFile('Init');  // Note: C++ adds .awaon extension

        // Also request the full preset list so all presets are available in the viewer
        setTimeout(() => {
          if (window.presetManager && typeof window.presetManager.requestPresetList === 'function') {
            console.log('📋 Requesting preset list for viewer...');
            window.presetManager.requestPresetList();
          }
        }, 500);
      }, 100);
    } else {
      console.error('Init Load Failed: presetLoadFromFile() bridge not available');
      showErrorBalloon('Init Load Failed', 'presetLoadFromFile() bridge not available');
    }
  } else {
    // Retry after 50ms if bridge not ready
    setTimeout(waitForBridgeAndLoadInit, 50);
  }
}
setTimeout(waitForBridgeAndLoadInit, 100);

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// PARAMETER ID MAPPING (matches namespace Param in IPlugWebUI.h)
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
const PARAM_NAMES = [
  // Oscillator 1 (0-4)
  'osc1_wave', 'osc1_semi', 'osc1_fine', 'osc1_level', 'osc1_sync',
  // Oscillator 2 (5-9)
  'osc2_wave', 'osc2_semi', 'osc2_fine', 'osc2_level', 'osc2_detune',
  // Noise (10-12)
  'noise_type', 'noise_level', 'noise_variant',
  // Filter 1 (13-16)
  'flt1_type', 'flt1_cutoff', 'flt1_reso', 'flt1_drive',
  // Filter 2 (17-20)
  'flt2_type', 'flt2_cutoff', 'flt2_reso', 'flt2_drive',
  // Filter Routing (21-22)
  'flt_routing', 'flt_mix',
  // Envelope 1 (23-28)
  'env1_attack', 'env1_decay', 'env1_sustain', 'env1_release', 'env1_curve', 'env1_level',
  // Envelope 2 (29-34)
  'env2_attack', 'env2_decay', 'env2_sustain', 'env2_release', 'env2_curve', 'env2_level',
  // LFO 1 (35-39)
  'lfo1_wave', 'lfo1_rate', 'lfo1_shape', 'lfo1_depth', 'lfo1_sync',
  // LFO 2 (40-44)
  'lfo2_wave', 'lfo2_rate', 'lfo2_shape', 'lfo2_depth', 'lfo2_sync',
  // Effects (45-54)
  'delay_time', 'delay_feedback', 'delay_mix', 'delay_sync',
  'chorus_rate', 'chorus_depth', 'chorus_mix',
  'reverb_size', 'reverb_damp', 'reverb_mix',
  // Master/Global (55-63, 61 repurposed for LFO1 tempo div)
  'master', 'portamento', 'tune', 'voices', 'voicing', 'bend', 'lfo1_tempo_div', 'octave', 'semitone',
  // OSC Wavetable Blend (64-69)
  'osc1_amount', 'osc1_bank', 'osc1_compound', 'osc2_amount', 'osc2_bank', 'osc2_compound',
  // Modal Filter (70-73)
  'modal_type', 'modal_tone', 'modal_reso', 'modal_mix',
  // LFO Delays (74-75)
  'lfo1_delay', 'lfo2_delay',
  // Filter Dry/Wet Mix (76-77)
  'flt1_mix', 'flt2_mix',
  // OSC Wavetable Phase Offset (78-81)
  'osc1_offset_a', 'osc1_offset_b', 'osc2_offset_a', 'osc2_offset_b',
  // OSC Clip Mode (82-83)
  'osc1_clip', 'osc2_clip',
  // Transient Oscillator (84-88, 87 repurposed for LFO2 tempo div)
  'trans_mode', 'trans_decay', 'trans_timbre', 'lfo2_tempo_div', 'trans_level',
  // Signals Section (89-91)
  'sig_clip', 'sig_drive', 'sig_tone',
  // Master Pan (92)
  'master_pan',
  // Unison Detune (93)
  'unison_detune',
  // Filter Slope (94)
  'filter_slope',
  // Filter 2 Slope (95)
  'filter2_slope'
];

// Global storage for all parameter values (normalized 0-1, indexed by paramIdx)
window.__parameterValues = {};

// Convert parameters from index→value to name→value format
function indexedParamsToNamed(indexedParams) {
  const namedParams = {};
  for (let i = 0; i < PARAM_NAMES.length; i++) {
    if (indexedParams[i] !== undefined) {
      namedParams[PARAM_NAMES[i]] = indexedParams[i];
    }
  }
  return namedParams;
}

// Convert parameters from name→value to index→value format (for preset loading)
function namedParamsToIndexed(namedParams) {
  const indexedParams = {};
  for (let i = 0; i < PARAM_NAMES.length; i++) {
    const paramName = PARAM_NAMES[i];
    if (namedParams[paramName] !== undefined) {
      indexedParams[i] = namedParams[paramName];
    }
  }
  return indexedParams;
}

// TEMPORARY: Helper function to dump current state as Init preset
window.dumpCurrentAsInit = function () {
  // Get current wavetable names (simplified)
  const getWavetableName = (bank, index) => {
    if (!bank || !bank[index]) return 'Sine';
    return bank[index].name || 'Sine';
  };

  // Convert indexed parameters to named format
  const namedParams = indexedParamsToNamed(window.__parameterValues);

  // Create preset data with ALL parameters and simplified wavetable info
  const initPreset = {
    version: APP_VERSION,  // Use current app version
    id: 0,
    name: 'Init',
    category: 'Lead',
    author: 'Factory',
    description: 'Default initialization preset',
    parameters: namedParams,  // Named parameter IDs → values (0-1 normalized)
    wavetables: {
      osc1A: getWavetableName(wavetablesOsc1A, window.osc1Showcase ? window.osc1Showcase.banks.A : 0),
      osc1B: getWavetableName(wavetablesOsc1B, window.osc1Showcase ? window.osc1Showcase.banks.B : 0),
      osc2A: getWavetableName(wavetablesOsc2A, window.osc2Showcase ? window.osc2Showcase.banks.A : 0),
      osc2B: getWavetableName(wavetablesOsc2B, window.osc2Showcase ? window.osc2Showcase.banks.B : 0)
    },
    matrix: __matrixRoutes.map(route => ({
      source: route.source,
      destination: route.destination,
      amount: route.amount / 100  // Convert 0-100 to 0-1
    }))
  };

  console.log('=== COPY THIS AS INIT PRESET ===');
  console.log(JSON.stringify(initPreset, null, 2));
  console.log('=== END INIT PRESET ===');
  console.log('Parameter count:', Object.keys(namedParams).length);
  console.log('Indexed count:', Object.keys(window.__parameterValues).length);
  return initPreset;
};

// Effects Controls
// Delay Time (logarithmic)
const delayTimeSlider = document.getElementById('delay-time');
const delayTimeVal = document.getElementById('delay-time-val');
if (delayTimeSlider) {
  delayTimeSlider.addEventListener('input', (e) => {
    const sliderValue = parseInt(e.target.value) / 100;
    const ms = logScale(sliderValue, 10, 2000);
    delayTimeVal.innerHTML = Math.round(ms) + '<span class="unit">ms</span>';
    sendParam(Params.DELAY_TIME, sliderValue);
    const fb = (delayFeedbackSlider ? parseInt(delayFeedbackSlider.value) / 100 : 0.3);
    const mixEl = document.getElementById('delay-mix');
    const mix = mixEl ? parseInt(mixEl.value) / 100 : 0.2;
    const canvas = document.getElementById('delay-graph'); if (canvas) drawDelayGraph(canvas, sliderValue, fb, mix, THEME_COLORS.effects);
  });
}

// Delay Feedback
const delayFeedbackSlider = document.getElementById('delay-feedback');
const delayFeedbackVal = document.getElementById('delay-feedback-val');
if (delayFeedbackSlider) {
  delayFeedbackSlider.addEventListener('input', (e) => {
    const value = parseInt(e.target.value);
    delayFeedbackVal.innerHTML = `${value}<span class=\"unit\">%</span>`;
    sendParam(Params.DELAY_FEEDBACK, value / 100);
    const timeNorm = (delayTimeSlider ? parseInt(delayTimeSlider.value) / 100 : 0.25);
    const mixEl = document.getElementById('delay-mix');
    const mix = mixEl ? parseInt(mixEl.value) / 100 : 0.2;
    const canvas = document.getElementById('delay-graph'); if (canvas) drawDelayGraph(canvas, timeNorm, value / 100, mix, THEME_COLORS.effects);
  });
}

// Delay Mix
const delayMixSlider = document.getElementById('delay-mix');
const delayMixVal = document.getElementById('delay-mix-val');
if (delayMixSlider) {
  delayMixSlider.addEventListener('input', (e) => {
    const value = parseInt(e.target.value);  // -100 to +100 (bipolar slider)
    const pct = value;  // Already the display value
    const sign = pct >= 0 ? '+' : '';
    delayMixVal.innerHTML = `${sign}${pct}<span class=\"unit\">%</span>`;
    const bipolar = value / 100;  // -100 to +100 → -1.0 to +1.0
    const normalized = (bipolar + 1.0) / 2.0;  // -1.0 to +1.0 → 0 to 1
    sendParam(Params.DELAY_MIX, normalized);
    // Redraw delay graph reflecting new MIX opacity
    const timeEl = document.getElementById('delay-time');
    const fbEl = document.getElementById('delay-feedback');
    const t = timeEl ? parseInt(timeEl.value) / 100 : 0.25;
    const f = fbEl ? parseInt(fbEl.value) / 100 : 0.3;
    const canvas = document.getElementById('delay-graph');
    if (canvas) drawDelayGraph(canvas, t, f, normalized, THEME_COLORS.effects);
  });
}

// Chorus Rate (logarithmic)
const chorusRateSlider = document.getElementById('chorus-rate');
const chorusRateVal = document.getElementById('chorus-rate-val');
if (chorusRateSlider) {
  chorusRateSlider.addEventListener('input', (e) => {
    const sliderValue = parseInt(e.target.value) / 100;
    const hz = logScale(sliderValue, 0.1, 10);
    chorusRateVal.innerHTML = hz.toFixed(1) + '<span class=\"unit\">Hz</span>';
    sendParam(Params.CHORUS_RATE, sliderValue);
    const depth = (chorusDepthSlider ? parseInt(chorusDepthSlider.value) / 100 : 0.5);
    const mixEl = document.getElementById('chorus-mix');
    const mix = mixEl ? parseInt(mixEl.value) / 100 : 0.3;
    const canvas = document.getElementById('chorus-graph'); if (canvas) drawChorusGraph(canvas, sliderValue, depth, mix, THEME_COLORS.effects);
  });
}

// Chorus Depth
const chorusDepthSlider = document.getElementById('chorus-depth');
const chorusDepthVal = document.getElementById('chorus-depth-val');
if (chorusDepthSlider) {
  chorusDepthSlider.addEventListener('input', (e) => {
    const value = parseInt(e.target.value);
    chorusDepthVal.innerHTML = `${value}<span class=\"unit\">%</span>`;
    sendParam(Params.CHORUS_DEPTH, value / 100);
    const rate = (chorusRateSlider ? parseInt(chorusRateSlider.value) / 100 : 0.2);
    const mixEl = document.getElementById('chorus-mix');
    const mix = mixEl ? parseInt(mixEl.value) / 100 : 0.3;
    const canvas = document.getElementById('chorus-graph'); if (canvas) drawChorusGraph(canvas, rate, value / 100, mix, THEME_COLORS.effects);
  });
}

// Chorus Mix
const chorusMixSlider = document.getElementById('chorus-mix');
const chorusMixVal = document.getElementById('chorus-mix-val');
if (chorusMixSlider) {
  chorusMixSlider.addEventListener('input', (e) => {
    const value = parseInt(e.target.value);  // -100 to +100 (bipolar slider)
    const pct = value;  // Already the display value
    const sign = pct >= 0 ? '+' : '';
    chorusMixVal.innerHTML = `${sign}${pct}<span class=\"unit\">%</span>`;
    const bipolar = value / 100;  // -100 to +100 → -1.0 to +1.0
    const normalized = (bipolar + 1.0) / 2.0;  // -1.0 to +1.0 → 0 to 1
    sendParam(Params.CHORUS_MIX, normalized);
    const rate = (chorusRateSlider ? parseInt(chorusRateSlider.value) / 100 : 0.2);
    const depth = (chorusDepthSlider ? parseInt(chorusDepthSlider.value) / 100 : 0.5);
    const canvas = document.getElementById('chorus-graph'); if (canvas) drawChorusGraph(canvas, rate, depth, normalized, THEME_COLORS.effects);
  });
}

// Reverb Room Size
const reverbSizeSlider = document.getElementById('reverb-size');
const reverbSizeVal = document.getElementById('reverb-size-val');
if (reverbSizeSlider) {
  reverbSizeSlider.addEventListener('input', (e) => {
    const value = parseInt(e.target.value);
    reverbSizeVal.innerHTML = `${value}<span class=\"unit\">%</span>`;
    sendParam(Params.REVERB_SIZE, value / 100);
    const mix = (reverbMixSlider ? parseInt(reverbMixSlider.value) / 100 : 0.25);
    const damp = (reverbDampSlider ? parseInt(reverbDampSlider.value) / 100 : 0.4);
    const canvas = document.getElementById('reverb-graph'); if (canvas) drawReverbGraph(canvas, value / 100, damp, mix, THEME_COLORS.effects);
  });
}

// Reverb Damping
const reverbDampSlider = document.getElementById('reverb-damp');
const reverbDampVal = document.getElementById('reverb-damp-val');
if (reverbDampSlider) {
  reverbDampSlider.addEventListener('input', (e) => {
    const value = parseInt(e.target.value);
    reverbDampVal.innerHTML = `${value}<span class=\"unit\">%</span>`;
    sendParam(Params.REVERB_DAMP, value / 100);
    const size = (reverbSizeSlider ? parseInt(reverbSizeSlider.value) / 100 : 0.5);
    const mix = (reverbMixSlider ? parseInt(reverbMixSlider.value) / 100 : 0.25);
    const canvas = document.getElementById('reverb-graph'); if (canvas) drawReverbGraph(canvas, size, value / 100, mix, THEME_COLORS.effects);
  });
}

// Reverb Mix
const reverbMixSlider = document.getElementById('reverb-mix');
const reverbMixVal = document.getElementById('reverb-mix-val');
if (reverbMixSlider) {
  reverbMixSlider.addEventListener('input', (e) => {
    const value = parseInt(e.target.value);  // -100 to +100 (bipolar slider)
    const pct = value;  // Already the display value
    const sign = pct >= 0 ? '+' : '';
    reverbMixVal.innerHTML = `${sign}${pct}<span class=\"unit\">%</span>`;
    const bipolar = value / 100;  // -100 to +100 → -1.0 to +1.0
    const normalized = (bipolar + 1.0) / 2.0;  // -1.0 to +1.0 → 0 to 1
    sendParam(Params.REVERB_MIX, normalized);
    const size = (reverbSizeSlider ? parseInt(reverbSizeSlider.value) / 100 : 0.5);
    const damp = (reverbDampSlider ? parseInt(reverbDampSlider.value) / 100 : 0.4);
    const canvas = document.getElementById('reverb-graph'); if (canvas) drawReverbGraph(canvas, size, damp, normalized, THEME_COLORS.effects);
  });
}

// ============================================================================
// VIRTUAL KEYBOARD - MIDI Input
// ============================================================================

// Send MIDI message to C++ plugin
function sendMidi(status, data1, data2) {
  try {
    if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.callback) {
      window.webkit.messageHandlers.callback.postMessage({
        msg: 'SMMFUI',
        statusByte: status,
        dataByte1: data1,
        dataByte2: data2
      });
      console.log(`MIDI: ${status.toString(16)} ${data1} ${data2}`);
    } else {
      console.warn('WebKit message handler not available');
    }
  } catch (e) {
    console.error('sendMidi failed:', e);
  }
}

// MIDI Note On/Off helpers
function noteOn(noteNumber, velocity = 100) {
  sendMidi(0x90, noteNumber, velocity); // 0x90 = Note On, channel 1
  if (window.pulseMidiIndicator) window.pulseMidiIndicator();
}

function noteOff(noteNumber) {
  sendMidi(0x80, noteNumber, 0); // 0x80 = Note Off, channel 1
  if (window.pulseMidiIndicator) window.pulseMidiIndicator();
}

// Track active notes (for visual feedback and avoiding double note-offs)
const activeNotes = new Set();
var keyToNote = new Map();

// Virtual keyboard mouse/touch events (delegated + refreshable)
var keyboard = getKeyboardContainer();
if (keyboard) {
  // Global mouse up to catch releases outside keys
  document.addEventListener('mouseup', () => {
    activeNotes.forEach(note => {
      const key = keyboard.querySelector(`[data-note="${note}"]`);
      if (key) key.classList.remove('active');
      noteOff(note);
    });
    activeNotes.clear();
  });
}

// Computer keyboard mapping
function refreshKeyToNote() {
  keyToNote = new Map();
  if (!keyboard) keyboard = getKeyboardContainer();
  if (!keyboard) return;
  const keys = keyboard.querySelectorAll('.key');
  keys.forEach(key => {
    const noteNumber = parseInt(key.getAttribute('data-note'));
    const keyChar = key.getAttribute('data-key');
    if (keyChar) keyToNote.set(keyChar.toLowerCase(), { note: noteNumber, element: key });
  });
}

// Track keys currently pressed (to prevent key repeat)
const pressedKeys = new Set();

if (KEYBOARD) {
  // Computer keyboard events (debug only)
  document.addEventListener('keydown', (e) => {
    const key = e.key.toLowerCase();

    // Ignore if key is already pressed (key repeat)
    if (pressedKeys.has(key)) return;

    // Ignore if typing in an input field
    if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;

    const mapping = keyToNote.get(key);
    if (mapping) {
      e.preventDefault();
      pressedKeys.add(key);

      if (!activeNotes.has(mapping.note)) {
        activeNotes.add(mapping.note);
        mapping.element.classList.add('active');
        noteOn(mapping.note, 100);
      }
    }
  });

  document.addEventListener('keyup', (e) => {
    const key = e.key.toLowerCase();
    pressedKeys.delete(key);

    const mapping = keyToNote.get(key);
    if (mapping) {
      e.preventDefault();

      if (activeNotes.has(mapping.note)) {
        activeNotes.delete(mapping.note);
        mapping.element.classList.remove('active');
        noteOff(mapping.note);
      }
    }
  });
}

// Panic button - all notes off (useful for debugging)
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    console.log('PANIC: All notes off');
    activeNotes.forEach(note => {
      noteOff(note);
      const key = keyboard?.querySelector(`[data-note="${note}"]`);
      if (key) key.classList.remove('active');
    });
    activeNotes.clear();
    pressedKeys.clear();
  }
});

// ============================================================================
// MODULATION MATRIX - React-style implementation
// ============================================================================

const MOD_SOURCES = [
  { label: 'Velocity', icon: '\uEAC0', isAC: false },        // velocity
  { label: 'Envelope 1', icon: '\uEA12', isAC: true },       // function_env_adsr_exp
  { label: 'Envelope 2', icon: '\uEA12', isAC: true },       // function_env_adsr_exp
  { label: 'LFO 1', icon: '\uEAC7', isAC: true },            // lfo
  { label: 'LFO 2', icon: '\uEAC7', isAC: true },            // lfo
  { label: 'Key Follow', icon: '\uEACC', isAC: false },      // key follow
  { label: 'Pressure', icon: '\uEB09', isAC: false },        // pressure
  { label: 'Side Chain', icon: '\uEA26', isAC: false, hidden: true }, // removed from UI
  { label: 'Pitch Bend', icon: '\uEB04', isAC: false },      // bend
  { label: 'Modulation Wheel', icon: '\uEAE6', isAC: false }, // mod wheel
  { label: 'Constant', icon: '\uEA70', isAC: false },        // constant
  { label: 'Random Per Note', icon: '', isAC: false },       // random
  { label: 'Random Per Voice', icon: '', isAC: false }       // random
];

// Bipolar destinations that inherently accept negative modulation (from C++ code analysis)
// These should always use bipolar amount sliders (-100% to +100%)
const BIPOLAR_DESTINATIONS = new Set([
  1,   // OSC 1 → Pitch (±12 semitones)
  3,   // OSC 1 → Fine Pitch (±1 semitone)
  5,   // OSC 2 → Pitch (±12 semitones)
  7,   // OSC 2 → Fine Pitch (±1 semitone)
  11,  // Filter 1 → Cutoff (±48 semitones)
  12,  // Filter 1 → Resonance (±0.5)
  13,  // Filter 2 → Cutoff (±48 semitones)
  14,  // Filter 2 → Resonance (±0.5)
  15,  // LFO 1 → Rate (±10 Hz)
  16,  // LFO 1 → Depth (±1.0)
  17,  // LFO 2 → Rate (±10 Hz)
  18   // LFO 2 → Depth (±1.0)
]);

// Modulation Destinations (matches C++ Voice::process() switch cases)
// IMPORTANT: Array index MUST match C++ case number exactly!
// Index 0 = None, Indices 1-20 correspond to C++ cases 1-20
const MOD_DESTINATIONS = [
  // Index 0: None
  'None',

  // Index 1-4: OSC 1 (Implemented: cases 1-3)
  'OSC 1 → Pitch',           // case 1: ±12 semitones ✅
  'OSC 1 → Level',           // case 2: amplitude modulation ✅
  'OSC 1 → Fine Pitch',      // case 3: ±1 semitone ✅
  '(OSC 1 → Phase)',         // case 4: NOT IMPLEMENTED ❌

  // Index 5-9: OSC 2 (Implemented: cases 5-7)
  'OSC 2 → Pitch',           // case 5: ±12 semitones ✅
  'OSC 2 → Level',           // case 6: amplitude modulation ✅
  'OSC 2 → Fine Pitch',      // case 7: ±1 semitone ✅
  '(OSC 2 → Phase)',         // case 8: NOT IMPLEMENTED ❌
  '(OSC 2 → Detune)',        // case 9: NOT IMPLEMENTED ❌

  // Index 10: Noise
  'Noise → Level',           // case 10: ✅ Implemented

  // Index 11-12: Filter 1 (Implemented: cases 11-12)
  'Filter 1 → Cutoff',       // case 11: ±48 semitones (4 octaves) ✅
  'Filter 1 → Resonance',    // case 12: ±0.5 (additive) ✅

  // Index 13-14: Filter 2 (Implemented: cases 13-14)
  'Filter 2 → Cutoff',       // case 13: ±48 semitones ✅
  'Filter 2 → Resonance',    // case 14: ±0.5 (additive) ✅

  // Index 15-16: LFO 1
  '(LFO 1 → Rate)',          // case 15: ❌ NOT WORKING (LFO processed before matrix evaluation!)
  'LFO 1 → Depth',           // case 16: ✅ Implemented (⚠️ LFO 1→LFO 1 forbidden, cross-mod only)

  // Index 17-18: LFO 2
  '(LFO 2 → Rate)',          // case 17: ❌ NOT WORKING (LFO processed before matrix evaluation!)
  'LFO 2 → Depth',           // case 18: ✅ Implemented (⚠️ LFO 2→LFO 2 forbidden, cross-mod only)

  // Index 19: Volume (VCA - Voice Amplitude)
  'Volume',                  // case 19: ✅ Master amplitude control (replaces hardcoded env1)

  // Index 20: Filter 1 Mix
  'Filter 1 → Mix',          // case 20: 0-100% dry/wet

  // Index 21: Filter 2 Mix
  'Filter 2 → Mix',          // case 21: 0-100% dry/wet

  // Index 22-24: Modal Filter
  'Modal → Tone',            // case 22: Formant position/tone
  'Modal → Resonance',       // case 23: Resonance amount
  'Modal → Mix',             // case 24: 0-100% dry/wet

  // Index 25-26: Delay
  'Delay → Time',            // case 25: Delay time modulation
  'Delay → Feedback',        // case 26: Feedback amount

  // Index 27-28: Chorus
  'Chorus → Rate',           // case 27: LFO rate modulation
  'Chorus → Depth',          // case 28: Modulation depth

  // Index 29-30: Reverb
  'Reverb → Size',           // case 29: Room size
  'Reverb → Damping',        // case 30: High frequency damping

  // Index 31-32: OSC Wavetable Blend
  'OSC 1 → Amount',          // case 31: Wavetable A/B crossfade
  'OSC 2 → Amount',          // case 32: Wavetable A/B crossfade

  // Index 33-36: OSC Wavetable Offsets
  'OSC 1 → Offset A',        // case 33: Wavetable A position
  'OSC 1 → Offset B',        // case 34: Wavetable B position
  'OSC 2 → Offset A',        // case 35: Wavetable A position
  'OSC 2 → Offset B',        // case 36: Wavetable B position

  // Index 37-39: Transient Oscillator
  'Transient → Decay',       // case 37: Decay time
  'Transient → Timbre',      // case 38: Tone/color
  'Transient → Level',       // case 39: Output level

  // Index 40: Noise Generator
  'Noise → Variant',         // case 40: Color/variant parameter

  // Index 41-42: Signals (Mixer Section)
  'Drive → Amount',          // case 41: Saturation drive
  'Tone → Tilt',             // case 42: Tilt EQ

  // Index 43: Master
  'Portamento → Time',       // case 43: Glide time per-note modulation

  // Index 44-51: Enum/Toggle Modulation (discrete values)
  'OSC 1 → Compound Mode',   // case 44: 0=Fade, 1=Phase, 2=Multiply, 3=Mask
  'OSC 2 → Compound Mode',   // case 45: 0=Fade, 1=Phase, 2=Multiply, 3=Mask
  'Noise → Type',            // case 46: 0=Analog, 1=Digital, 2=Arcade
  'Transient → Mode',        // case 47: 0=Modal, 1=Karplus, 2=Kick, 3=Snare, 4=HiHat, 5=Zap
  'Filter 1 → Type',         // case 48: 0=LP, 1=HP, 2=BP, 3=Notch, 4=Transistor, 5=Acid
  'Filter 2 → Type',         // case 49: 0=LP, 1=HP, 2=BP, 3=Notch, 4=Transistor, 5=Acid
  'LFO 1 → Waveform',        // case 50: 0=Sine, 1=Tri, 2=Saw, 3=Square, 4=S&H, 5=Noise
  'LFO 2 → Waveform',        // case 51: 0=Sine, 1=Tri, 2=Saw, 3=Square, 4=S&H, 5=Noise

  // Index 52: Master Pitch
  'Master → Pitch'           // case 52: ±12 semitones (all 4 OSCs simultaneously)
];

const MATRIX_SOURCE_THEMES = [
  'master', // VELOCITY
  'env',    // ENVELOPE 1
  'env',    // ENVELOPE 2
  'lfo',    // LFO 1
  'lfo',    // LFO 2
  'master', // KEY FOLLOW
  'master', // PRESSURE
  'master', // SIDE CHAIN
  'master', // BEND
  'master', // WHEEL
  'master', // CONSTANT
  'master', // RANDOM PER NOTE
  'master'  // RANDOM PER VOICE
];

const MATRIX_DESTINATION_THEMES = [
  'master', // None
  'osc1', 'osc1', 'osc1', 'osc1', // OSC 1
  'osc2', 'osc2', 'osc2', 'osc2', 'osc2', // OSC 2
  'noise', // Noise
  'vcf', 'vcf', // Filter 1
  'vcf', 'vcf', // Filter 2
  'lfo', 'lfo', // LFO 1
  'lfo', 'lfo', // LFO 2
  'master', // Volume
  'vcf', 'vcf', // Filter Mix
  'resonator', 'resonator', 'resonator', // Modal
  'effects', 'effects', // Delay
  'effects', 'effects', // Chorus
  'effects', 'effects', // Reverb
  'osc1', 'osc2', // Wavetable Amount
  'osc1', 'osc1', 'osc2', 'osc2', // Wavetable Offsets
  'transient', 'transient', 'transient', // Transient
  'noise', // Noise Variant
  'master', 'master', // Signals
  'master', // Portamento
  'osc1', 'osc2', // OSC Compound Mode
  'noise', // Noise Type
  'transient', // Transient Mode
  'vcf', 'vcf', // Filter Type
  'lfo', 'lfo' // LFO Waveform
];

function getMatrixSourceTheme(index) {
  return MATRIX_SOURCE_THEMES[index] || 'master';
}

function getMatrixDestinationTheme(index) {
  return MATRIX_DESTINATION_THEMES[index] || 'master';
}

// Icon mapping for each destination index (based on section)
const MATRIX_DESTINATION_CHILD_ICONS = {
  0: '\uEAA3',  // None
  2: '\uEA6D',  // OSC 1 Level
  3: '\uEAA7',  // OSC 1 Fine Pitch
  6: '\uEA6D',  // OSC 2 Level
  7: '\uEAA7',  // OSC 2 Fine Pitch
  10: '\uEA6D', // Noise Level
  11: '\uEA9D', // Filter 1 Cutoff
  12: '\uEA9E', // Filter 1 Resonance
  13: '\uEA9D', // Filter 2 Cutoff
  14: '\uEA9E', // Filter 2 Resonance
  16: '\uEACF', // LFO 1 Depth
  18: '\uEACF', // LFO 2 Depth
  19: '\uEAF3', // Volume
  20: '\uEA11', // Filter 1 Mix
  21: '\uEA11', // Filter 2 Mix
  22: '\uEA47', // Resonator Tone
  25: '\uEA42', // Delay Time
  26: '\uEAE2', // Delay Feedback
  27: '\uEA8E', // Chorus Rate
  28: '\uEACF', // Chorus Depth
  29: '\uEA95', // Reverb Size
  30: '\uEACF', // Reverb Damping
  37: '\uEA19', // Transient Decay
  38: '\uEA47', // Transient Timbre
  39: '\uEA6D', // Transient Level
  42: '\uEA47'  // Signals Tone
};

function getMatrixDestinationChildIcon(index) {
  return MATRIX_DESTINATION_CHILD_ICONS[index] || '';
}

// Hierarchical menu structure for destinations with separators
// Maps to flat MOD_DESTINATIONS indices - CRITICAL: indices must match exactly!
const MOD_DESTINATIONS_HIERARCHY = [
  { label: 'None', index: 0, icon: '\uEAA3' },

  { type: 'separator' },

  // OSC 1 (includes wavetable controls)
  {
    label: 'OSC 1',
    icon: '\uEAED',  // Fukiai icon: osc
    children: [
      { label: 'Pitch', index: 1, implemented: true },
      { label: 'Level', index: 2, implemented: true },
      { label: 'Fine Pitch', index: 3, implemented: true },
      { label: 'Wavetable Amount', index: 31, implemented: true },
      { label: 'Wavetable Offset A', index: 33, implemented: true },
      { label: 'Wavetable Offset B', index: 34, implemented: true },
      { label: 'Compound Mode', index: 44, implemented: true }
    ]
  },

  // OSC 2 (includes wavetable controls)
  {
    label: 'OSC 2',
    icon: '\uEAED',  // Fukiai icon: osc
    children: [
      { label: 'Pitch', index: 5, implemented: true },
      { label: 'Level', index: 6, implemented: true },
      { label: 'Fine Pitch', index: 7, implemented: true },
      { label: 'Wavetable Amount', index: 32, implemented: true },
      { label: 'Wavetable Offset A', index: 35, implemented: true },
      { label: 'Wavetable Offset B', index: 36, implemented: true },
      { label: 'Compound Mode', index: 45, implemented: true }
    ]
  },

  // Transient
  {
    label: 'Transient',
    icon: '\uEAC3',  // Fukiai icon: transient
    children: [
      { label: 'Decay', index: 37, implemented: true },
      { label: 'Timbre', index: 38, implemented: true },
      { label: 'Level', index: 39, implemented: true },
      { label: 'Mode', index: 47, implemented: true }
    ]
  },

  // Noise
  {
    label: 'Noise',
    icon: '\uEA7A',  // Fukiai icon: noise
    children: [
      { label: 'Level', index: 10, implemented: true },
      { label: 'Variant', index: 40, implemented: true },
      { label: 'Type', index: 46, implemented: true }
    ]
  },

  { type: 'separator' },

  // Filter 1
  {
    label: 'Filter 1',
    icon: '\uEA9D',  // Fukiai icon: filter
    children: [
      { label: 'Cutoff', index: 11, implemented: true },
      { label: 'Resonance', index: 12, implemented: true },
      { label: 'Mix', index: 20, implemented: true },
      { label: 'Type', index: 48, implemented: true }
    ]
  },

  // Filter 2
  {
    label: 'Filter 2',
    icon: '\uEA9D',  // Fukiai icon: filter
    children: [
      { label: 'Cutoff', index: 13, implemented: true },
      { label: 'Resonance', index: 14, implemented: true },
      { label: 'Mix', index: 21, implemented: true },
      { label: 'Type', index: 49, implemented: true }
    ]
  },

  // Resonator (renamed from Modal)
  {
    label: 'Resonator',
    icon: '\uEAEE',  // resonator
    children: [
      { label: 'Tone', index: 22, implemented: true },
      { label: 'Resonance', index: 23, implemented: true },
      { label: 'Mix', index: 24, implemented: true }
    ]
  },

  { type: 'separator' },

  // LFO 1
  {
    label: 'LFO 1',
    icon: '\uEAC7',  // lfo
    children: [
      { label: 'Depth', index: 16, implemented: true },
      { label: 'Waveform', index: 50, implemented: true }
    ]
  },

  // LFO 2
  {
    label: 'LFO 2',
    icon: '\uEAC7',  // lfo
    children: [
      { label: 'Depth', index: 18, implemented: true },
      { label: 'Waveform', index: 51, implemented: true }
    ]
  },

  { type: 'separator' },

  // Signals
  {
    label: 'Signals',
    icon: '\uEA40',  // signals
    children: [
      { label: 'Drive', index: 41, implemented: true },
      { label: 'Tone', index: 42, implemented: true }
    ]
  },

  // Volume (VCA - Voice Amplitude)
  { label: 'Volume', icon: '\uEAF3', index: 19, implemented: true },  // volume

  { type: 'separator' },

  // Delay
  {
    label: 'Delay',
    icon: '\uEAB5',  // Fukiai icon: delay
    children: [
      { label: 'Time', index: 25, implemented: true },
      { label: 'Feedback', index: 26, implemented: true }
    ]
  },

  // Chorus
  {
    label: 'Chorus',
    icon: '\uEA20',  // Fukiai icon: chorus
    children: [
      { label: 'Rate', index: 27, implemented: true },
      { label: 'Depth', index: 28, implemented: true }
    ]
  },

  // Reverb
  {
    label: 'Reverb',
    icon: '\uEAB6',  // Fukiai icon: reverb
    children: [
      { label: 'Size', index: 29, implemented: true },
      { label: 'Damping', index: 30, implemented: true }
    ]
  },

  { type: 'separator' },

  // Master
  {
    label: 'Master',
    icon: '\uEA71',  // master
    children: [
      { label: 'Pitch', index: 52, implemented: true },
      { label: 'Portamento', index: 43, implemented: true }
    ]
  }
];

const MATRIX_DESTINATION_PARENT_ICON_BY_INDEX = {};
MOD_DESTINATIONS_HIERARCHY.forEach((item) => {
  if (item.type) return;
  if (Array.isArray(item.children)) {
    item.children.forEach((child) => {
      if (typeof child.index === 'number') {
        MATRIX_DESTINATION_PARENT_ICON_BY_INDEX[child.index] = item.icon || '';
      }
    });
  } else if (typeof item.index === 'number') {
    MATRIX_DESTINATION_PARENT_ICON_BY_INDEX[item.index] = item.icon || '';
  }
});

function getMatrixDestinationParentIcon(index) {
  return MATRIX_DESTINATION_PARENT_ICON_BY_INDEX[index] || '';
}

const MOD_SOURCES_HIERARCHY = [
  { label: 'Constant', icon: '\uEA70', index: 10 },
  { type: 'separator' },
  { label: 'Env 1', index: 1 },
  { label: 'Env 2', index: 2 },
  { label: 'LFO 1', index: 3 },
  { label: 'LFO 2', index: 4 },
  { type: 'separator' },
  { label: 'Velocity', index: 0 },
  { label: 'Key Follow', index: 5 },
  { label: 'Pressure', index: 6 },
  { label: 'Pitch Bend', index: 8 },
  { label: 'Modulation Wheel', index: 9 },
  { type: 'separator' },
  {
    label: 'Random',
    icon: '',
    children: [
      { label: 'Random Per Note', index: 11 },
      { label: 'Random Per Voice', index: 12 }
    ]
  }
];

// Dynamic modulation matrix state
const MAX_MATRIX_SLOTS = 16;
let __matrixRoutes = []; // Empty - will be populated from Init.json

// Send matrix configuration to C++ plugin as JSON (only active rows)
function sendMatrixConfig() {
  const matrixConfig = { slots: [] };

  // IMPORTANT: Update __matrixRoutes from DOM before sending to C++
  // This ensures __matrixRoutes is in sync for preset saving
  for (let slotIdx = 0; slotIdx < __matrixRoutes.length; slotIdx++) {
    const row = document.getElementById(`matrix-row-${slotIdx}`);
    const isSleep = row?.classList.contains('is-sleep') ?? false;

    const sourceSelect = document.getElementById(`matrix-source-${slotIdx}`);
    const destSelect = document.getElementById(`matrix-dest-${slotIdx}`);
    const amountSlider = document.getElementById(`matrix-amount-${slotIdx}`);
    if (!sourceSelect || !destSelect || !amountSlider) continue;

    const source = parseInt(sourceSelect.value);
    const destination = parseInt(destSelect.value);
    const amount = parseInt(amountSlider.value);

    // Update __matrixRoutes to keep it in sync with UI (including sleep state for presets)
    __matrixRoutes[slotIdx] = {
      source: source,
      slot: slotIdx,
      destination: destination,
      amount: amount,  // Store as 0-100 (not normalized)
      isSleep: isSleep  // Store sleep state for preset save/load
    };

    // Send slot if destination is selected AND not sleeping
    // Sleeping rows are skipped (temporarily disabled)
    if (destination > 0 && !isSleep) {
      matrixConfig.slots.push({
        source,
        slot: slotIdx,
        destination,
        amount: amount / 100.0  // Normalize to 0-1 for C++
      });
    }
  }

  const jsonStr = JSON.stringify(matrixConfig);

  // Send via webkit messageHandlers (like wavetable does)
  try {
    if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.callback) {
      window.webkit.messageHandlers.callback.postMessage({
        msg: 'SCMFUI',
        ctrlTag: 'MATRIX_CONFIG',
        data: jsonStr
      });
    } else {
      console.error('WebKit message handlers not available');
    }
  } catch (e) {
    console.error('Failed to send matrix config:', e);
  }
}

function updateAddMatrixBtnState() {
  const btn = document.getElementById('add-matrix-btn');
  if (!btn) return;
  const headerControl = btn.closest('.header-control');
  const disabled = __matrixRoutes.length >= MAX_MATRIX_SLOTS;
  btn.disabled = disabled;
  btn.setAttribute('aria-disabled', disabled ? 'true' : 'false');
  if (headerControl) {
    if (disabled) headerControl.setAttribute('disabled', '');
    else headerControl.removeAttribute('disabled');
  }
}

function addMatrixRoute() {
  if (__matrixRoutes.length >= MAX_MATRIX_SLOTS) return;
  const slotIndex = __matrixRoutes.length;  // Auto-increment slot index
  __matrixRoutes.push({ source: 10, slot: slotIndex, destination: 0, amount: 50 });  // Default 50% amount
  renderModMatrix();
  sendMatrixConfig();
}

function removeMatrixRoute(idx) {
  if (idx < 0 || idx >= __matrixRoutes.length) return;
  __matrixRoutes.splice(idx, 1);
  renderModMatrix();
  sendMatrixConfig();
}

// Render routes to DOM
function renderModMatrix() {
  updateAddMatrixBtnState();
  const container = document.getElementById('mod-matrix');
  if (!container) return;
  container.innerHTML = '';
  for (let slotIdx = 0; slotIdx < __matrixRoutes.length; slotIdx++) {
    const slotRow = createMatrixSlot(slotIdx, __matrixRoutes[slotIdx]);
    container.appendChild(slotRow);
  }
  updateAddMatrixBtnState();
  // Bind dropdown triggers for newly created matrix slots
  setupDropdownTriggers();
}

// Initialize dynamic modulation matrix
function initModMatrix() {
  const addBtn = document.getElementById('add-matrix-btn');
  if (addBtn && !addBtn.__wired) {
    addBtn.addEventListener('click', addMatrixRoute);
    addBtn.__wired = true;
  }
  // Matrix starts completely empty - no default routing
  renderModMatrix();
  sendMatrixConfig();  // Send initial matrix config to C++ plugin
}

function createMatrixSlot(slotIdx, route) {
  const row = document.createElement('div');
  row.className = 'matrix-slot-row';
  row.id = `matrix-row-${slotIdx}`;  // Add ID for sleep detection

  const labelBtn = document.createElement('button');
  labelBtn.className = 'matrix-slot-label-btn';
  labelBtn.type = 'button';
  labelBtn.setAttribute('aria-pressed', 'false');
  labelBtn.setAttribute('aria-label', 'Sleep modulation row');

  const labelNum = document.createElement('span');
  labelNum.className = 'matrix-slot-label-number';
  labelNum.textContent = String(slotIdx + 1);

  const labelIcon = document.createElement('span');
  labelIcon.className = 'fukiai matrix-slot-label-icon';
  labelIcon.textContent = '\uEAE7';

  labelBtn.appendChild(labelNum);
  labelBtn.appendChild(labelIcon);
  labelBtn.addEventListener('click', () => {
    const isSleep = row.classList.toggle('is-sleep');
    labelBtn.setAttribute('aria-pressed', isSleep ? 'true' : 'false');
  });

  row.appendChild(labelBtn);

  // Source icon display - REMOVED: icons now only in dropdown menu
  // const sourceIcon = document.createElement('span');
  // sourceIcon.className = 'fukiai matrix-source-icon';
  // sourceIcon.id = `matrix-source-icon-${slotIdx}`;
  const initialSource = (route && typeof route.source === 'number') ? route.source : 0;
  const initialDest = (route && typeof route.destination === 'number') ? route.destination : 0;
  const initialAmount = (route && typeof route.amount === 'number') ? route.amount : 0;
  // sourceIcon.textContent = MOD_SOURCES[initialSource].icon;
  // row.appendChild(sourceIcon);

  // Source selector - dropdown button
  const sourceBtn = document.createElement('button');
  sourceBtn.className = 'control-btn is-dropdown matrix-source-btn';
  sourceBtn.type = 'button';
  sourceBtn.setAttribute('data-dropdown-toggle', `matrix-source-${slotIdx}`);
  sourceBtn.setAttribute('aria-haspopup', 'true');
  sourceBtn.setAttribute('aria-expanded', 'false');
  sourceBtn.setAttribute('aria-label', 'Source selector');
  sourceBtn.title = 'Select modulation source';

  // Source icon (inside button)
  const sourceBtnSourceIcon = document.createElement('span');
  sourceBtnSourceIcon.className = 'fukiai matrix-source-btn-icon';
  sourceBtnSourceIcon.id = `matrix-source-btn-icon-${slotIdx}`;
  sourceBtnSourceIcon.textContent = MOD_SOURCES[initialSource].icon;
  sourceBtn.appendChild(sourceBtnSourceIcon);

  const sourceBtnLabel = document.createElement('span');
  sourceBtnLabel.className = 'matrix-dropdown-label';
  sourceBtnLabel.id = `matrix-source-label-${slotIdx}`;
  sourceBtnLabel.textContent = MOD_SOURCES[initialSource].label;
  sourceBtn.appendChild(sourceBtnLabel);

  const sourceBtnIcon = document.createElement('span');
  sourceBtnIcon.className = 'fukiai';
  sourceBtnIcon.textContent = '\uEAD2'; // chevron down
  sourceBtn.appendChild(sourceBtnIcon);

  row.appendChild(sourceBtn);

  // Source selector - hidden native select
  const sourceSelect = document.createElement('select');
  sourceSelect.className = 'matrix-source-select dropdown-native-select';
  sourceSelect.id = `matrix-source-${slotIdx}`;
  sourceSelect.setAttribute('tabindex', '-1');
  sourceSelect.setAttribute('aria-hidden', 'true');
  const initialSourceTheme = getMatrixSourceTheme(initialSource);
  sourceBtn.setAttribute('data-theme', initialSourceTheme);
  sourceSelect.setAttribute('data-theme', initialSourceTheme);

  MOD_SOURCES.forEach((source, i) => {
    if (source.hidden) return;
    const option = document.createElement('option');
    option.value = i;
    option.textContent = source.label;
    option.setAttribute('data-icon', source.icon);
    sourceSelect.appendChild(option);
  });
  sourceSelect.value = String(initialSource);
  row.appendChild(sourceSelect);

  // Arrow icon
  const arrow = document.createElement('span');
  arrow.className = 'matrix-arrow';
  arrow.textContent = '→';
  row.appendChild(arrow);

  // Destination selector - dropdown button
  const destBtn = document.createElement('button');
  destBtn.className = 'control-btn is-dropdown matrix-dest-btn';
  destBtn.type = 'button';
  destBtn.setAttribute('data-dropdown-toggle', `matrix-dest-${slotIdx}`);
  destBtn.setAttribute('aria-haspopup', 'true');
  destBtn.setAttribute('aria-expanded', 'false');
  destBtn.setAttribute('aria-label', 'Destination selector');
  destBtn.title = 'Select modulation destination';

  const destBtnIcon = document.createElement('span');
  destBtnIcon.className = 'fukiai matrix-dest-btn-icon';
  destBtnIcon.id = `matrix-dest-btn-icon-${slotIdx}`;
  destBtnIcon.textContent = getMatrixDestinationParentIcon(initialDest) || ' ';
  destBtn.appendChild(destBtnIcon);

  const destBtnLabel = document.createElement('span');
  destBtnLabel.className = 'matrix-dropdown-label';
  destBtnLabel.id = `matrix-dest-label-${slotIdx}`;
  destBtnLabel.textContent = MOD_DESTINATIONS[initialDest];
  destBtn.appendChild(destBtnLabel);

  const destBtnChevron = document.createElement('span');
  destBtnChevron.className = 'fukiai';
  destBtnChevron.textContent = '\uEAD2'; // chevron down
  destBtn.appendChild(destBtnChevron);

  row.appendChild(destBtn);

  // Destination selector - hidden native select
  const destSelect = document.createElement('select');
  destSelect.className = 'matrix-dest-select dropdown-native-select';
  destSelect.id = `matrix-dest-${slotIdx}`;
  destSelect.setAttribute('tabindex', '-1');
  destSelect.setAttribute('aria-hidden', 'true');
  const initialDestTheme = getMatrixDestinationTheme(initialDest);
  destBtn.setAttribute('data-theme', initialDestTheme);
  destSelect.setAttribute('data-theme', initialDestTheme);
  row.setAttribute('data-source', initialSourceTheme);
  row.setAttribute('data-dest', initialDestTheme);

  // Implemented destinations (verified by code analysis):
  // OSC 1/2: Pitch (1,5), Level (2,6), Fine (3,7) ✅
  // Noise: Level (10), Variant (40) ✅
  // Filter 1/2: Cutoff (11,13), Resonance (12,14), Mix (20,21) ✅
  // Modal: Tone (22), Resonance (23), Mix (24) ✅
  // LFO 1/2: Depth (16,18) ✅ with anti-recursion (1-sample latency)
  // LFO 1/2: Rate NOT working (LFOs processed before matrix evaluation)
  // VCA (19) ✅
  // Effects: Delay (25,26), Chorus (27,28), Reverb (29,30) ✅
  // OSC Wavetable: Amount (31,32), Offsets (33-36) ✅
  // Transient: Decay (37), Timbre (38), Level (39) ✅
  // Signals: Drive (41), Tone (42) ✅
  // Master: Portamento (43) ✅
  // Enum/Toggle: OSC Compound (44,45), Noise Type (46), Transient Mode (47), Filter Type (48,49), LFO Waveform (50,51) ✅
  const implementedDests = new Set([
    1, 2, 3, 5, 6, 7, 10, 11, 12, 13, 14, 16, 18, 19,
    20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30,
    31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43,
    44, 45, 46, 47, 48, 49, 50, 51,
    52  // Master → Pitch
  ]);

  MOD_DESTINATIONS.forEach((dest, i) => {
    const option = document.createElement('option');
    option.value = i;
    option.textContent = dest;

    // Disable unimplemented destinations (marked with parentheses)
    if (i > 0 && !implementedDests.has(i)) {
      option.disabled = true;
      option.style.color = '#666';
      option.style.fontStyle = 'italic';
    }

    destSelect.appendChild(option);
  });
  destSelect.value = String(initialDest);
  row.appendChild(destSelect);

  // Amount slider container
  const amountContainer = document.createElement('div');
  amountContainer.className = 'matrix-amount-container';

  const slider = document.createElement('input');
  slider.type = 'range';
  slider.className = 'matrix-slider';
  slider.id = `matrix-amount-${slotIdx}`;
  slider.min = '0';  // default; will be updated by updateSliderType
  slider.max = '100';
  slider.value = String(initialAmount);

  amountContainer.appendChild(slider);

  // Center detent marker (hidden by default)
  const detentMarker = document.createElement('div');
  detentMarker.className = 'center-detent-marker';
  detentMarker.style.display = 'none';
  amountContainer.appendChild(detentMarker);

  row.appendChild(amountContainer);

  // Value display
  const valueDisplay = document.createElement('div');
  valueDisplay.className = 'matrix-value';
  valueDisplay.id = `matrix-value-${slotIdx}`;
  valueDisplay.textContent = `${initialAmount > 0 ? '+' : ''}${initialAmount}%`;
  row.appendChild(valueDisplay);

  // Remove button
  const removeBtn = document.createElement('button');
  removeBtn.className = 'matrix-remove-btn';
  removeBtn.classList.add('fukiai');
  removeBtn.textContent = '\uEAC1';
  removeBtn.title = 'Remove route';
  removeBtn.addEventListener('click', (e) => {
    e.preventDefault();
    removeMatrixRoute(slotIdx);
  });
  // FIX: Allow deleting all slots (no minimum requirement)
  row.appendChild(removeBtn);

  // Function to update slider based on source type (DC/AC) AND destination bipolarity
  const updateSliderType = () => {
    const sourceIdx = parseInt(sourceSelect.value);
    const destIdx = parseInt(destSelect.value);
    const source = MOD_SOURCES[sourceIdx];
    const isSourceAC = source.isAC; // Bipolar (AC) or Unipolar (DC)
    const isDestBipolar = BIPOLAR_DESTINATIONS.has(destIdx);

    // Slider should be bipolar if EITHER source is AC OR destination is bipolar
    // Examples:
    // - LFO (AC) → Level (unipolar) = bipolar slider (LFO can go ±)
    // - Velocity (DC) → Fine Pitch (bipolar) = bipolar slider (pitch can go ±)
    // - Velocity (DC) → Level (unipolar) = unipolar slider (both unipolar)
    const isBipolar = isSourceAC || isDestBipolar;

    // Update icon in button
    sourceBtnSourceIcon.textContent = source.icon;

    // Update slider range and class
    const currentVal = parseInt(slider.value) || 0;
    if (isBipolar) {
      slider.min = '-100';
      slider.max = '100';
      slider.className = 'matrix-slider bipolar';
      detentMarker.style.display = 'block';
    } else {
      slider.min = '0';
      slider.max = '100';
      slider.className = 'matrix-slider';
      detentMarker.style.display = 'none';
    }
    // Clamp to new range and reflect
    const min = parseInt(slider.min);
    const max = parseInt(slider.max);
    const clamped = Math.max(min, Math.min(max, currentVal));
    slider.value = String(clamped);
    valueDisplay.textContent = `${clamped > 0 ? '+' : ''}${clamped}%`;
    // Update progress indicators when slider type changes
    setRangeProgress(slider);
    const sourceTheme = getMatrixSourceTheme(sourceIdx);
    const destTheme = getMatrixDestinationTheme(destIdx);
    sourceBtn.setAttribute('data-theme', sourceTheme);
    sourceSelect.setAttribute('data-theme', sourceTheme);
    destBtn.setAttribute('data-theme', destTheme);
    destSelect.setAttribute('data-theme', destTheme);
    destBtnIcon.textContent = getMatrixDestinationParentIcon(destIdx) || ' ';
    row.setAttribute('data-source', sourceTheme);
    row.setAttribute('data-dest', destTheme);
  };

  // Event listeners
  slider.addEventListener('input', (e) => {
    const value = parseInt(e.target.value);
    const sourceIdx = parseInt(sourceSelect.value);
    const destIdx = parseInt(destSelect.value);
    const isSourceAC = MOD_SOURCES[sourceIdx].isAC;
    const isDestBipolar = BIPOLAR_DESTINATIONS.has(destIdx);
    const isBipolar = isSourceAC || isDestBipolar;
    valueDisplay.textContent = (isBipolar && value > 0 ? '+' : '') + value + '%';
    __matrixRoutes[slotIdx].amount = value;
    // Update progress indicators for range slider
    setRangeProgress(slider);
    sendMatrixConfig();
  });

  sourceSelect.addEventListener('change', () => {
    const sourceIdx = parseInt(sourceSelect.value);
    __matrixRoutes[slotIdx].source = sourceIdx;
    // Update button label
    sourceBtnLabel.textContent = MOD_SOURCES[sourceIdx].label;
    updateSliderType();
    sendMatrixConfig();
  });

  destSelect.addEventListener('change', () => {
    const destIdx = parseInt(destSelect.value);
    __matrixRoutes[slotIdx].destination = destIdx;
    // Update button label
    destBtnLabel.textContent = MOD_DESTINATIONS[destIdx];
    destBtnIcon.textContent = getMatrixDestinationParentIcon(destIdx) || ' ';
    updateSliderType(); // Update slider bipolarity based on new destination
    sendMatrixConfig();
  });

  // Ensure slider mode matches initial source
  updateSliderType();

  // Initialize progress indicators for the slider
  setRangeProgress(slider);

  return row;
}

// Helper to set a matrix slot programmatically
function setMatrixSlot(slotIdx, source, dest, amount) {
  const sourceSelect = document.getElementById(`matrix-source-${slotIdx}`);
  const destSelect = document.getElementById(`matrix-dest-${slotIdx}`);
  const amountSlider = document.getElementById(`matrix-amount-${slotIdx}`);
  const valueDisplay = document.getElementById(`matrix-value-${slotIdx}`);
  const sourceBtnLabel = document.getElementById(`matrix-source-label-${slotIdx}`);
  const destBtnLabel = document.getElementById(`matrix-dest-label-${slotIdx}`);
  const row = sourceSelect?.closest('.matrix-slot-row');
  const sourceBtn = row?.querySelector('.matrix-source-btn');
  const destBtn = row?.querySelector('.matrix-dest-btn');
  const destBtnIcon = row?.querySelector('.matrix-dest-btn-icon');

  if (sourceSelect && destSelect && amountSlider && valueDisplay) {
    sourceSelect.value = source;
    destSelect.value = dest;
    amountSlider.value = amount;

    // Check if slider should be bipolar (same logic as updateSliderType)
    const isSourceAC = MOD_SOURCES[source]?.isAC || false;
    const isDestBipolar = BIPOLAR_DESTINATIONS.has(dest);
    const isBipolar = isSourceAC || isDestBipolar;
    valueDisplay.textContent = (isBipolar && amount > 0 ? '+' : '') + amount + '%';

    // Update button labels
    if (sourceBtnLabel) sourceBtnLabel.textContent = MOD_SOURCES[source].label;
    if (destBtnLabel) destBtnLabel.textContent = MOD_DESTINATIONS[dest];

    const sourceTheme = getMatrixSourceTheme(source);
    const destTheme = getMatrixDestinationTheme(dest);
    if (sourceBtn) sourceBtn.setAttribute('data-theme', sourceTheme);
    if (sourceSelect) sourceSelect.setAttribute('data-theme', sourceTheme);
    if (destBtn) destBtn.setAttribute('data-theme', destTheme);
    if (destSelect) destSelect.setAttribute('data-theme', destTheme);
    if (destBtnIcon) destBtnIcon.textContent = getMatrixDestinationParentIcon(dest) || ' ';
    if (row) {
      row.setAttribute('data-source', sourceTheme);
      row.setAttribute('data-dest', destTheme);
    }
  }
}

// Position black keys responsively between white keys
function layoutKeyboard() {
  const kb = getKeyboardContainer();
  if (!kb) return;
  const children = Array.from(kb.children);
  children.forEach((el, idx) => {
    if (!el.classList.contains('black')) return;
    // find previous white
    let prevWhite = null;
    for (let i = idx - 1; i >= 0; i--) {
      if (children[i].classList.contains('white')) { prevWhite = children[i]; break; }
    }
    // find next white
    let nextWhite = null;
    for (let i = idx + 1; i < children.length; i++) {
      if (children[i].classList.contains('white')) { nextWhite = children[i]; break; }
    }
    if (!prevWhite || !nextWhite) return;

  });
}

function updateOctaveButtons() {
  const buttons = document.querySelectorAll('.keyboard-octave-btn');
  if (!buttons.length) return;
  const minOffset = 0 - KEYBOARD_MIN_NOTE;
  const maxOffset = KEYBOARD_MAX_ABS_NOTE - KEYBOARD_MAX_NOTE;
  buttons.forEach((btn) => {
    const dir = btn.getAttribute('data-dir');
    if (dir === 'down') {
      btn.disabled = keyboardOctaveOffset <= minOffset;
    } else if (dir === 'up') {
      btn.disabled = keyboardOctaveOffset >= maxOffset;
    }
  });
}

function setupKeyboardOctaveControls() {
  const buttons = document.querySelectorAll('.keyboard-octave-btn');
  if (!buttons.length) return;
  buttons.forEach((btn) => {
    btn.addEventListener('click', () => {
      const dir = btn.getAttribute('data-dir');
      if (dir === 'down') {
        keyboardOctaveOffset -= KEYBOARD_STEP;
      } else if (dir === 'up') {
        keyboardOctaveOffset += KEYBOARD_STEP;
      }
      buildKeyboard();
      layoutKeyboard();
    });
  });
  updateOctaveButtons();
}

function setupKeyboardWheelIndicators() {
  const attachWheelHandler = (wheel, indicator, bipolar) => {
    if (!wheel || !indicator) return;
    const clamp = (v, min, max) => Math.max(min, Math.min(max, v));
    let value = bipolar ? 0 : 0;
    const updateIndicator = () => {
      const pct = bipolar ? ((value + 1) * 0.5) * 90 + 5 : value * 90 + 5;
      indicator.style.bottom = `${clamp(pct, 0, 100)}%`;
    };
    const handlePointer = (clientY) => {
      const rect = wheel.getBoundingClientRect();
      const rel = clamp(1 - ((clientY - rect.top) / rect.height), 0, 1);
      value = bipolar ? (rel * 2 - 1) : rel;
      updateIndicator();
    };
    const startDrag = (startEvent) => {
      startEvent.preventDefault();
      const move = (e) => handlePointer(e.clientY);
      const up = () => {
        document.removeEventListener('mousemove', move);
        document.removeEventListener('mouseup', up);
        if (bipolar) {
          value = 0;
          updateIndicator();
        }
      };
      document.addEventListener('mousemove', move);
      document.addEventListener('mouseup', up);
      handlePointer(startEvent.clientY);
    };
    wheel.addEventListener('mousedown', startDrag);
    updateIndicator();
  };
  const bendWheel = document.querySelector('.keyboard-wheel-bend');
  const bendIndicator = bendWheel?.querySelector('.keyboard-wheel-indicator-bend');
  const modWheel = document.querySelector('.keyboard-wheel-mod');
  const modIndicator = modWheel?.querySelector('.keyboard-wheel-indicator-mod');
  attachWheelHandler(bendWheel, bendIndicator, true);
  attachWheelHandler(modWheel, modIndicator, false);
}

function setupKeyboardDock() {
  const panel = document.querySelector('.panel.keyboard');
  const toggleBtns = document.querySelectorAll('.toggle-keyboard');
  if (!panel || !toggleBtns.length) return;
  toggleBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      panel.classList.toggle('hidden');
      const isOpen = !panel.classList.contains('hidden');
      document.body.classList.toggle('keyboard-open', isOpen);
      if (isOpen) {
        // just opened: ensure keyboard layout is correct
        requestAnimationFrame(layoutKeyboard);
      }
    });
  });
}

// Initialize matrix when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initModMatrix);
} else {
  initModMatrix();
}

// ============================================================================
// Wavetable Catalog/Grid Picker
// ============================================================================

// Reusable app modal
class AppModal {
  constructor({ title = '', themeColor = '255,255,255', width, maxWidth, closeOnOverlay = true, onClose } = {}) {
    this.onClose = onClose;
    this.themeColor = themeColor;
    // overlay
    this.overlay = document.createElement('div');
    this.overlay.className = 'app-modal-overlay';
    if (closeOnOverlay) this.overlay.addEventListener('click', () => this.close());
    // modal
    this.modal = document.createElement('div');
    this.modal.className = 'app-modal';
    if (width) this.modal.style.width = width;
    if (maxWidth) this.modal.style.maxWidth = maxWidth;
    this.modal.style.setProperty('--tint-rgb', themeColor);
    // header
    this.header = document.createElement('div');
    this.header.className = 'app-modal-header';
    this.titleEl = document.createElement('div');
    this.titleEl.className = 'app-modal-title';
    this.titleEl.textContent = title;
    this.closeEl = document.createElement('div');
    this.closeEl.className = 'app-modal-close';
    this.closeEl.textContent = '✕';
    this.closeEl.addEventListener('click', () => this.close());
    this.header.appendChild(this.titleEl);
    this.header.appendChild(this.closeEl);
    // content + footer
    this.contentEl = document.createElement('div');
    this.contentEl.className = 'app-modal-content';
    this.footerEl = document.createElement('div');
    this.footerEl.className = 'app-modal-footer';
    // assemble
    this.modal.appendChild(this.header);
    this.modal.appendChild(this.contentEl);
    this.modal.appendChild(this.footerEl);
    // keyboard
    this._onKey = (e) => { if (e.key === 'Escape') this.close(); };
  }

  setTitle(text) { this.titleEl.textContent = text || ''; }
  setThemeColor(rgb) { this.modal.style.setProperty('--tint-rgb', rgb); }
  setContent(node) { this.contentEl.innerHTML = ''; if (node) this.contentEl.appendChild(node); }
  setFooter(node) { this.footerEl.innerHTML = ''; if (node) this.footerEl.appendChild(node); }

  open() {
    document.body.appendChild(this.overlay);
    document.body.appendChild(this.modal);
    requestAnimationFrame(() => {
      this.overlay.classList.add('active');
      this.modal.classList.add('active');
    });
    window.addEventListener('keydown', this._onKey);
  }
  close() {
    this.overlay.classList.remove('active');
    this.modal.classList.remove('active');
    window.removeEventListener('keydown', this._onKey);
    setTimeout(() => { this.overlay.remove(); this.modal.remove(); this.onClose && this.onClose(); }, 250);
  }
}

class WavetableCatalog {
  constructor(wavetables, currentIndex, themeColor, onSelect, showcasePrefix, bank) {
    this.wavetables = wavetables;  // Bank-specific wavetable array
    this.currentIndex = currentIndex;
    this.themeColor = themeColor;
    this.onSelect = onSelect;
    this.showcasePrefix = showcasePrefix;  // 'osc1' or 'osc2'
    this.bank = bank;  // 'A' or 'B'
    this.createOverlay();
  }

  createOverlay() {
    // Find the waveform-preview-container
    const canvas = document.getElementById(`${this.showcasePrefix}-waveform-canvas`);
    if (!canvas) return;
    const container = canvas.parentElement;  // waveform-preview-container
    if (!container) return;

    // Create or reuse overlay
    let overlay = container.querySelector('.catalog-overlay');
    if (!overlay) {
      overlay = document.createElement('div');
      overlay.className = 'catalog-overlay';
      container.appendChild(overlay);
    }

    // Clear previous content
    overlay.innerHTML = '';

    // Body (no header)
    const body = document.createElement('div');
    body.className = 'catalog-body';


    // Get grouped waveforms
    const grouped = window.wavetableLibrary.getAllGrouped();

    // FACTORY section
    if (grouped.factory && grouped.factory.length > 0) {
      const factorySection = this.createSection('FACTORY', grouped.factory, true);
      body.appendChild(factorySection);
    }

    // USER section
    if (grouped.user && grouped.user.length > 0) {
      const userSection = this.createSection('USER', grouped.user, false);
      body.appendChild(userSection);
    } else {
      const emptyMsg = document.createElement('div');
      emptyMsg.className = 'catalog-empty';
      emptyMsg.textContent = 'No user waveforms';
      const userSection = document.createElement('div');
      userSection.className = 'catalog-section';
      userSection.innerHTML = '<h4>USER</h4>';
      userSection.appendChild(emptyMsg);
      body.appendChild(userSection);
    }

    overlay.appendChild(body);

    // Click outside to close
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) {
        this.close();
      }
    });

    // ESC key handler
    this.escHandler = (e) => {
      if (e.key === 'Escape') this.close();
    };
    document.addEventListener('keydown', this.escHandler);

    this.overlay = overlay;
  }

  createSection(title, waveforms, isFactory) {
    const section = document.createElement('div');
    section.className = 'catalog-section';

    // Section title
    const titleEl = document.createElement('h4');
    titleEl.textContent = title;
    section.appendChild(titleEl);

    // Grid
    const grid = document.createElement('div');
    grid.className = 'catalog-grid';

    // Create grid items
    waveforms.forEach((waveform) => {
      const item = this.createWaveformItem(waveform, isFactory);
      grid.appendChild(item);
    });

    section.appendChild(grid);
    return section;
  }

  createWaveformItem(waveform, isFactory) {
    const item = document.createElement('div');
    item.className = 'catalog-item';

    // Check if current (active)
    if (isFactory && waveform.slotIndex === this.currentIndex) {
      item.classList.add('active');
    }

    // Preview canvas (high resolution for smooth display)
    const canvas = document.createElement('canvas');
    canvas.width = 240;
    canvas.height = 120;
    canvas.style.cssText = 'width: 90%; height: auto; display: block; margin-bottom: 0.25rem;';

    // Draw preview
    if (isFactory) {
      const primitiveData = generatePrimitiveSamples(waveform.type, 2048);
      this.drawPreview(canvas, primitiveData);
    } else {
      // User wavetable - check if data is already available
      if (waveform.data && waveform.data.length > 0) {
        // Draw immediately (old format with embedded data)
        this.drawPreview(canvas, waveform.data);
      } else if (waveform.filename) {
        // File-based wavetable - check cache first, then lazy load preview
        this.drawLoadingPlaceholder(canvas);

        // Try to get from cache first
        const loadPreview = async () => {
          let samples = null;

          // Check IndexedDB cache
          if (window.wavetablePreviewCache && window.wavetablePreviewCache.ready) {
            const cached = await window.wavetablePreviewCache.get(waveform.filename);
            if (cached && cached.samples) {
              console.log(`📦 Cache hit for preview: ${waveform.filename}`);
              samples = cached.samples;
              this.drawPreview(canvas, samples);
              return;
            }
          }

          // Cache miss - request from C++
          if (typeof window.wavetableLoadPreview === 'function') {
            window.wavetableLoadPreview(waveform.filename, async (samples, filename, error) => {
              if (error) {
                console.error('Failed to load preview for', filename, ':', error);
                this.drawErrorPlaceholder(canvas);
              } else if (samples && samples.length > 0) {
                this.drawPreview(canvas, samples);

                // Cache the preview for next time
                if (window.wavetablePreviewCache && window.wavetablePreviewCache.ready) {
                  await window.wavetablePreviewCache.set(filename, samples);
                  console.log(`💾 Cached preview: ${filename}`);
                }
              }
            });
          } else {
            this.drawErrorPlaceholder(canvas);
          }
        };

        loadPreview();
      } else {
        // No data available
        this.drawErrorPlaceholder(canvas);
      }
    }

    // Name label (Factory wavetables - catalog view shows name only)
    const label = document.createElement('div');
    label.textContent = waveform.name;
    label.style.cssText = 'font-size: 0.65rem; text-align: center; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;';

    item.appendChild(canvas);
    item.appendChild(label);

    // Click handler
    item.addEventListener('click', () => {
      console.log('🖱️ Catalog item clicked:', { isFactory, waveform });

      if (isFactory) {
        // Restore factory waveform to its original primitive state
        this.restoreFactorySlot(waveform.slotIndex, waveform.type);

        // Select factory waveform by slot index
        if (this.onSelect) {
          this.onSelect(waveform.slotIndex);
        }
        this.close();
      } else {
        // Load user waveform into current slot
        console.log('🔄 Loading user waveform:', waveform);
        this.loadUserWaveform(waveform);
      }
    });

    return item;
  }

  restoreFactorySlot(slotIndex, factoryType) {
    // Restore a factory slot to its original primitive state
    if (slotIndex == null || slotIndex < 0 || slotIndex > 5) return;

    const table = this.wavetables[slotIndex];
    if (!table) return;

    // Reset to factory defaults
    table.isCustom = false;
    table.isUnsaved = false;
    table.customData = null;
    table.name = table.originalName;
    table.type = table.originalType;

    // Send original primitive waveform to C++ (to correct bank slot)
    const primitiveData = generatePrimitiveSamples(table.originalType, 2048);
    const cppSlot = getCppSlot(this.showcasePrefix, this.bank);
    sendWavetable(cppSlot, primitiveData);

    // Update only the relevant showcase
    if (this.showcasePrefix === 'osc1' && window.osc1Showcase) {
      window.osc1Showcase.updateDisplay();
    } else if (this.showcasePrefix === 'osc2' && window.osc2Showcase) {
      window.osc2Showcase.updateDisplay();
    }

    console.log(`Restored factory slot ${slotIndex} (${table.originalName}) to original primitive in ${this.showcasePrefix} bank ${this.bank}`);
  }

  loadUserWaveform(userWaveform) {
    // Load user waveform into the currently selected slot
    console.log('📥 loadUserWaveform called:', {
      userWaveform,
      currentIndex: this.currentIndex,
      hasData: !!(userWaveform.data),
      hasFilename: !!(userWaveform.filename),
      dataLength: userWaveform.data ? userWaveform.data.length : 0
    });

    if (this.currentIndex == null) {
      console.error('❌ currentIndex is null');
      return;
    }

    const table = this.wavetables[this.currentIndex];
    if (!table) {
      console.error('❌ table not found at index', this.currentIndex);
      return;
    }

    // Helper function to apply waveform data to slot
    const applyWaveformToSlot = (samples) => {
      console.log(`✨ Applying waveform to slot ${this.currentIndex}:`, {
        sampleCount: samples.length,
        name: userWaveform.name,
        cppSlot: getCppSlot(this.showcasePrefix, this.bank)
      });

      // Update slot with user waveform data
      table.isCustom = true;
      table.customData = new Float32Array(samples);
      table.name = userWaveform.name;
      table.isUnsaved = false;  // Loading from catalog is not an "edit" - no unsaved changes

      // Send to C++ (to correct bank slot)
      const cppSlot = getCppSlot(this.showcasePrefix, this.bank);
      sendWavetable(cppSlot, table.customData);

      // Clear any existing snapshot to prevent revert button from being enabled
      // (loading from catalog is not an "edit" operation)
      const snapshotKey = `${this.showcasePrefix}_${this.bank}_${this.currentIndex}`;
      if (typeof wavetableSnapshots !== 'undefined') {
        wavetableSnapshots.delete(snapshotKey);
        console.log(`🗑️ Cleared snapshot for ${snapshotKey}`);
      }

      // Update only the relevant showcase
      if (this.showcasePrefix === 'osc1' && window.osc1Showcase) {
        window.osc1Showcase.updateDisplay();
        // Update revert button state in editor
        if (window.osc1InlineEditor && typeof window.osc1InlineEditor.updateRevertButton === 'function') {
          window.osc1InlineEditor.updateRevertButton();
        }
      } else if (this.showcasePrefix === 'osc2' && window.osc2Showcase) {
        window.osc2Showcase.updateDisplay();
        // Update revert button state in editor
        if (window.osc2InlineEditor && typeof window.osc2InlineEditor.updateRevertButton === 'function') {
          window.osc2InlineEditor.updateRevertButton();
        }
      }

      console.log(`✅ Applied user waveform "${userWaveform.name}" to slot ${this.currentIndex} in ${this.showcasePrefix} bank ${this.bank}`);
      this.close();
    };

    // Check if data is already available (old format)
    if (userWaveform.data && userWaveform.data.length === 2048) {
      console.log('📦 Using embedded data (old format)');
      applyWaveformToSlot(userWaveform.data);
    } else if (userWaveform.filename) {
      // File-based wavetable - load preview and interpolate to 2048 samples
      // NOTE: We use preview (256 samples) instead of full file load to avoid WebKit message size limits
      console.log(`📂 Loading preview for interpolation: ${userWaveform.filename}`);

      const loadAndInterpolate = async () => {
        // Try to get preview from cache or C++
        let previewSamples = null;

        // Check IndexedDB cache first
        if (window.wavetablePreviewCache && window.wavetablePreviewCache.ready) {
          const cached = await window.wavetablePreviewCache.get(userWaveform.filename);
          if (cached && cached.samples) {
            console.log(`📦 Using cached preview for interpolation`);
            previewSamples = cached.samples;
          }
        }

        // If not in cache, load preview from C++
        if (!previewSamples && typeof window.wavetableLoadPreview === 'function') {
          await new Promise((resolve) => {
            window.wavetableLoadPreview(userWaveform.filename, (samples, filename, error) => {
              if (!error && samples) {
                previewSamples = samples;
              }
              resolve();
            });
          });
        }

        if (!previewSamples) {
          console.error('❌ Failed to load preview for interpolation');
          alert('Failed to load wavetable preview');
          return;
        }

        // Interpolate 256 samples to 2048 samples (8x upsampling)
        console.log(`🔄 Interpolating ${previewSamples.length} samples to 2048`);
        const fullSamples = new Float32Array(2048);
        const ratio = previewSamples.length / 2048;

        for (let i = 0; i < 2048; i++) {
          const srcPos = i * ratio;
          const srcIdx = Math.floor(srcPos);
          const frac = srcPos - srcIdx;
          const nextIdx = Math.min(srcIdx + 1, previewSamples.length - 1);

          // Linear interpolation
          fullSamples[i] = previewSamples[srcIdx] * (1 - frac) + previewSamples[nextIdx] * frac;
        }

        console.log(`✅ Interpolated to ${fullSamples.length} samples`);
        applyWaveformToSlot(fullSamples);
      };

      loadAndInterpolate();
    } else {
      console.error('❌ User waveform has no data or filename:', userWaveform);
      alert('Failed to load wavetable: No data available');
    }
  }

  drawPreview(canvas, waveform) {
    const ctx = canvas.getContext('2d');
    const width = canvas.width;
    const height = canvas.height;
    const centerY = height / 2;
    const amplitude = height * 0.4;

    // Clear canvas
    ctx.fillStyle = '#0a0a0a';
    ctx.fillRect(0, 0, width, height);

    // Draw waveform
    ctx.strokeStyle = `rgba(${this.themeColor}, 0.9)`;
    ctx.lineWidth = 2;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    ctx.beginPath();
    for (let i = 0; i < width; i++) {
      const sampleIndex = Math.floor((i / width) * waveform.length);
      const sample = waveform[sampleIndex];
      const y = centerY - sample * amplitude;

      if (i === 0) {
        ctx.moveTo(i, y);
      } else {
        ctx.lineTo(i, y);
      }
    }
    ctx.stroke();

    // Draw line preview when shift-constraining
    if (this.lineConstraintActive && this.lineStartPos && this.linePreviewPos) {
      ctx.strokeStyle = `rgba(${this.themeColor}, 0.5)`;
      ctx.lineWidth = 2;
      ctx.setLineDash([5, 5]);
      ctx.beginPath();
      ctx.moveTo(this.lineStartPos.x, this.lineStartPos.y);
      ctx.lineTo(this.linePreviewPos.x, this.linePreviewPos.y);
      ctx.stroke();
      ctx.setLineDash([]);
    }
  }

  drawLoadingPlaceholder(canvas) {
    const ctx = canvas.getContext('2d');
    const width = canvas.width;
    const height = canvas.height;

    // Background
    ctx.fillStyle = '#0a0a0a';
    ctx.fillRect(0, 0, width, height);

    // Loading text
    ctx.fillStyle = `rgba(${this.themeColor}, 0.5)`;
    ctx.font = '14px var(--font-body)';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('Loading...', width / 2, height / 2);
  }

  drawErrorPlaceholder(canvas) {
    const ctx = canvas.getContext('2d');
    const width = canvas.width;
    const height = canvas.height;

    // Background
    ctx.fillStyle = '#0a0a0a';
    ctx.fillRect(0, 0, width, height);

    // Error message
    ctx.fillStyle = 'rgba(255, 100, 100, 0.5)';
    ctx.font = '14px var(--font-body)';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('No preview', width / 2, height / 2);
  }

  open() {
    if (this.overlay) {
      this.overlay.classList.add('visible');
    }
    // Add .is-open to label for visual feedback
    const label = document.getElementById(`${this.showcasePrefix}-wave-label`);
    if (label) {
      label.classList.add('is-open');
    }
  }

  close() {
    if (this.overlay) {
      this.overlay.classList.remove('visible');
    }
    // Remove .is-open from label
    const label = document.getElementById(`${this.showcasePrefix}-wave-label`);
    if (label) {
      label.classList.remove('is-open');
    }
    if (this.escHandler) {
      document.removeEventListener('keydown', this.escHandler);
    }
  }
}

// ============================================================================
// Info Modal (About)
// ============================================================================
(function setupInfoModal() {
  const overlay = document.getElementById('about-overlay');
  const modal = document.getElementById('about-modal');
  const closeBtn = document.getElementById('about-close');
  const logo = document.querySelector('.logo');
  if (!overlay || !modal || !logo) return;
  const versionEl = modal.querySelector('.about-modal-version');
  if (versionEl && typeof APP_VERSION !== 'undefined') {
    versionEl.textContent = `Version v${APP_VERSION}`;
  }

  const close = () => {
    overlay.classList.remove('active');
    modal.classList.remove('active');
    document.removeEventListener('keydown', onKey);
  };

  const onKey = (e) => {
    if (e.key === 'Escape') close();
  };

  const open = () => {
    overlay.classList.add('active');
    modal.classList.add('active');
    document.addEventListener('keydown', onKey);
  };

  overlay.addEventListener('click', (e) => {
    if (e.target === overlay) close();
  });
  if (closeBtn) closeBtn.addEventListener('click', close);

  logo.style.cursor = 'pointer';
  logo.addEventListener('click', (e) => {
    const header = document.querySelector('.app-header');
    if (header && header.classList.contains('preset-viewing')) return;
    e.preventDefault();
    open();
  });
})();

// ============================================================================
// Preset Save As Modal
// ============================================================================
(function setupSaveAsModal() {
  const overlay = document.getElementById('saveas-overlay');
  const modal = document.getElementById('saveas-modal');
  const form = document.getElementById('saveas-form');
  const closeBtn = document.getElementById('saveas-close');
  const cancelBtn = document.getElementById('saveas-cancel');
  const nameInput = document.getElementById('saveas-name');

  if (!overlay || !modal || !form) return;

  const close = () => {
    overlay.classList.remove('active');
    modal.classList.remove('active');
    form.reset();
  };

  const onKey = (e) => {
    if (e.key === 'Escape') close();
  };

  // Close button
  if (closeBtn) closeBtn.addEventListener('click', close);

  // Cancel button
  if (cancelBtn) cancelBtn.addEventListener('click', close);

  // Click outside to close
  overlay.addEventListener('click', (e) => {
    if (e.target === overlay) close();
  });

  // Handle form submission
  form.addEventListener('submit', (e) => {
    e.preventDefault();

    const name = document.getElementById('saveas-name').value.trim();
    const category = document.getElementById('saveas-category').value;
    const description = document.getElementById('saveas-description').value.trim();
    const author = document.getElementById('saveas-author').value.trim();

    if (!name) {
      alert('Please enter a preset name');
      nameInput.focus();
      return;
    }

    // Sync matrix configuration from DOM to __matrixRoutes before saving
    sendMatrixConfig();

    // Call the preset manager's _doSavePreset method
    if (window.presetManager) {
      window.presetManager._doSavePreset(name, category, description, author, false);
    }

    close();
  });

  // Add Escape key listener when modal is visible
  overlay.addEventListener('transitionend', () => {
    if (overlay.style.display === 'flex') {
      document.addEventListener('keydown', onKey);
    } else {
      document.removeEventListener('keydown', onKey);
    }
  });
})();

// ============================================================================
// Wavetable Save Dialog - Simple modal for naming and saving wavetables
// ============================================================================

class WavetableSaveDialog {
  constructor(defaultName, onSave) {
    this.defaultName = defaultName || 'Custom';
    this.onSave = onSave;
    this.modal = null;
    this.input = null;
  }

  open() {
    // Create modal overlay
    this.modal = document.createElement('div');
    this.modal.className = 'modal-overlay';
    this.modal.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.7);
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 10000;
    `;

    // Create dialog
    const dialog = document.createElement('div');
    dialog.style.cssText = `
      background: #222;
      border: 1px solid #444;
      border-radius: 8px;
      padding: 24px;
      min-width: 320px;
      max-width: 400px;
    `;

    // Title
    const title = document.createElement('h3');
    title.textContent = 'Save to USER WAVEFORMS';
    title.style.cssText = `
      margin: 0 0 16px 0;
      color: #fff;
      font-size: 16px;
      font-weight: 600;
    `;
    dialog.appendChild(title);

    // Input
    this.input = document.createElement('input');
    this.input.type = 'text';
    this.input.value = this.defaultName;
    this.input.autocomplete = 'off';
    this.input.spellcheck = false;
    this.input.style.cssText = `
      width: 100%;
      padding: 8px 12px;
      background: #333;
      border: 1px solid #555;
      border-radius: 4px;
      color: #fff;
      font-size: 14px;
      margin-bottom: 16px;
      box-sizing: border-box;
      outline: none;
    `;
    this.input.style.pointerEvents = 'auto';
    this.input.tabIndex = 0;
    dialog.appendChild(this.input);

    // Buttons container
    const buttons = document.createElement('div');
    buttons.style.cssText = `
      display: flex;
      gap: 8px;
      justify-content: flex-end;
    `;

    // Cancel button
    const cancelBtn = document.createElement('button');
    cancelBtn.textContent = 'Cancel';
    cancelBtn.style.cssText = `
      padding: 8px 16px;
      background: #444;
      border: 1px solid #555;
      border-radius: 4px;
      color: #fff;
      cursor: pointer;
      font-size: 14px;
    `;
    cancelBtn.addEventListener('click', () => this.close(false));
    buttons.appendChild(cancelBtn);

    // Save button
    const saveBtn = document.createElement('button');
    saveBtn.textContent = 'Save';
    saveBtn.style.cssText = `
      padding: 8px 16px;
      background: #007bff;
      border: 1px solid #0056b3;
      border-radius: 4px;
      color: #fff;
      cursor: pointer;
      font-size: 14px;
      font-weight: 600;
    `;
    saveBtn.addEventListener('click', () => this.close(true));
    buttons.appendChild(saveBtn);

    dialog.appendChild(buttons);

    // Add to modal
    this.modal.appendChild(dialog);
    document.body.appendChild(this.modal);

    // Focus input and select text (multiple attempts for reliability)
    const focusInput = () => {
      if (this.input) {
        this.input.focus();
        this.input.select();
      }
    };

    // Immediate focus
    focusInput();

    // Delayed focus (backup)
    setTimeout(focusInput, 10);
    setTimeout(focusInput, 50);
    setTimeout(focusInput, 100);

    // Click to focus
    this.input.addEventListener('click', (e) => {
      e.stopPropagation();
      this.input.focus();
    });

    // Handle Enter/Escape
    this.input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        this.close(true);
      } else if (e.key === 'Escape') {
        e.preventDefault();
        this.close(false);
      }
    });

    // Click outside to cancel
    this.modal.addEventListener('click', (e) => {
      if (e.target === this.modal) {
        this.close(false);
      }
    });
  }

  close(save) {
    const name = save ? this.input.value.trim() : '';

    if (this.modal) {
      this.modal.remove();
      this.modal = null;
    }

    if (this.onSave) {
      this.onSave(name);
    }
  }
}

// ============================================================================
// Inline Wavetable Editor (embedded in preview canvas)
// ============================================================================

class InlineWavetableEditor {
  constructor(showcase) {
    this.showcase = showcase;
    this.canvas = showcase?.canvas || null;
    if (!this.canvas) return;

    this.themeColor = showcase.themeColor || '255, 255, 255';
    this.label = showcase.label;
    this.saveBtn = document.getElementById(`${showcase.prefix}-save-btn`);
    this.revertBtn = document.getElementById(`${showcase.prefix}-revert-btn`);
    this.waveformData = null;
    this.currentSlot = null;
    this.isDrawing = false;
    this.lastDrawPos = null;
    this.lastPointerPos = null;
    this.lineConstraintActive = false;
    this.lineStartPos = null;
    this.linePreviewPos = null;
    this.needsSend = false;
    this.renameInput = null;
    this.renameBlurHandler = null;

    this.handleMouseUpBound = (e) => this.handleMouseUp(e);
    this.canvas.addEventListener('mousedown', (e) => this.handleMouseDown(e));
    this.canvas.addEventListener('mousemove', (e) => this.handleMouseMove(e));
    this.canvas.addEventListener('mouseleave', () => this.handleMouseLeave());
    document.addEventListener('mouseup', this.handleMouseUpBound);

    if (this.saveBtn) {
      this.saveBtn.addEventListener('click', (e) => {
        e.preventDefault();
        this.startInlineSave();
      });
    }

    // Setup dropdown menu
    this.dropdownSelect = document.getElementById(`${showcase.prefix}-save-dropdown`);
    if (this.dropdownSelect) {
      this.setupDropdownSelect();
    }

    // Setup inline save input
    this.inlineInput = document.getElementById(`${showcase.prefix}-inline-input`);
    this.inlineNameInput = document.getElementById(`${showcase.prefix}-inline-name`);
    this.inlineCancelBtn = document.getElementById(`${showcase.prefix}-inline-cancel`);
    this.inlineOkBtn = document.getElementById(`${showcase.prefix}-inline-ok`);
    this.normalControls = document.getElementById(`${showcase.prefix}-controls`);

    if (this.inlineCancelBtn) {
      this.inlineCancelBtn.addEventListener('click', (e) => {
        e.preventDefault();
        this.hideInlineSaveInput();
      });
    }

    if (this.inlineOkBtn) {
      this.inlineOkBtn.addEventListener('click', (e) => {
        e.preventDefault();
        this.confirmInlineSave();
      });
    }

    if (this.inlineNameInput) {
      this.inlineNameInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
          e.preventDefault();
          this.confirmInlineSave();
        } else if (e.key === 'Escape') {
          e.preventDefault();
          this.hideInlineSaveInput();
        }
      });
    }

    if (this.revertBtn) {
      this.revertBtn.disabled = true;
      this.revertBtn.style.display = 'none';  // Initially hidden
      this.revertBtn.addEventListener('click', (e) => {
        e.preventDefault();
        this.handleRevert();
      });
    }

    if (this.showcase) {
      this.showcase.setInlineEditor(this);
    }
    this.updateRevertButton();
  }

  destroy() {
    document.removeEventListener('mouseup', this.handleMouseUpBound);
  }

  setupDropdownSelect() {
    // Add event listener for native select
    this.dropdownSelect.addEventListener('change', (e) => {
      const action = e.target.value;
      if (action) {
        this.handleDropdownAction(action);
        // Reset select to default
        e.target.value = '';
      }
    });

    // Update state when showcase changes
    this.updateDropdownState();
  }

  updateDropdownState() {
    if (!this.dropdownSelect || !this.showcase) return;

    const slotIndex = this.getActiveSlotIndex();
    if (slotIndex == null) return;

    const wavetables = this.showcase.getWavetables();
    const table = wavetables[slotIndex];
    if (!table) return;

    const isCustom = table.isCustom && table.customData;
    const hasUnsavedChanges = table.name.endsWith('*');
    const isSaved = isCustom && !hasUnsavedChanges;
    const isUserWaveform = !!table.catalogId;  // Has catalogId = saved user waveform

    // Enable/disable options based on waveform state
    const saveOption = this.dropdownSelect.querySelector('option[value="save"]');
    const renameOption = this.dropdownSelect.querySelector('option[value="rename"]');
    const deleteOption = this.dropdownSelect.querySelector('option[value="delete"]');

    if (saveOption) saveOption.disabled = !isCustom;
    if (renameOption) renameOption.disabled = !isSaved;  // Only saved waveforms can be renamed
    if (deleteOption) deleteOption.disabled = !isUserWaveform;  // Only user waveforms can be deleted
  }

  handleDropdownAction(action) {
    switch (action) {
      case 'save':
        this.handleSave();
        break;
      case 'saveAs':
        this.handleSaveAs();
        break;
      case 'rename':
        this.handleRename();
        break;
      case 'delete':
        this.handleDelete();
        break;
      case 'verticalFlip':
        this.handleVerticalFlip();
        break;
      case 'horizontalFlip':
        this.handleHorizontalFlip();
        break;
      case 'randomize':
        this.handleRandomize();
        break;
      case 'clear':
        this.handleClear();
        break;
    }
  }

  handleSave() {
    // Overwrite current user waveform
    const slotIndex = this.getActiveSlotIndex();
    if (slotIndex == null || !this.showcase) return;

    const wavetables = this.showcase.getWavetables();
    const table = wavetables[slotIndex];
    if (!table || !table.isCustom) return;

    // Get current name (without asterisk)
    const currentName = table.name.replace(/\*+$/, '').trim();

    // Save with current name
    this.saveCurrentWaveformToCatalog(slotIndex, currentName);
  }

  handleSaveAs() {
    // Save as new waveform with different name (inline input)
    const slotIndex = this.getActiveSlotIndex();
    if (slotIndex == null) return;

    // Get suggested name from current waveform
    const wavetables = this.showcase.getWavetables();
    const table = wavetables[slotIndex];
    const suggestedName = table?.name?.replace(/\*+$/, '').trim() || 'Custom';

    this.showInlineSaveInput(suggestedName);
  }

  showInlineSaveInput(suggestedName = '') {
    if (!this.inlineInput || !this.normalControls || !this.inlineNameInput) return;

    // Hide normal controls, show inline input
    this.normalControls.style.display = 'none';
    this.inlineInput.style.display = 'flex';

    // Set suggested name and focus
    this.inlineNameInput.value = suggestedName;
    this.inlineNameInput.select();
    this.inlineNameInput.focus();
  }

  hideInlineSaveInput() {
    if (!this.inlineInput || !this.normalControls) return;

    // Show normal controls, hide inline input
    this.normalControls.style.display = 'flex';
    this.inlineInput.style.display = 'none';

    // Clear input
    if (this.inlineNameInput) {
      this.inlineNameInput.value = '';
    }
  }

  confirmInlineSave() {
    if (!this.inlineNameInput) return;

    const name = this.inlineNameInput.value.trim();
    if (!name) {
      alert('Please enter a name for the waveform.');
      return;
    }

    // Check for duplicate in factory waveforms (read-only, cannot overwrite)
    const factoryWaveforms = window.wavetableLibrary?.getFactoryWaveforms() || [];
    const existingFactory = factoryWaveforms.find(w => w.name.toLowerCase() === name.toLowerCase());

    if (existingFactory) {
      // Factory name - cannot use
      alert(`"${name}" is a factory waveform name. Please choose a different name.`);
      this.inlineNameInput.select();
      this.inlineNameInput.focus();
      return;
    }

    // Check for duplicate in user catalog
    const userWaveforms = window.wavetableLibrary?.getUserWaveforms() || [];
    const existingWaveform = userWaveforms.find(w => w.name.toLowerCase() === name.toLowerCase());

    if (existingWaveform) {
      // Name already exists - ask for confirmation
      const confirmed = confirm(`A waveform named "${name}" already exists. Overwrite it?`);
      if (!confirmed) {
        // User cancelled - keep input open for editing
        this.inlineNameInput.select();
        this.inlineNameInput.focus();
        return;
      }
      // User confirmed - proceed with overwrite (don't auto-rename)
    }

    // Save with the entered name
    const slotIndex = this.getActiveSlotIndex();
    if (slotIndex != null) {
      const allowOverwrite = !!existingWaveform;  // If duplicate was confirmed, allow overwrite
      this.saveCurrentWaveformToCatalog(slotIndex, name, allowOverwrite);
    }

    // Hide inline input and return to normal controls
    this.hideInlineSaveInput();
  }

  handleRename() {
    // Rename current user waveform (not implemented yet)
    console.log('Rename functionality - to be implemented');
    // TODO: Show rename dialog, update catalog entry
  }

  handleDelete() {
    // Delete current user waveform from catalog
    const slotIndex = this.getActiveSlotIndex();
    if (slotIndex == null || !this.showcase) return;

    const wavetables = this.showcase.getWavetables();
    const table = wavetables[slotIndex];
    if (!table) return;

    // Only allow deletion of user waveforms (with catalogId)
    if (!table.catalogId) {
      alert('Cannot delete factory waveforms or unsaved waveforms.');
      return;
    }

    // Confirm deletion
    const waveformName = table.name.replace(/\*+$/, '').trim();
    const confirmed = confirm(`Delete "${waveformName}" from your library?\n\nThis action cannot be undone.`);
    if (!confirmed) return;

    // Delete from localStorage catalog
    if (window.wavetableLibrary && window.wavetableLibrary.delete(table.catalogId)) {
      console.log(`Deleted wavetable "${waveformName}" (ID: ${table.catalogId})`);

      // Revert current slot to first factory waveform (Sine)
      const factoryWaveforms = window.wavetableLibrary.getFactoryWaveforms();
      if (factoryWaveforms && factoryWaveforms.length > 0) {
        const sine = factoryWaveforms[0];  // Sine wave
        wavetables[slotIndex] = {
          name: sine.name,
          isFactory: true,
          factoryType: sine.type,
          slotIndex: sine.slotIndex,
          customData: null,
          catalogId: null
        };

        // Update display
        this.showcase.updateDisplay();

        // Send default factory waveform to C++
        const cppSlot = this.showcase.getCppSlotForBank();
        const defaultWaveform = generatePrimitiveSamples(sine.type, 2048);
        sendWavetable(cppSlot, defaultWaveform);
      }

      // Clear editor state
      this.waveformData = null;
      this.currentSlot = null;
      this.updateRevertButton();
      this.updateDropdownState();

      alert(`"${waveformName}" has been deleted from your library.`);
    } else {
      alert('Failed to delete waveform. Please try again.');
    }
  }

  handleVerticalFlip() {
    // Flip waveform vertically (invert amplitude)
    const slotIndex = this.getActiveSlotIndex();
    if (slotIndex == null || !this.showcase) return;

    // Capture snapshot before editing
    this.prepareWaveformBuffer(slotIndex, true);
    this.convertFactoryToCustomOnEdit(slotIndex);

    const wavetables = this.showcase.getWavetables();
    const table = wavetables[slotIndex];
    if (!table || !table.customData) return;

    // Flip all samples vertically (multiply by -1)
    for (let i = 0; i < table.customData.length; i++) {
      table.customData[i] = -table.customData[i];
    }

    // Update editor buffer to match modified data
    this.waveformData = table.customData;
    this.currentSlot = slotIndex;

    // Mark as edited
    this.markAsEdited(slotIndex);
    this.showcase.updateDisplay();

    // Send to plugin
    const cppSlot = this.showcase.getCppSlotForBank();
    sendWavetable(cppSlot, table.customData);
  }

  handleHorizontalFlip() {
    // Flip waveform horizontally (reverse time)
    const slotIndex = this.getActiveSlotIndex();
    if (slotIndex == null || !this.showcase) return;

    // Capture snapshot before editing
    this.prepareWaveformBuffer(slotIndex, true);
    this.convertFactoryToCustomOnEdit(slotIndex);

    const wavetables = this.showcase.getWavetables();
    const table = wavetables[slotIndex];
    if (!table || !table.customData) return;

    // Reverse the array
    const reversed = new Float32Array(table.customData.length);
    for (let i = 0; i < table.customData.length; i++) {
      reversed[i] = table.customData[table.customData.length - 1 - i];
    }
    table.customData.set(reversed);

    // Update editor buffer to match modified data
    this.waveformData = table.customData;
    this.currentSlot = slotIndex;

    // Mark as edited
    this.markAsEdited(slotIndex);
    this.showcase.updateDisplay();

    // Send to plugin
    const cppSlot = this.showcase.getCppSlotForBank();
    sendWavetable(cppSlot, table.customData);
  }

  handleRandomize() {
    // Randomize waveform
    const slotIndex = this.getActiveSlotIndex();
    if (slotIndex == null || !this.showcase) return;

    // Capture snapshot before editing
    this.prepareWaveformBuffer(slotIndex, true);
    this.convertFactoryToCustomOnEdit(slotIndex);

    const wavetables = this.showcase.getWavetables();
    const table = wavetables[slotIndex];
    if (!table || !table.customData) return;

    // Generate random waveform with smooth interpolation
    const numPoints = 8;  // Number of random control points
    const controlPoints = [];
    for (let i = 0; i < numPoints; i++) {
      controlPoints.push(Math.random() * 2 - 1);  // Random value -1 to +1
    }

    // Interpolate between control points
    for (let i = 0; i < table.customData.length; i++) {
      const pos = (i / table.customData.length) * (numPoints - 1);
      const idx0 = Math.floor(pos);
      const idx1 = (idx0 + 1) % numPoints;
      const frac = pos - idx0;

      // Linear interpolation
      table.customData[i] = controlPoints[idx0] * (1 - frac) + controlPoints[idx1] * frac;
    }

    // Update editor buffer to match modified data
    this.waveformData = table.customData;
    this.currentSlot = slotIndex;

    // Mark as edited
    this.markAsEdited(slotIndex);
    this.showcase.updateDisplay();

    // Send to plugin
    const cppSlot = this.showcase.getCppSlotForBank();
    sendWavetable(cppSlot, table.customData);
  }

  handleClear() {
    // Clear waveform (set all samples to 0)
    const slotIndex = this.getActiveSlotIndex();
    if (slotIndex == null || !this.showcase) return;

    // Capture snapshot before editing
    this.prepareWaveformBuffer(slotIndex, true);
    this.convertFactoryToCustomOnEdit(slotIndex);

    const wavetables = this.showcase.getWavetables();
    const table = wavetables[slotIndex];
    if (!table || !table.customData) return;

    // Set all samples to 0
    table.customData.fill(0);

    // Update editor buffer to match modified data
    this.waveformData = table.customData;
    this.currentSlot = slotIndex;

    // Mark as edited
    this.markAsEdited(slotIndex);
    this.showcase.updateDisplay();

    // Send to plugin
    const cppSlot = this.showcase.getCppSlotForBank();
    sendWavetable(cppSlot, table.customData);
  }

  markAsEdited(slotIndex) {
    // Mark as edited: add asterisk to name and set isUnsaved flag
    if (!this.showcase) return;

    const wavetables = this.showcase.getWavetables();
    const table = wavetables[slotIndex];
    if (!table) return;

    if (!table.name.endsWith('*')) {
      table.name += '*';
      if (this.showcase.label) {
        // Update bank and name spans (determine if user or factory wavetable)
        const bankSpan = this.showcase.label.querySelector('.waveform-overlay-label-bank');
        const nameSpan = this.showcase.label.querySelector('.waveform-overlay-label-name');

        if (bankSpan && nameSpan) {
          // Check if this is a user or factory wavetable
          const bankLabel = table.isCustom ? 'User' : 'Factory';
          bankSpan.textContent = bankLabel;
          nameSpan.textContent = table.name;
        } else {
          // Fallback for compatibility
          this.showcase.label.textContent = table.name;
        }
      }
    }

    // Set isUnsaved flag to indicate unsaved edits
    table.isUnsaved = true;

    // Update dropdown state
    this.updateDropdownState();
  }

  getActiveSlotIndex() {
    if (!this.showcase) return null;
    const key = (this.showcase.mode === 'B') ? 'B' : 'A';
    return this.showcase.banks[key];
  }

  prepareWaveformBuffer(slotIndex, captureSnapshot = false) {
    if (slotIndex == null || !this.showcase) return;
    if (this.currentSlot !== slotIndex || !this.waveformData) {
      const wavetables = this.showcase.getWavetables();
      this.waveformData = getWavetableSamplesForEditing(wavetables[slotIndex]);
      this.currentSlot = slotIndex;
      this.lastDrawPos = null;
    }
    if (captureSnapshot) this.captureSnapshot(slotIndex);
  }

  captureSnapshot(slotIndex) {
    if (!this.showcase) return;
    const snapshotKey = `${this.showcase.prefix}_${this.showcase.mode}_${slotIndex}`;
    if (wavetableSnapshots.has(snapshotKey)) return;

    const wavetables = this.showcase.getWavetables();
    const table = wavetables[slotIndex];
    if (!table) return;

    wavetableSnapshots.set(snapshotKey, {
      name: table.name,
      type: table.type,
      isCustom: table.isCustom,
      customData: table.isCustom && table.customData ? new Float32Array(table.customData) : null
    });
    this.updateRevertButton();
  }

  updateRevertButton() {
    if (!this.revertBtn || !this.showcase) return;
    const slotIndex = this.getActiveSlotIndex();
    if (slotIndex == null) {
      this.revertBtn.style.display = 'none';
      return;
    }

    const wavetables = this.showcase.getWavetables();
    const table = wavetables[slotIndex];
    if (!table) {
      this.revertBtn.style.display = 'none';
      return;
    }

    const snapshotKey = `${this.showcase.prefix}_${this.showcase.mode}_${slotIndex}`;
    const hasSnapshot = wavetableSnapshots.has(snapshotKey);

    // Use isUnsaved flag instead of isCustom to determine if editing
    // isCustom=true just means custom data (could be loaded from catalog)
    // isUnsaved=true means actual unsaved edits
    const isEditing = table.isUnsaved === true;

    // Show button only if: has unsaved changes OR has snapshot to revert to
    const shouldShow = isEditing || hasSnapshot;
    this.revertBtn.style.display = shouldShow ? '' : 'none';
    this.revertBtn.disabled = !hasSnapshot;
  }

  notifyOtherShowcase() {
    // No longer notify other showcase since banks are now independent
    // Each showcase manages its own wavetable arrays
    return;
  }

  onShowcaseUpdated() {
    this.updateRevertButton();
  }

  convertFactoryToCustomOnEdit(slotIndex) {
    // When editing a factory primitive, convert it to a custom slot with unique name
    // This keeps factory slots pristine and creates a working copy for editing
    if (slotIndex == null || slotIndex < 0 || slotIndex > 5 || !this.showcase) return;

    const wavetables = this.showcase.getWavetables();
    const table = wavetables[slotIndex];
    if (!table) return;

    // If already custom, no need to convert (allow in-place editing/overwriting)
    if (table.isCustom && table.customData) {
      console.log(`✓ User waveform "${table.name}" - editing in place (no rename)`);
      return;
    }

    // This is a factory primitive - create a custom copy
    const baseName = table.originalName || table.name;

    // Collect all existing names from:
    // 1. Factory waveforms
    // 2. User waveforms (saved to localStorage)
    // 3. Currently editing waveforms in all banks (unsaved)
    let uniqueName = baseName;
    let counter = 2;

    const factoryNames = ['Sine', 'Saw', 'Square', 'Triangle'].map(n => n.toLowerCase());
    const userWaveforms = window.wavetableLibrary ? window.wavetableLibrary.getUserWaveforms() : [];
    const userNames = userWaveforms.map(w => w.name.toLowerCase());

    // Check all bank arrays for currently editing waveforms
    const editingNames = [];
    [wavetablesOsc1A, wavetablesOsc1B, wavetablesOsc2A, wavetablesOsc2B].forEach(bankArray => {
      bankArray.forEach(wt => {
        if (wt.name) {
          // Remove asterisk and add to list
          const cleanName = wt.name.replace(/\*+$/, '').trim();
          if (cleanName) editingNames.push(cleanName.toLowerCase());
        }
      });
    });

    const allNames = [...factoryNames, ...userNames, ...editingNames];

    while (allNames.includes(uniqueName.toLowerCase())) {
      uniqueName = `${baseName}_${counter}`;
      counter++;
    }

    // Convert to custom slot
    const primitiveData = generatePrimitiveSamples(table.originalType, 2048);
    table.isCustom = true;
    table.isUnsaved = true;  // Mark as having unsaved edits
    table.customData = new Float32Array(primitiveData);
    table.name = uniqueName + '*';  // Add asterisk to indicate unsaved

    // Send to C++ using the correct bank slot
    const cppSlot = this.showcase.getCppSlotForBank();
    sendWavetable(cppSlot, table.customData);

    // Update display
    if (this.showcase) this.showcase.updateDisplay();

    console.log(`Converted factory slot ${slotIndex} (${baseName}) to custom "${uniqueName}*" for editing in ${this.showcase.prefix} bank ${this.showcase.mode}`);
  }

  getCanvasCoordinates(e) {
    const rect = this.canvas.getBoundingClientRect();
    const scaleX = this.canvas.width / rect.width;
    const scaleY = this.canvas.height / rect.height;
    const clientX = e?.clientX ?? (rect.left + rect.width / 2);
    const clientY = e?.clientY ?? (rect.top + rect.height / 2);
    return {
      x: (clientX - rect.left) * scaleX,
      y: (clientY - rect.top) * scaleY,
    };
  }

  handleMouseDown(e) {
    if (e.button !== 0) return;
    const slotIndex = this.getActiveSlotIndex();
    if (slotIndex == null) return;
    e.preventDefault();
    const pos = this.getCanvasCoordinates(e);
    this.lastPointerPos = pos;

    // Capture snapshot BEFORE converting (so revert goes back to factory state)
    this.prepareWaveformBuffer(slotIndex, true);

    // Convert factory primitive to custom copy before editing
    this.convertFactoryToCustomOnEdit(slotIndex);

    this.isDrawing = true;
    this.lastDrawPos = null;
    this.lineConstraintActive = e.shiftKey;
    if (this.lineConstraintActive) {
      this.lineStartPos = pos;
      this.linePreviewPos = pos;
    } else {
      this.updateWaveformAtPosition(pos.x, pos.y, false);
      this.applyWaveformToSlot();
    }
  }

  handleMouseMove(e) {
    if (!this.isDrawing) return;
    const pos = this.getCanvasCoordinates(e);
    this.lastPointerPos = pos;
    if (this.lineConstraintActive && this.lineStartPos) {
      this.linePreviewPos = pos;
    } else {
      this.updateWaveformAtPosition(pos.x, pos.y, true);
      this.applyWaveformToSlot();
    }
  }

  handleMouseUp(e) {
    if (!this.isDrawing) return;
    const pos = e ? this.getCanvasCoordinates(e) : (this.lastPointerPos || this.lineStartPos);
    if (this.lineConstraintActive && this.lineStartPos && pos) {
      this.drawLine(this.lineStartPos.x, this.lineStartPos.y, pos.x, pos.y);
      this.applyWaveformToSlot();
    }
    this.isDrawing = false;
    this.lastDrawPos = null;
    this.lineConstraintActive = false;
    this.lineStartPos = null;
    this.linePreviewPos = null;
    this.flushPendingSend();
    this.showcase?.updateDisplay();
  }

  handleMouseLeave() {
    if (this.isDrawing) {
      this.handleMouseUp();
    }
  }

  updateWaveformAtPosition(x, y, interpolateFromLast = false) {
    if (!this.waveformData) return;
    if (interpolateFromLast && this.lastDrawPos) {
      this.drawLine(this.lastDrawPos.x, this.lastDrawPos.y, x, y);
    } else {
      const width = this.canvas.width;
      const height = this.canvas.height;

      // Account for canvas padding
      const drawWidth = width - 2 * CANVAS_PADDING;
      const xInDrawArea = Math.max(0, Math.min(drawWidth, x - CANVAS_PADDING));
      const dataIndex = Math.floor((xInDrawArea / drawWidth) * this.waveformData.length);
      const value = ((height / 2 - y) / (height / 2));

      if (dataIndex >= 0 && dataIndex < this.waveformData.length) {
        this.waveformData[dataIndex] = Math.max(-1, Math.min(1, value));
      }
    }
    this.lastDrawPos = { x, y };
  }

  drawLine(x1, y1, x2, y2) {
    if (!this.waveformData) return;
    const width = this.canvas.width;
    const height = this.canvas.height;

    // Account for canvas padding
    const drawWidth = width - 2 * CANVAS_PADDING;
    const x1InDrawArea = Math.max(0, Math.min(drawWidth, x1 - CANVAS_PADDING));
    const x2InDrawArea = Math.max(0, Math.min(drawWidth, x2 - CANVAS_PADDING));

    const startIndex = Math.floor((x1InDrawArea / drawWidth) * this.waveformData.length);
    const endIndex = Math.floor((x2InDrawArea / drawWidth) * this.waveformData.length);
    const startValue = ((height / 2 - y1) / (height / 2));
    const endValue = ((height / 2 - y2) / (height / 2));
    const minIndex = Math.min(startIndex, endIndex);
    const maxIndex = Math.max(startIndex, endIndex);
    for (let i = minIndex; i <= maxIndex; i++) {
      if (i >= 0 && i < this.waveformData.length) {
        const t = (i - startIndex) / (endIndex - startIndex || 1);
        const value = startValue + (endValue - startValue) * t;
        this.waveformData[i] = Math.max(-1, Math.min(1, value));
      }
    }
  }

  applyWaveformToSlot(shouldRedraw = true) {
    if (this.currentSlot == null || !this.waveformData || !this.showcase) return;

    // Get the correct wavetable array for the current bank
    const wavetables = this.showcase.getWavetables();
    const table = wavetables[this.currentSlot];
    if (!table) return;

    table.isCustom = true;
    table.customData = new Float32Array(this.waveformData);
    ensureWaveNameHasMarker(table, table.name);
    this.needsSend = true;

    if (shouldRedraw) {
      this.showcase?.updateDisplay();
      this.notifyOtherShowcase();
    }
  }

  flushPendingSend() {
    if (!this.needsSend || this.currentSlot == null || !this.showcase) return;

    // Get the correct wavetable array and C++ slot for the current bank
    const wavetables = this.showcase.getWavetables();
    const table = wavetables[this.currentSlot];

    if (table && table.customData) {
      const cppSlot = this.showcase.getCppSlotForBank();
      sendWavetable(cppSlot, table.customData);
    }
    this.needsSend = false;
  }

  startInlineSave() {
    const slotIndex = this.getActiveSlotIndex();
    if (slotIndex == null || !this.showcase) return;

    const wavetables = this.showcase.getWavetables();
    const table = wavetables[slotIndex];
    if (!table || !table.isCustom) return;

    // Check if this is a factory waveform (newly edited) or existing user waveform
    const currentName = table.name.replace(/\*+$/, '').trim();
    const isNewlyCreated = currentName.match(/_\d+$/);  // Ends with _2, _3, etc.

    // Factory waveform (or newly created) → "Save As" behavior (open dialog)
    // Existing user waveform → "Save" behavior (overwrite)
    if (isNewlyCreated || !table.isCustom) {
      this.openSaveDialog(slotIndex);
    } else {
      // User waveform - save with current name (overwrite)
      this.handleSave();
    }
  }

  openSaveDialog(slotIndex) {
    if (!this.showcase) return;
    const wavetables = this.showcase.getWavetables();
    const table = wavetables[slotIndex];
    if (!table) return;

    // Get default name (remove asterisk)
    const defaultName = (table.name || 'Custom').replace(/\*+$/, '').trim();

    // Create dialog
    const dialog = new WavetableSaveDialog(defaultName, (name) => {
      if (name) {
        this.saveCurrentWaveformToCatalog(slotIndex, name);
      }
    });
    dialog.open();
  }

  saveCurrentWaveformToCatalog(slotIndex, customName = '', allowOverwrite = false) {
    try {
      if (!window.wavetableLibrary || slotIndex == null || !this.showcase) return;

      const wavetables = this.showcase.getWavetables();
      const table = wavetables[slotIndex];
      if (!table) return;

      // Get waveform data
      const data = table.customData || this.waveformData;
      if (!data || data.length === 0) return;

      // Use custom name or fallback
      let baseName = (customName || table.name || 'Custom').replace(/\*+$/, '').trim() || 'Custom';

      // Generate unique name (avoid factory and existing user waveforms)
      // Skip uniqueness check if overwrite is allowed
      const uniqueName = allowOverwrite ? baseName : this.generateUniqueName(baseName);

      // Save to USER WAVEFORMS section
      const saved = window.wavetableLibrary.save(uniqueName, data, ['user']);

      if (saved) {
        console.log(`Saved wavetable "${uniqueName}" to USER WAVEFORMS`);

        // Update slot: remove asterisk, clear isUnsaved flag
        table.name = uniqueName;
        table.isUnsaved = false;  // No longer has unsaved changes

        // Capture new snapshot of saved state (for Revert button)
        const snapshotKey = `${this.showcase.prefix}_${this.showcase.mode}_${slotIndex}`;
        wavetableSnapshots.set(snapshotKey, {
          name: table.name,
          type: table.type,
          isCustom: table.isCustom,
          isUnsaved: false,  // Saved state has no unsaved changes
          customData: table.isCustom && table.customData ? new Float32Array(table.customData) : null
        });
        this.updateRevertButton();

        // Show success feedback
        this.showSaveSuccess(uniqueName);
      }
    } catch (e) {
      console.warn('Failed to save wavetable to catalog:', e);
    }
  }

  generateUniqueName(baseName) {
    // Get all existing names from:
    // 1. Factory waveforms
    // 2. User waveforms (saved to localStorage)
    // 3. Currently editing waveforms in all banks (unsaved)
    const factoryNames = window.wavetableLibrary.getFactoryWaveforms().map(w => w.name.toLowerCase());
    const userWaveforms = window.wavetableLibrary.getUserWaveforms();
    const userNames = userWaveforms.map(w => w.name.toLowerCase());

    // Check all bank arrays for currently editing waveforms
    const editingNames = [];
    [wavetablesOsc1A, wavetablesOsc1B, wavetablesOsc2A, wavetablesOsc2B].forEach(bankArray => {
      bankArray.forEach(wt => {
        if (wt.name) {
          // Remove asterisk and add to list
          const cleanName = wt.name.replace(/\*+$/, '').trim();
          if (cleanName) editingNames.push(cleanName.toLowerCase());
        }
      });
    });

    const allNames = [...factoryNames, ...userNames, ...editingNames];

    // Check if base name conflicts
    let finalName = baseName;
    let counter = 1;

    while (allNames.includes(finalName.toLowerCase())) {
      counter++;
      finalName = `${baseName}_${counter}`;
    }

    return finalName;
  }

  revertFactorySlot(slotIndex) {
    // Revert the factory slot back to its original primitive state
    if (slotIndex == null || slotIndex < 0 || slotIndex > 5) return;

    const table = wavetables[slotIndex];
    if (!table) return;

    // Reset to factory defaults
    table.isCustom = false;
    table.customData = null;
    table.name = table.originalName;
    table.type = table.originalType;

    // Send original primitive waveform to C++
    const primitiveData = generatePrimitiveSamples(table.originalType, 2048);
    sendWavetable(slotIndex, primitiveData);

    // Update displays
    this.waveformData = primitiveData;
    if (this.showcase) {
      this.showcase.updateDisplay();
    }
    this.notifyOtherShowcase();

    console.log(`Reverted slot ${slotIndex} (${table.originalName}) to factory default`);
  }

  showSaveSuccess(name) {
    // Show success message in waveform-preview-container
    if (!this.canvas) return;

    const container = this.canvas.parentElement;  // waveform-preview-container
    if (!container) return;

    // Create or get existing notification element
    let notification = container.querySelector('.save-notification');
    if (!notification) {
      notification = document.createElement('div');
      notification.className = 'save-notification';
      container.appendChild(notification);
    }

    // Show notification
    notification.textContent = `SAVED: ${name}`;
    notification.classList.add('visible');

    // Hide after 1.5 seconds
    setTimeout(() => {
      notification.classList.remove('visible');
    }, 1500);
  }

  handleRevert() {
    const slotIndex = this.getActiveSlotIndex();
    if (slotIndex == null || !this.showcase) return;

    const snapshotKey = `${this.showcase.prefix}_${this.showcase.mode}_${slotIndex}`;
    const snapshot = wavetableSnapshots.get(snapshotKey);
    if (!snapshot) return;

    const wavetables = this.showcase.getWavetables();
    const table = wavetables[slotIndex];
    if (!table) return;

    // Revert to snapshot state
    table.name = snapshot.name;
    table.type = snapshot.type;
    table.isCustom = snapshot.isCustom;
    table.isUnsaved = snapshot.isUnsaved || false;  // Restore unsaved flag from snapshot

    const cppSlot = this.showcase.getCppSlotForBank();

    if (snapshot.isCustom && snapshot.customData) {
      table.customData = new Float32Array(snapshot.customData);
      sendWavetable(cppSlot, table.customData);
    } else {
      table.customData = null;
      const primitive = generatePrimitiveSamples(snapshot.type || table.originalType || 'sine', 2048);
      sendWavetable(cppSlot, primitive);
    }

    this.waveformData = getWavetableSamplesForEditing(table);
    wavetableSnapshots.delete(snapshotKey);
    this.updateRevertButton();
    this.showcase?.updateDisplay();

    console.log(`Reverted ${this.showcase.prefix} bank ${this.showcase.mode} slot ${slotIndex} to "${snapshot.name}"`);
  }
}

if (window.osc1Showcase) {
  window.osc1InlineEditor = new InlineWavetableEditor(window.osc1Showcase);
}
if (window.osc2Showcase) {
  window.osc2InlineEditor = new InlineWavetableEditor(window.osc2Showcase);
}

//==============================================================================
// Wavetable Preview Cache - IndexedDB caching for 256-sample previews
//==============================================================================
class WavetablePreviewCache {
  constructor() {
    this.db = null;
    this.dbName = 'AwaonWavetableCache';
    this.storeName = 'previews';
    this.version = 1;
    this.ready = false;
    this.init();
  }

  async init() {
    try {
      this.db = await new Promise((resolve, reject) => {
        const request = indexedDB.open(this.dbName, this.version);

        request.onerror = () => reject(request.error);
        request.onsuccess = () => resolve(request.result);

        request.onupgradeneeded = (event) => {
          const db = event.target.result;

          // Create object store if it doesn't exist
          if (!db.objectStoreNames.contains(this.storeName)) {
            const objectStore = db.createObjectStore(this.storeName, { keyPath: 'filename' });
            objectStore.createIndex('timestamp', 'timestamp', { unique: false });
          }
        };
      });

      this.ready = true;
      console.log('✅ WavetablePreviewCache initialized');
    } catch (error) {
      console.error('❌ Failed to initialize WavetablePreviewCache:', error);
      this.ready = false;
    }
  }

  async get(filename) {
    if (!this.ready || !this.db) return null;

    try {
      return await new Promise((resolve, reject) => {
        const transaction = this.db.transaction([this.storeName], 'readonly');
        const objectStore = transaction.objectStore(this.storeName);
        const request = objectStore.get(filename);

        request.onsuccess = () => {
          const result = request.result;
          if (result) {
            // Convert array back to Float32Array
            result.samples = new Float32Array(result.samples);
          }
          resolve(result);
        };
        request.onerror = () => reject(request.error);
      });
    } catch (error) {
      console.error('Failed to get preview from cache:', filename, error);
      return null;
    }
  }

  async set(filename, samples) {
    if (!this.ready || !this.db) return false;

    try {
      await new Promise((resolve, reject) => {
        const transaction = this.db.transaction([this.storeName], 'readwrite');
        const objectStore = transaction.objectStore(this.storeName);

        const data = {
          filename: filename,
          samples: Array.from(samples),  // Convert Float32Array to regular array for storage
          timestamp: Date.now()
        };

        const request = objectStore.put(data);
        request.onsuccess = () => resolve();
        request.onerror = () => reject(request.error);
      });

      return true;
    } catch (error) {
      console.error('Failed to cache preview:', filename, error);
      return false;
    }
  }

  async clear() {
    if (!this.ready || !this.db) return false;

    try {
      await new Promise((resolve, reject) => {
        const transaction = this.db.transaction([this.storeName], 'readwrite');
        const objectStore = transaction.objectStore(this.storeName);
        const request = objectStore.clear();

        request.onsuccess = () => resolve();
        request.onerror = () => reject(request.error);
      });

      console.log('✅ Preview cache cleared');
      return true;
    } catch (error) {
      console.error('Failed to clear preview cache:', error);
      return false;
    }
  }

  async getAll() {
    if (!this.ready || !this.db) return [];

    try {
      return await new Promise((resolve, reject) => {
        const transaction = this.db.transaction([this.storeName], 'readonly');
        const objectStore = transaction.objectStore(this.storeName);
        const request = objectStore.getAll();

        request.onsuccess = () => resolve(request.result || []);
        request.onerror = () => reject(request.error);
      });
    } catch (error) {
      console.error('Failed to get all previews:', error);
      return [];
    }
  }
}

// Global preview cache instance
window.wavetablePreviewCache = new WavetablePreviewCache();

//==============================================================================
// Wavetable Library - Catalog management with localStorage
//==============================================================================
class WavetableLibrary {
  constructor() {
    this.userWavetables = [];  // File-based user wavetables from C++
  }

  // Update user wavetables list from C++ (via WAVETABLE_LIST message)
  updateUserWavetables(wavetableList) {
    this.userWavetables = wavetableList || [];
    console.log(`📂 WavetableLibrary updated with ${this.userWavetables.length} user wavetables`);

    // Invalidate wavetable array cache so getWavetableArray() recreates with updated user wavetables
    window.__wavetableArrayCache = {};

    // Update showcases to reflect new wavetable count
    if (window.osc1Showcase) window.osc1Showcase.updateDisplay();
    if (window.osc2Showcase) window.osc2Showcase.updateDisplay();
  }

  // Get all saved wavetables (factory + user from file system)
  getAll() {
    return [...this.getFactoryWaveforms(), ...this.userWavetables];
  }

  // Save a new wavetable to the file system (.wtb format)
  save(name, waveformData, tags = []) {
    try {
      // Generate filename (sanitize name)
      const filename = name.replace(/[^a-zA-Z0-9_\-]/g, '_') + '.wtb';

      // Save to file system via C++
      if (window.wavetableSaveToFile) {
        window.wavetableSaveToFile(filename, waveformData);

        // After save, request updated list
        setTimeout(() => {
          if (window.wavetableListRequest) {
            window.wavetableListRequest();
          }
        }, 100);

        return {
          id: filename,
          name: name,
          filename: filename,
          tags: tags,
          isFactory: false
        };
      } else {
        console.error('wavetableSaveToFile not available');
        return null;
      }
    } catch (e) {
      console.error('Failed to save wavetable:', e);
      return null;
    }
  }

  // Delete a wavetable by ID (filename)
  delete(id) {
    try {
      // TODO: Implement WAVETABLE_DELETE message to C++
      console.warn('Wavetable delete not yet implemented (file system)');
      // For now, filter from local cache
      this.userWavetables = this.userWavetables.filter(w => w.id !== id);
      return true;
    } catch (e) {
      console.error('Failed to delete wavetable:', e);
      return false;
    }
  }

  // Get a specific wavetable by ID
  get(id) {
    const library = this.getAll();
    return library.find(w => w.id === id);
  }

  // Search wavetables by name or tags
  search(query) {
    const library = this.getAll();
    const lowerQuery = query.toLowerCase();
    return library.filter(w =>
      w.name.toLowerCase().includes(lowerQuery) ||
      (w.tags && w.tags.some(tag => tag.toLowerCase().includes(lowerQuery)))
    );
  }

  // Get factory waveforms (built-in 6 primitives)
  getFactoryWaveforms() {
    return [
      { id: 'factory_0', name: 'Sine', type: 'sine', isFactory: true, slotIndex: 0 },
      { id: 'factory_1', name: 'Saw', type: 'saw', isFactory: true, slotIndex: 1 },
      { id: 'factory_2', name: 'Square', type: 'square', isFactory: true, slotIndex: 2 },
      { id: 'factory_3', name: 'Triangle', type: 'triangle', isFactory: true, slotIndex: 3 },
      { id: 'factory_4', name: 'Ramp', type: 'ramp', isFactory: true, slotIndex: 4 },
      { id: 'factory_5', name: 'Parabola', type: 'parabola', isFactory: true, slotIndex: 5 }
    ];
  }

  // Get user waveforms (from file system)
  getUserWaveforms() {
    return this.userWavetables;
  }

  // Get all waveforms grouped by category
  getAllGrouped() {
    return {
      factory: this.getFactoryWaveforms(),
      user: this.getUserWaveforms()
    };
  }
}

// Global wavetable library instance
window.wavetableLibrary = new WavetableLibrary();

//==============================================================================
// Wavetable Catalog UI - Browse and select wavetables from library
//==============================================================================
class WavetableCatalogUI {
  constructor(themeColor, onSelect) {
    this.themeColor = themeColor;
    this.onSelect = onSelect;
    this.library = window.wavetableLibrary;
    this.createModal();
  }

  createModal() {
    this.modalView = new AppModal({
      title: 'Wavetable Library',
      themeColor: this.themeColor,
      maxWidth: '900px'
    });

    // Search bar
    const searchBar = document.createElement('div');
    searchBar.className = 'wavetable-catalog-search';
    searchBar.innerHTML = `
      <input type="text" id="wavetable-search" placeholder="Search wavetables..."
             style="width: 100%; padding: 10px; border-radius: 8px; border: 1px solid rgba(255,255,255,0.2);
                    background: rgba(0,0,0,0.3); color: var(--text-primary); font-family: var(--font-body);">
    `;

    // Grid container
    this.gridContainer = document.createElement('div');
    this.gridContainer.className = 'wavetable-catalog-grid';
    this.gridContainer.style.cssText = `
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
      gap: 16px;
      margin-top: 16px;
      max-height: 500px;
      overflow-y: auto;
      padding: 4px;
    `;

    // Assemble content
    const content = document.createElement('div');
    content.appendChild(searchBar);
    content.appendChild(this.gridContainer);
    this.modalView.setContent(content);

    // Search functionality
    const searchInput = searchBar.querySelector('#wavetable-search');
    searchInput.addEventListener('input', (e) => {
      const query = e.target.value;
      this.renderGrid(query ? this.library.search(query) : this.library.getAll());
    });

    // Initial render
    this.renderGrid(this.library.getAll());
  }

  renderGrid(wavetables) {
    this.gridContainer.innerHTML = '';

    if (wavetables.length === 0) {
      this.gridContainer.innerHTML = `
        <div style="grid-column: 1 / -1; text-align: center; padding: 40px; color: rgba(255,255,255,0.5);">
          No wavetables in library. Use the editor to create and save wavetables.
        </div>
      `;
      return;
    }

    wavetables.forEach(wt => {
      const item = document.createElement('div');
      item.className = 'wavetable-catalog-item';
      item.style.cssText = `
        background: rgba(0,0,0,0.4);
        border: 1px solid rgba(${this.themeColor}, 0.3);
        border-radius: 8px;
        padding: 12px;
        cursor: pointer;
        transition: all 0.2s;
      `;

      // Preview canvas
      const canvas = document.createElement('canvas');
      canvas.width = 200;
      canvas.height = 80;
      canvas.style.cssText = 'width: 100%; height: auto; border-radius: 4px;';

      // Check if waveform data is already available (factory wavetables)
      if (wt.data && wt.data.length > 0) {
        // Draw immediately for factory wavetables
        this.drawPreview(canvas, new Float32Array(wt.data));
      } else if (wt.filename) {
        // File-based wavetable - check cache first, then lazy load preview
        this.drawLoadingPlaceholder(canvas);

        // Try to get from cache first
        const loadPreview = async () => {
          // Check IndexedDB cache
          if (window.wavetablePreviewCache && window.wavetablePreviewCache.ready) {
            const cached = await window.wavetablePreviewCache.get(wt.filename);
            if (cached && cached.samples) {
              console.log(`📦 Cache hit for preview: ${wt.filename}`);
              this.drawPreview(canvas, cached.samples);
              return;
            }
          }

          // Cache miss - request from C++
          if (typeof window.wavetableLoadPreview === 'function') {
            window.wavetableLoadPreview(wt.filename, async (samples, filename, error) => {
              if (error) {
                console.error('Failed to load preview for', filename, ':', error);
                this.drawErrorPlaceholder(canvas);
              } else if (samples && samples.length > 0) {
                this.drawPreview(canvas, samples);

                // Cache the preview for next time
                if (window.wavetablePreviewCache && window.wavetablePreviewCache.ready) {
                  await window.wavetablePreviewCache.set(filename, samples);
                  console.log(`💾 Cached preview: ${filename}`);
                }
              }
            });
          }
        };

        loadPreview();
      } else {
        // No data available
        this.drawErrorPlaceholder(canvas);
      }

      // Name
      const name = document.createElement('div');
      name.textContent = wt.name;
      name.style.cssText = `
        margin-top: 8px;
        font-weight: 600;
        color: var(--text-primary);
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      `;

      // Date
      const date = document.createElement('div');
      date.textContent = new Date(wt.createdAt).toLocaleDateString();
      date.style.cssText = 'font-size: 11px; color: rgba(255,255,255,0.5); margin-top: 4px;';

      // Delete button
      const deleteBtn = document.createElement('button');
      deleteBtn.textContent = '×';
      deleteBtn.style.cssText = `
        position: absolute;
        top: 8px;
        right: 8px;
        background: rgba(255,0,0,0.7);
        border: none;
        border-radius: 4px;
        color: white;
        width: 24px;
        height: 24px;
        cursor: pointer;
        font-size: 18px;
        line-height: 1;
        display: none;
      `;
      deleteBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        if (confirm(`Delete "${wt.name}"?`)) {
          this.library.delete(wt.id);
          this.renderGrid(this.library.getAll());
        }
      });

      item.style.position = 'relative';
      item.addEventListener('mouseenter', () => {
        item.style.borderColor = `rgba(${this.themeColor}, 0.8)`;
        item.style.background = 'rgba(0,0,0,0.6)';
        deleteBtn.style.display = 'block';
      });
      item.addEventListener('mouseleave', () => {
        item.style.borderColor = `rgba(${this.themeColor}, 0.3)`;
        item.style.background = 'rgba(0,0,0,0.4)';
        deleteBtn.style.display = 'none';
      });

      item.addEventListener('click', () => {
        if (this.onSelect) {
          this.onSelect(new Float32Array(wt.data), wt.name);
        }
        this.close();
      });

      item.appendChild(deleteBtn);
      item.appendChild(canvas);
      item.appendChild(name);
      item.appendChild(date);
      this.gridContainer.appendChild(item);
    });
  }

  drawPreview(canvas, waveformData) {
    const ctx = canvas.getContext('2d');
    const width = canvas.width;
    const height = canvas.height;

    // Background
    ctx.fillStyle = '#0a0a0a';
    ctx.fillRect(0, 0, width, height);

    // Waveform
    ctx.strokeStyle = `rgba(${this.themeColor}, 0.9)`;
    ctx.lineWidth = 2;
    ctx.beginPath();

    for (let i = 0; i < width; i++) {
      const dataIndex = Math.floor((i / width) * waveformData.length);
      const value = waveformData[dataIndex];
      const y = height / 2 - (value * height / 2);

      if (i === 0) {
        ctx.moveTo(i, y);
      } else {
        ctx.lineTo(i, y);
      }
    }
    ctx.stroke();
  }

  drawLoadingPlaceholder(canvas) {
    const ctx = canvas.getContext('2d');
    const width = canvas.width;
    const height = canvas.height;

    // Background
    ctx.fillStyle = '#0a0a0a';
    ctx.fillRect(0, 0, width, height);

    // Loading text
    ctx.fillStyle = `rgba(${this.themeColor}, 0.5)`;
    ctx.font = '12px var(--font-body)';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('Loading...', width / 2, height / 2);
  }

  drawErrorPlaceholder(canvas) {
    const ctx = canvas.getContext('2d');
    const width = canvas.width;
    const height = canvas.height;

    // Background
    ctx.fillStyle = '#0a0a0a';
    ctx.fillRect(0, 0, width, height);

    // Error message
    ctx.fillStyle = 'rgba(255, 100, 100, 0.5)';
    ctx.font = '12px var(--font-body)';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('No preview', width / 2, height / 2);
  }

  open() {
    this.renderGrid(this.library.getAll());
    this.modalView.open();
  }

  close() {
    this.modalView.close();
  }
}

// ============================================================================
// Footer Functionality
// ============================================================================

// Panic button - reset all voices
const panicBtn = document.getElementById('panic-btn');
if (panicBtn) {
  panicBtn.addEventListener('click', () => {
    console.log('Panic! Resetting all voices...');
    // TODO: Send panic/all-notes-off MIDI message to iPlug2
    // For now, send CC 123 (All Notes Off) and CC 120 (All Sound Off)
    try {
      window.webkit.messageHandlers.callback.postMessage({
        msg: 'SMMFUI',
        statusByte: 0xB0, // Control Change on channel 1
        dataByte1: 123,   // All Notes Off
        dataByte2: 0
      });
      window.webkit.messageHandlers.callback.postMessage({
        msg: 'SMMFUI',
        statusByte: 0xB0, // Control Change on channel 1
        dataByte1: 120,   // All Sound Off
        dataByte2: 0
      });
    } catch (e) {
      console.error('Panic failed:', e);
    }
  });
}

// Randomize button - randomize all parameters
const randomizeBtn = document.getElementById('randomize-btn');
if (randomizeBtn) {
  randomizeBtn.addEventListener('click', () => {
    console.log('Randomizing parameters...');
    // TODO: Implement parameter randomization
    // For now, just log a message
    alert('Randomize feature coming soon!\n\n(Will randomize all synth parameters)');
  });
}

// MIDI indicator - pulse on MIDI receive
// This will be triggered when MIDI messages are received
function pulseMidiIndicator() {
  const midiDot = document.getElementById('midi-indicator');
  if (midiDot) {
    midiDot.classList.add('active');
    setTimeout(() => {
      midiDot.classList.remove('active');
    }, 100);
  }
}

// Make pulseMidiIndicator available globally for MIDI handling
window.pulseMidiIndicator = pulseMidiIndicator;

console.log('Awaon UI script initialized');
